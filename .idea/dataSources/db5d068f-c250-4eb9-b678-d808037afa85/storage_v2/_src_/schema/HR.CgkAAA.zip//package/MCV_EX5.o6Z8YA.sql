create PACKAGE mcv_ex5 IS
 PROCEDURE anumit(job mcv_emp.job_id%TYPE);
 PROCEDURE anumit(anul NUMBER);
END mcv_ex5;
/

