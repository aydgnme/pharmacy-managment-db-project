create PACKAGE Angajati_pkg AS
    FUNCTION Anul_Angajarii(ID_angajat IN NUMBER) RETURN NUMBER;


END Angajati_pkg;

CREATE OR REPLACE PACKAGE BODY Angajati_pkg AS
    FUNCTION Anul_Angajarii(ID_angajat IN NUMBER) RETURN NUMBER IS
        Anul DATE;
    BEGIN
        SELECT EXTRACT(YEAR FROM hire_date) INTO Anul
        FROM employees
        WHERE employee_id = ID_angajat;

        RETURN Anul;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END Anul_Angajarii;


END Angajati_pkg;
/

