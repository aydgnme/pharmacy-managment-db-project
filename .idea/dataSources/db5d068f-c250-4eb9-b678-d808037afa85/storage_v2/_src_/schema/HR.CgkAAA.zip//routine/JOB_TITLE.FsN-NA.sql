create function job_title( v_first_name in varchar2,  v_last_name in varchar2) return varchar2 is
v_job varchar2(100);
begin

select j.job_title into v_job
from employees e
inner join jobs j  on e.job_id = j.job_id
where e.first_name = v_first_name and e.last_name = v_last_name;

return v_job;
exception
when no_data_found then
return null;
end;
/

