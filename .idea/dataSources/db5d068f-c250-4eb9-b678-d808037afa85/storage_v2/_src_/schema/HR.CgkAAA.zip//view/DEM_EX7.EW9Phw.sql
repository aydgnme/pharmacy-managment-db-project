create view DEM_EX7 as
SELECT COUNT(employee_id) AS nr_angajati, MAX(salary) AS salariu_maxim, TO_CHAR(hire_date, 'YYYY') AS year
FROM employees
GROUP BY TO_CHAR(hire_date, 'YYYY')
/

