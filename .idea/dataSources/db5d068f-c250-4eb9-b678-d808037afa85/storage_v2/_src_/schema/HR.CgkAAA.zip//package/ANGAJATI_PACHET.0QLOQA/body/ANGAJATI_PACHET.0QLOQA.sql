create PACKAGE BODY Angajati_Pachet AS
  PROCEDURE afisare_angajati_job(job_id VARCHAR2) IS
  BEGIN
    FOR angajat IN (SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME FROM EMPLOYEES WHERE JOB_ID = job_id) LOOP
      DBMS_OUTPUT.PUT_LINE('ID: ' || angajat.EMPLOYEE_ID || ', Nume: ' || angajat.FIRST_NAME || ' ' || angajat.LAST_NAME);
    END LOOP;
  END afisare_angajati_job;

  PROCEDURE afisare_salariati_an(anul NUMBER) IS
  BEGIN
    FOR salariat IN (SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME FROM EMPLOYEES WHERE EXTRACT(YEAR FROM HIRE_DATE) = anul) LOOP
      DBMS_OUTPUT.PUT_LINE('ID: ' || salariat.EMPLOYEE_ID || ', Nume: ' || salariat.FIRST_NAME || ' ' || salariat.LAST_NAME);
    END LOOP;
  END afisare_salariati_an;

  PROCEDURE afisare_angajati_job(job_id VARCHAR2, anul NUMBER) IS
  BEGIN
    FOR angajat IN (SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME FROM EMPLOYEES WHERE JOB_ID = job_id AND EXTRACT(YEAR FROM HIRE_DATE) = anul) LOOP
      DBMS_OUTPUT.PUT_LINE('ID: ' || angajat.EMPLOYEE_ID || ', Nume: ' || angajat.FIRST_NAME || ' ' || angajat.LAST_NAME);
    END LOOP;
  END afisare_angajati_job;
END Angajati_Pachet;
/

