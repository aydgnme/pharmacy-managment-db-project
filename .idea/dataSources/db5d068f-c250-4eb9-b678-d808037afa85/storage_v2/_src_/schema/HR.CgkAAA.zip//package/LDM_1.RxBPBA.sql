create package LDM_1 is
function avg_sal_dep (v_dep employees.department_id%type)
return number;
function avg_sal
return number;
function avg_sal_an (v_an number)
return number;
end LDM_1;
/

