create PACKAGE BODY CB_pachet5 IS
    PROCEDURE afisareAngajati(job_name IN VARCHAR2)
    IS
    BEGIN
        FOR emp IN (SELECT employee_id, first_name, last_name
                    FROM employees
                    WHERE UPPER(job_id) = UPPER(job_name))
        LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || emp.employee_id || ', Nume: ' || emp.first_name || ', Prenume: ' || emp.last_name);
        END LOOP;
    END afisareAngajati;

    PROCEDURE afisareAngajati(anul_angajarii IN NUMBER)
    IS
    BEGIN
        FOR emp IN (SELECT employee_id, first_name, last_name
                    FROM employees
                    WHERE EXTRACT(YEAR FROM hire_date) = anul_angajarii)
        LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || emp.employee_id || ', Nume: ' || emp.first_name || ', Prenume: ' || emp.last_name);
        END LOOP;
    END afisareAngajati;
END CB_pachet5;
/

