create function salary_name(p_department_name in varchar2) return number is

v_max_salariu number;

begin

select max(salary) into v_max_salariu
from employees e
inner join departments d on d.department_id = e.department_id
where upper(d.department_name) = upper(p_department_name);

return v_max_salariu;
exception
when no_data_found then
return null;
end;

set serveroutput on;

declare

v_nume_departament varchar2(100);
v_max_salary number;

begin

v_nume_departament := 'IT';
v_max_salary := salary_name(v_nume_departament);

if v_max_salary is not null then
dbms_output.put_line(v_nume_departament || v_max_salary);
else
dbms_output.put_line('nu este' || v_nume_departament);
end if;
end;
/

