create PACKAGE BODY sa_pachet_2 IS

    FUNCTION getAnAngajare(employee_id IN employees.employee_id%TYPE) RETURN DATE IS
        v_an_angajare DATE;
    BEGIN
        SELECT hire_date INTO v_an_angajare
        FROM employees
        WHERE employee_id = employee_id;

        RETURN v_an_angajare;
    END getAnAngajare;

    PROCEDURE afisareAnAngajare(employee_id IN employees.employee_id%TYPE) IS
        v_an_angajare DATE;
    BEGIN
        v_an_angajare := getAnAngajare(employee_id);
        DBMS_OUTPUT.PUT_LINE('Angajatul cu ID-ul ' || employee_id || ' a fost angajat în anul: ' || TO_CHAR(v_an_angajare, 'YYYY'));
    END afisareAnAngajare;

END sa_pachet_2;
/

