create FUNCTION IdManagerAngajat(
    p_employee_id employees_sa.employee_id%TYPE
)

RETURN employees_sa.manager_id%TYPE AS
    v_manager_id employees_sa.manager_id%TYPE;
BEGIN
SELECT manager_id INTO v_manager_id
FROM employees
WHERE employee_id = p_employee_id;

RETURN v_manager_id;

EXCEPTION WHERE NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE (' Eroare ');


END;
/

