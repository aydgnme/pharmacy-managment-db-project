create PACKAGE BODY pachet_aa2 IS
FUNCTION numecompletangajat(id aa_emp.employee_id%TYPE)
RETURN VARCHAR2
IS
numecomplet aa_emp.last_name%TYPE;
BEGIN
SELECT last_name||' '||first_name into numecomplet from aa_emp where employee_id = id;
IF id is null then
DBMS_OUTPUT.PUT_LINE('Nu exista niciun angajat cu acest id');
ELSE
return numecomplet;
END IF;
END numecompletangajat;
FUNCTION salariuangajat(id aa_emp.employee_id%TYPE)
RETURN NUMBER
is
salariu aa_emp.salary%TYPE;
BEGIN
SELECT salary into salariu from aa_emp where employee_id = id;
return salariu;
END salariuangajat;
FUNCTION emailangajat(id aa_emp.employee_id%TYPE)
RETURN VARCHAR2
is
email aa_emp.email%TYPE;
BEGIN
select email into email from aa_emp where employee_id = id;
return email;
END emailangajat;
FUNCTION hiredateangajat(id aa_emp.employee_id%TYPE)
RETURN DATE
is
hiredate aa_emp.hire_date%TYPE;
BEGIN
select hire_date into hiredate from aa_emp where employee_id = id;
return hiredate;
END hiredateangajat;
END pachet_aa2;
/

