create procedure delete_employees(v_vechime in number)

is

   v_vechime  number;

begin

  delete from employees_ab where to_char(hire_date, 'YYYY') = v_vechime;



end delete_employees;
/

