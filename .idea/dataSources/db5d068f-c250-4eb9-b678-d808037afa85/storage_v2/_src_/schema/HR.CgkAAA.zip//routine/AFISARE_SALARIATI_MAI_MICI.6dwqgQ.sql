create PROCEDURE afisare_salariati_mai_mici(
    p_salariu_maxim IN NUMBER
)
IS
BEGIN
    FOR angajat IN (SELECT * FROM employees WHERE salary < p_salariu_maxim) LOOP
        DBMS_OUTPUT.PUT_LINE(angajat.employee_id || ' ' || angajat.last_name || ' ' || angajat.first_name || ' ' || angajat.salary);
    END LOOP;
END afisare_salariati_mai_mici;
/

