create PACKAGE BODY pachet_AA IS
FUNCTION AVGSAL
RETURN NUMBER IS
suma NUMBER;
BEGIN
SELECT AVG(SALARY) into suma  from aa_emp;
return suma;
END AVGSAL;
FUNCTION AVGSALDEP(depid aa_dep.department_id%TYPE)
RETURN NUMBER IS
sumasalarii NUMBER;
BEGIN
SELECT avg(salary) into sumasalarii from employees where department_id = depid;
return sumasalarii;
END avgsaldep;
FUNCTION AVGSALAN(AN NUMBER)
RETURN NUMBER IS
sumasalariipean number;
BEGIN
select avg(salary) into sumasalariipean from employees where TO_CHAR(hire_date,'YYYY') = an;
return sumasalariipean;
END avgsalan;
end pachet_aa;
/

