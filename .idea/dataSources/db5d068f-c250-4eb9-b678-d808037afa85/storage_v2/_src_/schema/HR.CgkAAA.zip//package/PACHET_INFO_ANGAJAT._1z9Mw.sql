create PACKAGE pachet_info_angajat IS

    FUNCTION nume_complet(p_employee_id IN employees.employee_id%TYPE) RETURN VARCHAR2;

    FUNCTION salariu(p_employee_id IN employees.employee_id%TYPE) RETURN NUMBER;

        FUNCTION email(p_employee_id IN employees.employee_id%TYPE) RETURN VARCHAR2;

    FUNCTION data_angajare(p_employee_id IN employees.employee_id%TYPE) RETURN DATE;
END pachet_info_angajat;
/

