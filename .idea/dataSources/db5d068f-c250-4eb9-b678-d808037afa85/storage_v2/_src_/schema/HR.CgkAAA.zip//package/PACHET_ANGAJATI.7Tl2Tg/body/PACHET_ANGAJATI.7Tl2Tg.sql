create PACKAGE BODY Pachet_Angajati AS

    FUNCTION AnulAngajarii(ID_angajat IN employees.employee_id%TYPE) RETURN DATE IS
        v_Anul DATE;
    BEGIN
        SELECT hire_date INTO v_Anul FROM employees WHERE employee_id = ID_angajat;
        RETURN v_Anul;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END AnulAngajarii;


    PROCEDURE ModificaSalariu(ID_angajat IN employees.employee_id%TYPE, NouSalariu IN NUMBER) IS
    BEGIN
        UPDATE employees SET salary = NouSalariu WHERE employee_id = ID_angajat;
    END ModificaSalariu;
END Pachet_Angajati;
/

