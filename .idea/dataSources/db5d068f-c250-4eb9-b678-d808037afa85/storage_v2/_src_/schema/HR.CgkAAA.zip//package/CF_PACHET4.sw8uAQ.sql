create PACKAGE CF_pachet4 IS

PROCEDURE ADD_DEP(id departments.department_id%TYPE, nume departments.department_name%TYPE, manager departments.manager_id%TYPE, locatie departments.location_id%TYPE);
PROCEDURE MODIF_DEP(nume departments.department_name%TYPE, id departments.department_id%TYPE);
PROCEDURE DEL_DEP(id departments.department_id%TYPE);
FUNCTION GET_DEP(id departments.department_id%TYPE) RETURN departments.department_name%TYPE;

END CF_pachet4;
/

