create PROCEDURE inserare_departament(

    v_nume_departament departments.department_name%TYPE,

    v_locatie_departament departments.location_id%TYPE,

    v_manager_departament departments.manager_id%TYPE

) AS

BEGIN

    v_nume_departament :='test';

    INSERT INTO AD_dep(department_id, department_name,manager_id, location_id)

    VALUES (departments_seq.NEXTVAL, v_nume_departament, v_manager_departament,v_locatie_departament);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Departamentul ' || v_nume_departament || ' a fost inserat cu succes.');

EXCEPTION

    WHEN OTHERS THEN

        DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);

        ROLLBACK;

END;
/

