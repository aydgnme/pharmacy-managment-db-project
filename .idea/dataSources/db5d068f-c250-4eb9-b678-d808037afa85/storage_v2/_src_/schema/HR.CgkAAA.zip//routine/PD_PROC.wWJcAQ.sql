create procedure  pd_proc
is updateor insert;

declare
v_dep departments_pdd.department_name%type;

begin
--v_dep:='Dep_nou';
procedure pd_proc;
Update departments_pdd
set department_name=v_dep;


end pd_proc;

begin
v_dep:='Dep_nou';

update departments_pdd
set department_name=v_dep
where department_id=90;
end;
/show errors;
/

