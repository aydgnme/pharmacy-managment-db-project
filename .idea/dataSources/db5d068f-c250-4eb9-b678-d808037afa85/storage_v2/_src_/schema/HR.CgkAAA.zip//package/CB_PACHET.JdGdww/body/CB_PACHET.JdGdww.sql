create PACKAGE BODY CB_pachet IS
FUNCTION medSalDep(dep departments.department_id%TYPE)
RETURN NUMBER
IS
numar NUMBER;
BEGIN
SELECT avg(salary) INTO numar FROM employees
WHERE department_id=dep;
RETURN numar;
END medSalDep;

FUNCTION medSalAn(date1 number)
RETURN NUMBER
IS
med NUMBER;
BEGIN
SELECT avg(salary) INTO med FROM employees WHERE extract(year from hire_date)=date1;
RETURN med;
END medSalAn;

function medSal
return number
is
medsal number;
begin
select avg(salary) into medsal from employees;
return medsal;
end medSal;

END CB_pachet;

set serveroutput on;
begin
DBMS_OUTPUT.PUT_LINE('avg salariu mediu departament angajati: '|| CB_pachet.medSalDep(70));
DBMS_OUTPUT.PUT_LINE('avg Salariu mediu pe an : '|| CB_pachet.medSalAn(1999));
DBMS_OUTPUT.PUT_LINE('avg salariu mediu angajati: '|| CB_pachet.medSal);
end;
/

