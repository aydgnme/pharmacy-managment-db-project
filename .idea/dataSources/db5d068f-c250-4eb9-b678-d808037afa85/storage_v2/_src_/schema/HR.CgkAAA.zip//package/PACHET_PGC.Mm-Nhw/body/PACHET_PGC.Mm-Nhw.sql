create package body pachet_pgc IS
FUNCTION f1(id employees.employee_id%type) return employees.hire_date%type is
data employees.hire_date%type;
BEGIN
select hire_date into data from employees where employee_id=id;
return data;
end f1;
end pachet_pgc;
/

