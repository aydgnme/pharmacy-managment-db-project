create procedure  pzd_proced
is update;
declare
v_dep departments_pdd.department_name%type;
function fct (v_id_ang employees_pdd.employee_id%type)
as number;

begin
procedure pzd_proced;
Update departments_pdd
set department_name=v_dep;
end pzd_proced;

end;
/show errors;
/

