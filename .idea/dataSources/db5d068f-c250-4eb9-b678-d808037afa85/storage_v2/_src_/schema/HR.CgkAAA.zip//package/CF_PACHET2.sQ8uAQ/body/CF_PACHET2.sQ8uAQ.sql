create PACKAGE BODY CF_pachet2 IS

FUNCTION numeComplet(id employees.employee_id%TYPE) RETURN VARCHAR2 IS

nume employees.last_name%TYPE;
prenume employees.first_name%TYPE;
complet VARCHAR2(40);
BEGIN
SELECT last_name, first_name INTO nume, prenume FROM Employees WHERE employee_id = id;
complet := nume || prenume;
RETURN complet ;
END numeComplet;

FUNCTION salariu(id employees.employee_id%TYPE) RETURN NUMBER IS

nr NUMBER;
BEGIN
SELECT salary INTO nr FROM Employees WHERE employee_id = id;
RETURN nr;
END salariu;

FUNCTION email(id employees.employee_id%TYPE) RETURN employees.email%TYPE IS

em employees.email%TYPE;
BEGIN
SELECT email INTO em FROM Employees WHERE employee_id = id;
RETURN em;
END email;

FUNCTION dataAngajarii(id employees.employee_id%TYPE) RETURN employees.hire_date%TYPE IS

data employees.hire_date%TYPE;
BEGIN
SELECT hire_date INTO data FROM Employees WHERE employee_id = id;
RETURN data;
END dataAngajarii;

END CF_pachet2;
/

