create PACKAGE BODY SalaryCalculatorPackage AS
    FUNCTION avg_salary_by_department(p_department_id NUMBER) RETURN NUMBER IS
        v_avg_salary NUMBER;
    BEGIN
        SELECT AVG(salary) INTO v_avg_salary
        FROM employees
        WHERE department_id = p_department_id;

        RETURN v_avg_salary;
    END avg_salary_by_department;

    FUNCTION avg_salary_all_employees RETURN NUMBER IS
        v_avg_salary NUMBER;
    BEGIN
        SELECT AVG(salary) INTO v_avg_salary
        FROM employees;

        RETURN v_avg_salary;
    END avg_salary_all_employees;

    FUNCTION avg_salary_by_year(p_year NUMBER) RETURN NUMBER IS
        v_avg_salary NUMBER;
    BEGIN
        SELECT AVG(salary) INTO v_avg_salary
        FROM employees
        WHERE EXTRACT(YEAR FROM hire_date) = p_year;
        RETURN v_avg_salary;
    END avg_salary_by_year;
END packageArcadie;
/

