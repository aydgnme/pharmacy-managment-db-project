create PACKAGE mvd_pachet_1 IS
 FUNCTION anul(id employees.employee_id%TYPE) RETURN NUMBER;
 PROCEDURE modifica_salar(id employees.employee_id%TYPE, valoare employees.salary%TYPE);
END mvd_pachet_1;
/

