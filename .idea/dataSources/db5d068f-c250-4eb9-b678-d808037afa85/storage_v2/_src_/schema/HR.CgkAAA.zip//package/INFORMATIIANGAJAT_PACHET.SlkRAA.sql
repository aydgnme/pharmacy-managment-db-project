create PACKAGE InformatiiAngajat_pachet IS
    FUNCTION numeComplet(id_angajat IN employees.employee_id%TYPE) RETURN VARCHAR2;
    FUNCTION salariu(id_angajat IN employees.employee_id%TYPE) RETURN NUMBER;
    FUNCTION email(id_angajat IN employees.employee_id%TYPE) RETURN VARCHAR2;
    FUNCTION dataAngajarii(id_angajat IN employees.employee_id%TYPE) RETURN DATE;
END InformatiiAngajat_pachet;
/

