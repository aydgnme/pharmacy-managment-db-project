create PACKAGE BODY CM_pack5 IS
PROCEDURE showEmps(job employees.job_id%TYPE) IS
CURSOR c_ang IS
SELECT last_name, first_name FROM employees WHERE job_id=job;
BEGIN
FOR v_ang in c_ang LOOP
DBMS_OUTPUT.PUT_LINE(v_ang.last_name || ' ' || v_ang.first_name);
END LOOP;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END showEmps;

PROCEDURE showEmps(year VARCHAR2) IS
CURSOR c_ang IS
SELECT last_name, first_name FROM employees WHERE TO_CHAR(hire_date, 'YYYY')=year;
BEGIN
FOR v_ang in c_ang LOOP
DBMS_OUTPUT.PUT_LINE(v_ang.last_name || ' ' || v_ang.first_name);
END LOOP;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END showEmps;
END CM_pack5;
/

