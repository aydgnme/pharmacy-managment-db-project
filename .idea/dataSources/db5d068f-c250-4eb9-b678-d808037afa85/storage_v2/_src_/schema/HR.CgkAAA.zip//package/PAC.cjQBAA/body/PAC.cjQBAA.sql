create package body pac is

  function oras(nume_dept departments.department_name%type) return varchar2 is
  o locations.city%type;
  ex exception;
  begin

  select l.city into o from locations l,departments d
 where d.location_id = l.location_id and d.department_name = nume_dept;

if o is null then
   raise ex;
else
   return o;
end if;

exception
  when ex then
    dbms_output.put_line('Nu s a gasit orasul');
    return null;
end oras;

end pac;
/

