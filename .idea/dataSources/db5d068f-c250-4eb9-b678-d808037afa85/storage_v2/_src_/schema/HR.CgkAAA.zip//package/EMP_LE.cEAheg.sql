create PACKAGE emp_le IS

    FUNCTION get_count_emp(p_job_id IN employees.job_id%TYPE) RETURN NUMBER;

    PROCEDURE delete_employee;

END emp_le;
/

