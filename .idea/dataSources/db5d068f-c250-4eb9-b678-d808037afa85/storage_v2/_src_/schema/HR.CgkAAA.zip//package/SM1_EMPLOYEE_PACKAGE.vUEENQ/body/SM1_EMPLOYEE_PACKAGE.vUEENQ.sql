create PACKAGE BODY SM1_EMPLOYEE_PACKAGE AS

    PROCEDURE DELETE_EMPLOYEE IS

    BEGIN

        DELETE FROM employees

        WHERE hire_date = (SELECT MAX(hire_date) FROM employees);

    END DELETE_EMPLOYEE;

 FUNCTION count_employee(job_id IN NUMBER) RETURN NUMBER IS

        emp_count NUMBER;

    BEGIN

        SELECT COUNT(*)

        INTO emp_count

        FROM employees

        WHERE job_id = job_id;



        RETURN emp_count;

    END count_employee;

END SM1_EMPLOYEE_PACKAGE;




/

