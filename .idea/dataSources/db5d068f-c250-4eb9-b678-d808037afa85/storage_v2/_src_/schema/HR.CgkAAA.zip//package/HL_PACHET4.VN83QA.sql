create PACKAGE hl_pachet4 AS

  PROCEDURE ADD_DEP(h_dep_id NUMBER, h_dep_name VARCHAR2);

  PROCEDURE MODIF_DEP(h_dep_id NUMBER, h_dep_name VARCHAR2);

  PROCEDURE DEL_DEP(h_dep_id NUMBER);

  FUNCTION GET_DEP(h_dep_id NUMBER) RETURN VARCHAR2;
END hl_pachet4;
/

