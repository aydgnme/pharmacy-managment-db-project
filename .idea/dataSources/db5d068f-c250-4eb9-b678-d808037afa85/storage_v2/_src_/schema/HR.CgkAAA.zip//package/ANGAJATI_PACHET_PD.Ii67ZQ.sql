create PACKAGE Angajati_pachet_pd IS
    PROCEDURE afisareAngajatiCuLitera(litera IN VARCHAR2);
    PROCEDURE afisareAngajatiCuAcelasiJob(nume IN VARCHAR2, prenume IN VARCHAR2);
    PROCEDURE afisareAngajatiCuSalariuMaiMare;
END Angajati_pachet_pd;
CREATE OR REPLACE PACKAGE BODY Angajati_pachet IS
    PROCEDURE afisareAngajatiCuLitera(litera IN VARCHAR2) IS
    BEGIN
        FOR angajat IN (SELECT * FROM employees WHERE UPPER(SUBSTR(first_name, 1, 1)) = UPPER(litera)) LOOP
            DBMS_OUTPUT.PUT_LINE(angajat.employee_id || ' ' || angajat.first_name || ' ' || angajat.last_name);
        END LOOP;
    END afisareAngajatiCuLitera;

    PROCEDURE afisareAngajatiCuAcelasiJob(nume IN VARCHAR2, prenume IN VARCHAR2) IS
        job_angajat VARCHAR2(100);
    BEGIN
        SELECT job_id INTO job_angajat FROM employees WHERE first_name = nume AND last_name = prenume;
        FOR angajat IN (SELECT * FROM employees WHERE job_id = job_angajat AND first_name || ' ' || last_name <> nume || ' ' || prenume) LOOP
            DBMS_OUTPUT.PUT_LINE(angajat.employee_id || ' ' || angajat.first_name || ' ' || angajat.last_name);
        END LOOP;
    END afisareAngajatiCuAcelasiJob;

    PROCEDURE afisareAngajatiCuSalariuMaiMare IS
        salariu_mediu NUMBER;
    BEGIN
        SELECT AVG(salary) INTO salariu_mediu FROM employees;
        FOR angajat IN (SELECT * FROM employees WHERE salary > salariu_mediu) LOOP
            DBMS_OUTPUT.PUT_LINE(angajat.employee_id || ' ' || angajat.first_name || ' ' || angajat.last_name);
        END LOOP;
    END afisareAngajatiCuSalariuMaiMare;
END Angajati_pachet;

show errors;
/

