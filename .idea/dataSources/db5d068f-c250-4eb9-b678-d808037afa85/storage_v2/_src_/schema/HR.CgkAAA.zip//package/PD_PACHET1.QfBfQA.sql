create PACKAGE pd_pachet1 IS
FUNCTION medSalDep(dep departments.department_id%TYPE)
RETURN NUMBER;
FUNCTION medSalAn(date1 number)
RETURN NUMBER;
function medSal
return number;


END pd_pachet1;



CREATE OR REPLACE PACKAGE BODY pd_pachet1 IS
FUNCTION medSalDep(dep departments.department_id%TYPE)
RETURN NUMBER
IS
numar NUMBER;
BEGIN
SELECT avg(salary) INTO numar FROM employees
WHERE department_id=dep;
RETURN numar;
END medSalDep;

FUNCTION medSalAn(date1 number)
RETURN NUMBER
IS
med NUMBER;
BEGIN
SELECT avg(salary) INTO med FROM employees WHERE extract(year from hire_date)=date1;
RETURN med;
END medSalAn;

function medSal
return number
is
medsal;
select avg(salary) into medsal from employees;
return medsal;
end medSal;

END pd_pachet1;



begin
DBMS_OUTPUT.PUT_LINE('avg sal dep angajati: '|| pd_pachet1.medSalDep(80));
DBMS_OUTPUT.PUT_LINE('avg an de angajati: '|| pd_pachet1.medSalAn(2000));
DBMS_OUTPUT.PUT_LINE('avg sal de angajati: '|| pd_pachet1.medSal);
end;
/

