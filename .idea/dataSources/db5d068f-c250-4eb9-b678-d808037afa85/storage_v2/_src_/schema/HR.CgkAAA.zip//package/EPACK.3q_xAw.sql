create PACKAGE EPack is
    PROCEDURE Job(job_title jobs.job_title%type);
    PROCEDURE displayYear(year number);
END EPack;
/

