create FUNCTION FUNCTIE(nume employees.first_name%TYPE, prenume employees.last_name%TYPE)RETURN jobs.job_title%TYPE IS nume_job jobs.job_title%TYPE;







BEGIN







SELECT job_title into nume_job



from employees e,jobs j



where j.job_id=e.job_id and first_name=prenume and last_name=nume;



return nume_job;







end functie;
/

