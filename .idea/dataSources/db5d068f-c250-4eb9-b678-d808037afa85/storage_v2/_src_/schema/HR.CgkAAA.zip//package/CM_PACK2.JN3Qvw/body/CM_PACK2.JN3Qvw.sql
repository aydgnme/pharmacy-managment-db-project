create PACKAGE BODY CM_pack2 IS
FUNCTION getFullName(id employees.employee_id%TYPE)
RETURN VARCHAR2
IS
fullName VARCHAR2(45);
BEGIN
SELECT employees.last_name || ' ' || employees.first_name INTO fullName FROM employees WHERE employee_id=id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
RETURN fulLName;
END getFullName;

FUNCTION getSalary(id employees.employee_id%TYPE)
RETURN employees.salary%TYPE
IS
v_salary employees.salary%TYPE;
BEGIN
SELECT salary INTO v_salary FROM employees WHERE employee_id=id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
RETURN v_salary;
END getSalary;

FUNCTION getEmail(id employees.employee_id%TYPE)
RETURN employees.email%TYPE
IS
v_email employees.email%TYPE;
BEGIN
SELECT email INTO v_email FROM employees WHERE employee_id=id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
RETURN v_email ;
END getEmail;

FUNCTION getHireDate(id employees.employee_id%TYPE)
RETURN employees.hire_date%TYPE
IS
v_hire_date employees.hire_date%TYPE;
BEGIN
SELECT hire_date INTO v_hire_date FROM employees WHERE employee_id=id;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
RETURN v_hire_date ;
END getHireDate;
END CM_pack2;
/

