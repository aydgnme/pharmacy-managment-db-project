create FUNCTION numar_salariati_departament (
    p_department_id IN departments.department_id%TYPE
) RETURN INTEGER
IS
    v_nr_salariati INTEGER;
BEGIN

    SELECT COUNT(*)
    INTO v_nr_salariati
    FROM employees
    WHERE department_id = p_department_id;


    RETURN v_nr_salariati;
EXCEPTION
    WHEN NO_DATA_FOUND THEN

        RETURN 0;
END;
/

