create PROCEDURE aa_procedure(
    id IN employees.employee_id%TYPE,
    salariu OUT employees.salary%TYPE,
    salariunou OUT employees.salary%TYPE
)
IS
    com employees.commission_pct%TYPE;
BEGIN
    SELECT commission_pct INTO com
    FROM employees
    WHERE employee_id = id;

    SELECT salary INTO salariu
    FROM employees
    WHERE employee_id = id;

    IF com BETWEEN 0.1 AND 0.2 THEN
        DBMS_OUTPUT.PUT_LINE('com intre 0.1 si 0.2');
        salariunou := salariu * 1.1;
    ELSIF com > 0.2 THEN
        DBMS_OUTPUT.PUT_LINE('com peste 0.2');
        salariunou := salariu * 1.25;
    ELSE
        DBMS_OUTPUT.PUT_LINE('com sub 0.1');
        salariunou := salariu;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Nu exista niciun angajat cu acest id');
END aa_procedure;


DECLARE
    id employees.employee_id%TYPE := 145;
    salariu employees.salary%TYPE;
    salariunou employees.salary%TYPE;
BEGIN
    aa_procedure(id, salariu, salariunou);
    DBMS_OUTPUT.PUT_LINE('Salariul actual: ' || salariu || ', salariul nou: ' || salariunou);
END;
/

