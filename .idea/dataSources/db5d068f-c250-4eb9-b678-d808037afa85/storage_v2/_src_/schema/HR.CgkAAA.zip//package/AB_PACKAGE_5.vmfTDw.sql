create package ab_package_5 is

    procedure employee(p_job_id varchar2);
    procedure employee(p_an number);
end ab_package_5;
/

