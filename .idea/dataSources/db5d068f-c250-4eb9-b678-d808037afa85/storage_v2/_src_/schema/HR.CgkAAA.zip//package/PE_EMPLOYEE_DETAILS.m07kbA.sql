create PACKAGE pe_employee_details IS
 FUNCTION employeeFullName(id employees.EMPLOYEE_ID%Type)
 RETURN employees.FIRST_NAME%Type;

 FUNCTION employeeSalary(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Salary%Type;

 FUNCTION employeeEmail(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Email%Type;

 FUNCTIOn employeeHireDate(id employees.EMPLOYEE_ID%Type)
 RETURN employees.HIRE_DATE%Type;

END pe_employee_details;
/

