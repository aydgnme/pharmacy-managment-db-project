create PROCEDURE show_high_salary_employees(
    p_salary_threshold IN NUMBER
) IS
BEGIN
    FOR emp_rec IN (
        SELECT employee_id, first_name, last_name, salary
        FROM employees
        WHERE salary > p_salary_threshold
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Employee ID: ' || emp_rec.employee_id || ', Name: ' || emp_rec.first_name || ' ' || emp_rec.last_name || ', Salary: ' || emp_rec.salary);
    END LOOP;
END;
/

