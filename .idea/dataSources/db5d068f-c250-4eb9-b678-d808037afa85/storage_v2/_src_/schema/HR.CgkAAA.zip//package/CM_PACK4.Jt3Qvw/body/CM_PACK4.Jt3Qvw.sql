create PACKAGE BODY CM_pack4 IS
PROCEDURE ADD_DEP(id Cm_departments.department_id%TYPE,
name CM_departments.department_name%TYPE,
man_id CM_departments.manager_id%TYPE,
loc_id CM_departments.location_id%TYPE) IS
BEGIN
INSERT INTO CM_departments VALUES(id, name, man_id, loc_id);
END ADD_DEP;

PROCEDURE MODIF_DEP(id Cm_departments.department_id%TYPE,
name CM_departments.department_name%TYPE,
man_id CM_departments.manager_id%TYPE,
loc_id CM_departments.location_id%TYPE) IS
BEGIN
UPDATE CM_departments
SET CM_departments.department_name=name, CM_departments.manager_id=man_id, CM_departments.location_id=loc_id
WHERE id=CM_departments.department_id;
END MODIF_DEP;

PROCEDURE DEL_DEP(id Cm_departments.department_id%TYPE) IS
BEGIN
DELETE FROM CM_departments WHERE CM_departments.department_id=id;
END DEL_DEP;

FUNCTION GET_DEP(id Cm_departments.department_id%TYPE)
RETURN CM_departments.department_name%TYPE IS
name CM_departments.department_name%TYPE;
BEGIN
SELECT department_name INTO name FROM CM_departments WHERE department_id=id;
RETURN name;
END GET_DEP;
END CM_pack4;
/

