create PACKAGE BODY Employee_Management AS
  PROCEDURE Delete_Oldest_Employee_IC IS
    v_employee_id NUMBER;
  BEGIN
    SELECT employee_id INTO v_employee_id
    FROM employees
    WHERE hire_date = (SELECT MIN(hire_date) FROM employees);
    DELETE FROM employees WHERE employee_id = v_employee_id;
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('No employees found.');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
  END Delete_Oldest_Employee_IC;
  FUNCTION Count_Employees_By_Job_IC(job_id IN VARCHAR2) RETURN NUMBER IS
    v_count NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_count FROM employees WHERE job_id = job_id;
    RETURN v_count;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
      RETURN NULL;
  END Count_Employees_By_Job_IC;
END Employee_Management_IC;
/

