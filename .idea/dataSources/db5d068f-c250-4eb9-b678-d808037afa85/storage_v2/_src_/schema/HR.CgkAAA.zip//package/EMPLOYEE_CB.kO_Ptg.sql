create PACKAGE employee_cb IS

    FUNCTION get_hire_year(emp_id IN employees.employee_id%TYPE) RETURN NUMBER;

    PROCEDURE update_salary(emp_id IN employees.employee_id%TYPE, salary_change IN NUMBER);

END employee_cb;
/

