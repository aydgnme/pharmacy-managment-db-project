create package pachet_pgc IS
FUNCTION f1(id employees.employee_id%type) return employees.hire_date%type;
end pachet_pgc;
/

