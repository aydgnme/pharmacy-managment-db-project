create PACKAGE pachet_LE is

FUNCTION func(id employees.employee_id%type) return number;

PROCEDURE proc(id_ang employees.employee_id%type);

END pachet_LE;
/

