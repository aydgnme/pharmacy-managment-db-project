create PACKAGE CF_pachet1 IS

FUNCTION salariuMediuDepartament(dep departments.department_id%TYPE) RETURN NUMBER;
FUNCTION salariuMediuAngajati RETURN NUMBER;
FUNCTION salariuMediuAn(an VARCHAR2) RETURN NUMBER;

END CF_pachet1;
/

