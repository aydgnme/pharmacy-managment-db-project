create PACKAGE hlm_pachet3 IS
  PROCEDURE empInitial(p_initial IN VARCHAR2);
  PROCEDURE empSameJobs(p_nume IN VARCHAR2, p_prenume IN VARCHAR2);
  PROCEDURE highSalaries;
END hlm_pachet3;
/

