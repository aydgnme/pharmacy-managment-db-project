create FUNCTION CC1_test_ex2 (loc_id NUMBER)

RETURN INTEGER AS

	nr_deps INTEGER;

BEGIN

	SELECT COUNT(*)

	INTO nr_deps

	FROM departments

	WHERE location_id = loc_id;

	RETURN nr_deps;

END;
/

