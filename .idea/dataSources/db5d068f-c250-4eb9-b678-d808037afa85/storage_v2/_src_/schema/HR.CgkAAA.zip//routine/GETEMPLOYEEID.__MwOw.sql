create Function GetEmployeeID(
p_first_name VarChar2,
p_last_name VarChar2)
Return Number
IS
v_employee_id PSM_Employees.Employee_ID%Type;

BEGIN
Select Employee_ID
INTO v_Employee_ID
FROM PSM_EMPLOYEES
WHERE FIRST_NAME = p_first_name AND
Last_Name = p_last_name;

return v_employee_id;

EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
/

