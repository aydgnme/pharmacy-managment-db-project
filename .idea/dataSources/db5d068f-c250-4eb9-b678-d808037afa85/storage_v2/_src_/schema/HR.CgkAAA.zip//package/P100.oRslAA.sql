create PACKAGE p100 IS
  FUNCTION ValoareMedieSlariu(departament employees.department_id%type)
    RETURN NUMBER;
END p1;
/

