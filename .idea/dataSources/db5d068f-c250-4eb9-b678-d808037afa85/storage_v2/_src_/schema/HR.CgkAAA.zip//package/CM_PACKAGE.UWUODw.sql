create PACKAGE CM_package IS

PROCEDURE CM_deleteOldest;

FUNCTION CM_getEmpCountByJob(id employees.job_id%TYPE) RETURN NUMBER;

END;
/

