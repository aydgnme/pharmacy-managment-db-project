create package PACHET1 as
  procedure stergeAngajat is
  show errors;
end;
/

