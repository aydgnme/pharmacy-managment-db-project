create view ANGAJATIMANAGERI as
SELECT e.Employee_Id,e.First_Name || ' '  || e.Last_Name AS Angajat,d.Department_Name,j.Job_Title, m.First_name || ' ' || m.Last_name AS Manager
FROM Employees e,Departments d,Jobs j, Employees m
WHERE e.Department_Id = d.Department_Id AND e.Job_Id = j.Job_Id AND e.Manager_id = m.Employee_Id
/

