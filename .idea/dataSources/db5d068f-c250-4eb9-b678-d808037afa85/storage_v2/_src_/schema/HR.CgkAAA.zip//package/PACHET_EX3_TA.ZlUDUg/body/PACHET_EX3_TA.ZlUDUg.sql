create package body pachet_ex3_TA IS
  function getAnAngajare(employee_id employees.employee_id%TYPE) return date is
  v_an_angajare DATE;
  BEGIN
    SELECT HIRE_DATE INTO V_AN_ANGAJARE
    FROM EMPLOYEES
    WHERE EMPLOYEE_ID = EMPLOYEE_ID;

    RETURN V_AN_ANGAJARE;
  END GETaNaNGAJARE;
   procedure afisareAnAngajare(employee_id employees.employee_id%TYPE) IS
   v_an_angajare DATE;
   BEGIN
     v_an_angajare := getAnAngajare(employee_id);
     DBMS_OUTPUT.PUT_LINE('Angajatul cu ID-ul ' || employee_id ||
' a fost angajat in anul: ' || TO_CHAR(V_AN_ANGAJARE, 'YYYY'));
   END afisareAnAngajare;
END pachet_ex3_TA ;
/

