create PACKAGE BODY mcv_ex2 AS
 FUNCTION get_nume(id mcv_emp.employee_id%TYPE) RETURN varchar2
 IS
  nume_complet VARCHAR2(50);
 BEGIN
 SELECT first_Name ||''|| last_Name INTO nume_complet FROM Employees WHERE employee_id = id;
 RETURN nume_complet;
 END get_nume;

 FUNCTION get_salary(id mcv_emp.employee_id%TYPE)
  RETURN NUMBER
 IS
  salar NUMBER;
 BEGIN
 SELECT salary INTO salar FROM Employees Where employee_id = id;
 RETURN salar;
 END get_salary;

 FUNCTION get_email(id mcv_emp.employee_id%TYPE)
  RETURN varchar2
 IS
 eee mcv_emp.email%TYPE;
  BEGIN
  SELECT email INTO eee FROM Employees WHERE employee_id = id;
 RETURN eee;
 END get_email;

 FUNCTION get_hire_date(id mcv_emp.employee_id%TYPE)
  RETURN DATE
 IS
  data DATE;
 BEGIN
 SELECT hire_date INTO data FROM Employees where employee_id = id;
 RETURN data;
 END get_hire_date;

END mcv_ex2;
/

