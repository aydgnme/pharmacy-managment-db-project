create PACKAGE CB_pachet5 IS
    PROCEDURE afisareAngajati(job_name IN VARCHAR2);
    PROCEDURE afisareAngajati(anul_angajarii IN NUMBER);
END CB_pachet5;
/

