create PACKAGE BODY uc_pac1 IS


PROCEDURE p1(id departments.department_id%TYPE) IS

v_nume departments.department_name%TYPE;

BEGIN

SELECT department_name INTO v_nume FROM departments

WHERE department_id = id;

DBMS_OUTPUT.PUT_LINE('Departamentul ' || v_nume);

END p1;



FUNCTION f1(id departments.department_id%TYPE)

RETURN NUMBER IS

v_val NUMBER(5);

BEGIN

SELECT COUNT(*) INTO v_val FROM departments d

JOIN employees e

ON(e.department_id = d.department_id)

WHERE e.department_id = id;

RETURN v_val;

END f1;

END uc_pac1;
/

