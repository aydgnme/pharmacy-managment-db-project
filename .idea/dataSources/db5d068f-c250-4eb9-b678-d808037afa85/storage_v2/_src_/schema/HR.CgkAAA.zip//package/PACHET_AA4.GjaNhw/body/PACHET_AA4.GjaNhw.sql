create PACKAGE BODY pachet_aa4 IS
  PROCEDURE add_dep(depid aa_dep.department_id%TYPE, numedep aa_dep.department_name%TYPE, manid aa_dep.manager_id%TYPE, locid aa_dep.location_id%TYPE) IS
  BEGIN
    INSERT INTO aa_dep (department_id, department_name, manager_id, location_id)
    VALUES (depid, numedep, manid, locid);
  END add_dep;

  PROCEDURE modif_dep(depid aa_dep.department_id%TYPE, numedep aa_dep.department_name%TYPE) IS
  BEGIN
    UPDATE aa_dep
    SET department_name = numedep
    WHERE department_id = depid;
  END modif_dep;

  PROCEDURE del_dep(depid aa_dep.department_id%TYPE) IS
  BEGIN
    DELETE FROM aa_dep WHERE department_id = depid;
  END del_dep;

  FUNCTION get_dep(depid aa_dep.department_id%TYPE) RETURN aa_dep.department_name%TYPE IS
    depname aa_dep.department_name%TYPE;
  BEGIN
    SELECT department_name INTO depname FROM aa_dep WHERE department_id = depid;
    RETURN depname;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 'Nu  niciun departament cu acest ID';
  END get_dep;
END pachet_aa4;
/

