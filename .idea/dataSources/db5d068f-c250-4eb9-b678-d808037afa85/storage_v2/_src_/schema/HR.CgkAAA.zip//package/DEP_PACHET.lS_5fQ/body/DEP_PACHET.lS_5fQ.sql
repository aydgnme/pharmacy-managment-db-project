create PACKAGE BODY Dep_pachet IS
    PROCEDURE ADD_DEP(dep_id IN NUMBER, dep_name IN VARCHAR2) IS
    BEGIN
        INSERT INTO dp_dep(department_id, department_name) VALUES (dep_id, dep_name);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Departament adaugat cu succes.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Eroare la adaugarea departamentului: ' || SQLERRM);
    END ADD_DEP;

    PROCEDURE MODIF_DEP(dep_id IN NUMBER, new_dep_name IN VARCHAR2) IS
    BEGIN
        UPDATE dp_dep SET department_name = new_dep_name WHERE department_id = dep_id;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Numele departamentului a fost actualizat cu succes.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Eroare la actualizarea departamentului: ' || SQLERRM);
    END MODIF_DEP;

    PROCEDURE DEL_DEP(dep_id IN NUMBER) IS
    BEGIN
        DELETE FROM dp_dep WHERE department_id = dep_id;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Departamentul a fost sters cu succes.');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Eroare la stergerea departamentului: ' || SQLERRM);
    END DEL_DEP;

    FUNCTION GET_DEP(dep_id IN NUMBER) RETURN VARCHAR2 IS
        dep_name dp_dep.department_name%TYPE;
    BEGIN
        SELECT department_name INTO dep_name FROM dp_dep WHERE department_id = dep_id;
        RETURN dep_name;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END GET_DEP;
END Dep_pachet;
/

