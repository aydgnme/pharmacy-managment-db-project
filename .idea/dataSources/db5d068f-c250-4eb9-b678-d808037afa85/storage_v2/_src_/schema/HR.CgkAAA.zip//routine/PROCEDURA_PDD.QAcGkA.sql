create procedure procedura_pdd
update or insert;

--v_dep_id departments_pdd.department_id%type;
begin
end;

/

