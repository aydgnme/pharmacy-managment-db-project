create PACKAGE BODY hlm_pachet2 IS

FUNCTION empFullName(id employees.EMPLOYEE_ID%Type)
 RETURN employees.FIRST_NAME%Type
  IS
  full_name employees.FIRST_NAME%Type;
  BEGIN

  SELECT FIRST_NAME || ' ' || LAST_NAME INTO full_name FROM employees
  WHERE employee_id = id;

  RETURN full_name;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 'Angajatul nu exista';
    WHEN OTHERS THEN
     RETURN 'Error';
END empFullName;


--------------------------------------------


FUNCTION empSalary(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Salary%Type
IS
  emp_salary employees.Salary%Type;
  BEGIN

  SELECT salary INTO emp_salary FROM employees
  WHERE employee_id = id;

  RETURN emp_salary;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 0;
    WHEN OTHERS THEN
     RETURN -1;
end empSalary;

-----------------------------------

FUNCTION empEmail(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Email%Type
IS
    emp_email employees.Email%Type;
  BEGIN

  SELECT email INTO emp_email FROM employees
  WHERE employee_id = id;

  RETURN emp_email;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 'Angajatul nu exista';
    WHEN OTHERS THEN
     RETURN 'Error';

end empEmail;


---------------------------------

FUNCTIOn empHireDate(id employees.EMPLOYEE_ID%Type)
 RETURN employees.HIRE_DATE%Type
 IS
  emp_date employees.HIRE_DATE%Type;
 BEGIN
  SELECT hire_date INTO emp_date FROM employees
  WHERE employee_id = id;
  RETURN emp_date;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN null;
    WHEN OTHERS THEN
     RETURN null;

end empHireDate;


END hlm_pachet2;
/

