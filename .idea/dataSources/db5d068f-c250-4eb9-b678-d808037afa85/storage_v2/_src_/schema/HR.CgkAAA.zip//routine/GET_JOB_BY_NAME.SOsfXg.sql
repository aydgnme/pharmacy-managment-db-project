create FUNCTION get_job_by_name(
    v_first_name IN VARCHAR2,
    v_last_name IN VARCHAR2
) RETURN VARCHAR2 IS
    v_job VARCHAR2(100);
BEGIN

    SELECT j.job_title
    INTO v_job
    FROM employees e
    INNER JOIN jobs j ON e.job_id = j.job_id
    WHERE e.first_name = v_first_name AND e.last_name = v_last_name;


    RETURN v_job;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END;
/

