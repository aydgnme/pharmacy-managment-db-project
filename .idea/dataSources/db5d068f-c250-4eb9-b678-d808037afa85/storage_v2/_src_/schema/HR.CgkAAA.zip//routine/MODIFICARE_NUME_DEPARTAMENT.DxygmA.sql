create PROCEDURE modificare_nume_departament(
    p_department_id IN departments.department_id%TYPE,
    p_new_name IN departments.department_name%TYPE
)
IS
BEGIN
    UPDATE departments
    SET department_name = p_new_name
    WHERE department_id = p_department_id;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Numele departamentului a fost modificat cu succes.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);
END;
/

