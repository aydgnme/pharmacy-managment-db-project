create package body TA_PACHET_ex2

is

  procedure delHighestVechime

  is

  begin

      delete from empl_TA

      where hire_date =(select MIN(hire_date) from empl_TA);

  end delHighestVechime;

  function nrAng(id_job varchar)

  return number

  is

    nrAngajati Number;

    begin

    select count(employee_id) into nRAngajati from employees

    where job_id = UPPER(id_job);

    return nrAngajati;

  end nrAng;

end TA_PACHET_ex2;
/

