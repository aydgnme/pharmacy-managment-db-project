create package body pachet_bb is



procedure sterge_angajati is



id_angajat employee_bb.employee_id%type;



max_hire employee_bb.hire_date%type;



type  ids is table of employee_bb.employee_id%type;



type  nume is table of employee_bb.last_name%type;



type  prenume is table of employee_bb.first_name%type;



valori ids;



a_nume nume; a_prenume prenume;



begin



select min(hire_date) into max_hire from employee_bb;



if max_hire is null  then



 dbms_output.put_line('Nu s-a gasit cea mai mare data de angajare');

else



  delete from employee_bb where hire_date = max_hire returning employee_id, last_name, first_name bulk collect into valori, a_nume, a_prenume;



  if valori.count !=0 then



    for i in 1 .. valori.count loop



     dbms_output.put_line( 'S-a sters angajatul cu id ul: ' || valori(i) ||' ' || a_nume(i) ||' '||a_prenume(i) ||' cu data de angajare' || max_hire);

   end loop;



  else



   dbms_output.put_line('Nu s-a sters nici un angajat ');





 end if;



end if;







end sterge_angajati;











function nr_ang(id_job employee_bb.job_id%type) return number is



nr number:=0;



ex exception;



begin



select count(employee_id) into nr from employee_bb where job_id = id_job;



if nr =0 then



 raise ex;



else



 return nr;



end if;



exception



 when ex then



    return -1;

end nr_ang;

end pachet_bb;


/

