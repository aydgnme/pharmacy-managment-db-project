create package gp_package is
    procedure employee(p_job_id employees.job_id%type);
    procedure employee(p_an varchar2);
end gp_package;
/

