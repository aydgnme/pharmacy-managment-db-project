create PACKAGE CF_pachet3 IS

PROCEDURE angajatiLitera(litera CHAR);
PROCEDURE angajatiJob(eNume employees.last_name%TYPE, ePrenume employees.first_name%TYPE);
PROCEDURE salariuMediu;

END CF_pachet3;
/

