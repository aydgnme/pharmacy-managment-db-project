create package pd_pachet3 is
procedure AngLitera(litera in varchar2);
procedure AngJobidem(nume in varchar2, prenume in varchar2);
procedure AngSalMMediu;
end pd_pachet3;
/

