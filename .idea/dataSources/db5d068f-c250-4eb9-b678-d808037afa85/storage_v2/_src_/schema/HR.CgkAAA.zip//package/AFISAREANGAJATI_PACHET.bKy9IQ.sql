create PACKAGE AfisareAngajati_Pachet IS

    PROCEDURE afisareNumeInitialLitera(litera IN VARCHAR2);


    PROCEDURE afisareAngajatiCuAcelasiJob(nume IN VARCHAR2, prenume IN VARCHAR2);


    PROCEDURE afisareSalariuMaiMareDecatMedia;
END AfisareAngajati_Pachet;
/

