create PACKAGE CC_testex2 IS

FUNCTION an (ID Employees_CC.employee_id%TYPE)

RETURN DATE;

PROCEDURE editsalary(ID Employees_CC.employee_id%TYPE, salariu Employees.salary%TYPE);

END CC_testex2;
/

