create package body pachet1_LE is

function salMediu_dep(dep departments.department_id%TYPE)
return employees.salary%TYPE
is
salariu1 employees.salary%TYPE;
begin
select avg(salary) into salariu1 from employees
where department_id = dep;
return salariu1;
end salMediu_dep;

function salMediu_all
return employees.salary%TYPE
is
salariu2 employees.salary%TYPE;
begin
select avg(salary) into salariu2 from employees;
return salariu2;
end salMediu_all;

function salMediu_ang(data varchar2)
return employees.salary%TYPE
is
salariu3 employees.salary%TYPE;
begin
select avg(salary) into salariu3 from employees
where to_char(hire_date, 'yyyy') = data;
return salariu3;
end salMediu_ang;

end pachet1_LE;
/

