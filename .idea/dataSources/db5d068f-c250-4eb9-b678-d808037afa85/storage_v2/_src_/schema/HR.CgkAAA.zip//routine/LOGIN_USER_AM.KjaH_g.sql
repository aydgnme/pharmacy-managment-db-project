create FUNCTION login_user_AM (
    p_username IN VARCHAR2,
    p_password IN VARCHAR2
) RETURN VARCHAR2 IS
    v_count NUMBER;
    v_user_role VARCHAR2(50);
BEGIN
    SELECT COUNT(*), USER_ROLE INTO v_count, v_user_role
    FROM app_user_am
    WHERE USERNAME = p_username
      AND PASSWORD = p_password
    GROUP BY USER_ROLE;

    IF v_count = 1 THEN
        RETURN v_user_role;
    ELSE
        RETURN 'Invalid';
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'Invalid';
END;
/

