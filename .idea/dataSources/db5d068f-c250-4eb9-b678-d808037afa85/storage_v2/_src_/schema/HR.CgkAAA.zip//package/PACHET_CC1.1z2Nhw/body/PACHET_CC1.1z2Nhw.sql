create PACKAGE BODY pachet_CC1 IS

PROCEDURE printFirstNBySalary(n INTEGER) IS

BEGIN

FOR ang IN (SELECT * FROM employees WHERE ROWNUM <= n ORDER BY salary) LOOP

DBMS_OUTPUT.PUT_LINE('Angajatul ' || ang.last_name || ' ' || ang.first_name);

END LOOP;

END;



FUNCTION getCountByDepartment(id departments.department_id%TYPE) RETURN INTEGER IS

cnt INTEGER;

BEGIN



SELECT COUNT(*) INTO cnt

FROM EMPLOYEES

WHERE department_id = id AND salary > (SELECT AVG(salary) from employees WHERE department_id = id);



RETURN cnt;

END;



END pachet_CC1;
/

