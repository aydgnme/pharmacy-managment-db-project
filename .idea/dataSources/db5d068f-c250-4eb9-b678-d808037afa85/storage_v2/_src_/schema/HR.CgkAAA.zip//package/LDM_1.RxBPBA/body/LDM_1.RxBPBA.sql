create package body LDM_1 is
function avg_sal_dep (v_dep employees.department_id%type)
return number is
v_sal employees.salary%type;
begin
select avg(salary) into v_sal from employees
where department_id=v_dep;
return v_sal;
end avg_sal_dep;

function avg_sal return number is
v_sal employees.salary%type;
begin
select avg(salary) into v_sal from employees;
return v_sal;
end avg_sal;

function AVG_SAL_AN(v_an number)
return number is
v_sal employees.salary%type;
begin
select avg(salary) into v_sal from employees
where to_char(hire_date, 'YYYY')=v_an;
return v_sal;
end avg_sal_an;
end LDM_1;
/

