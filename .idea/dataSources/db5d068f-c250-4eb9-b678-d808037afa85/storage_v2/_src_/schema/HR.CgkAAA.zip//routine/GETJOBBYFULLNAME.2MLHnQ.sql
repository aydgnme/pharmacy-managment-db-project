create FUNCTION GetJobByFullName(p_first_name VARCHAR2, p_last_name VARCHAR2)
RETURN VARCHAR2
IS
    v_job employees.job_id%TYPE;
BEGIN
    SELECT job_id INTO v_job
    FROM employees
    WHERE first_name = p_first_name AND last_name = p_last_name;

    RETURN v_job;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'No employee found';
    WHEN TOO_MANY_ROWS THEN
        RETURN 'Multiple entries found';
    WHEN OTHERS THEN
        RETURN 'Error: ' || SQLERRM;
END;
/

