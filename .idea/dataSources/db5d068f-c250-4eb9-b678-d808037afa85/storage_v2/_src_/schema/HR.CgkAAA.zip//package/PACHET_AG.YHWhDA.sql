create package pachet_ag is



FUNCTION f(id IN emp_ag.employee_id%TYPE) return number;



PROCEDURE p(id IN emp_ag.employee_id%TYPE, val  IN NUMBER);



end pachet_ag;
/

