create PACKAGE BODY hlm_pachet5 AS

PROCEDURE showEmployees(j_id employees.JOB_ID%Type) IS
    begin
       FOR emp IN (SELECT first_name, last_name, job_id FROM employees WHERE job_id = j_id) LOOP
           DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name || ' job: ' || emp.job_id);
        END LOOP;

    end showEmployees;

PROCEDURE showEmployees(year NUMBER) IS
    begin
       FOR emp IN (SELECT first_name, last_name, hire_date FROM employees WHERE EXTRACT(YEAR FROM hire_date) = year) LOOP
           DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name || ' anul angajarii: ' || emp.hire_date);
        END LOOP;
    end showEmployees;

END hlm_pachet5;
/

