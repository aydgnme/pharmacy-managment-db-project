create PACKAGE sam_pachet4 IS
  PROCEDURE ADD_DEP(sam_dep_id NUMBER, sam_dep_name VARCHAR2);
  PROCEDURE MODIF_DEP(sam_dep_id NUMBER, sam_dep_name VARCHAR2);
  PROCEDURE DEL_DEP(sam_dep_id NUMBER);
  FUNCTION GET_DEP(sam_dep_id NUMBER)
 RETURN VARCHAR2;
END sam_pachet4;
/

