create PROCEDURE p_arcadie (
 fname employees.first_name%TYPE,
 lname employees.last_name%TYPE,
) IS
v_sal_angajat employees.salary%TYPE;
BEGIN
SELECT salary INTO v_sal_angajat FROM employees where employee_id = 100;
DBMS_OUTPUT.PUT_LINE('Salariul este ' || v_sal_angajat);
END p_arcadie;

DECLARE
v_rez number;

FUNCTION f (loc_id number) RETURN NUMBER IS
BEGIN
 for dep in (select * from departments where location_id = loc_id) loop
  DBMS_OUTPUT.PUT_LINE(dep.department_name);
 end loop;
 RETURN 1;
END f;

BEGIN
v_rez:= f(1400);
p_arcadie('Steven', 'King');
END;
/

