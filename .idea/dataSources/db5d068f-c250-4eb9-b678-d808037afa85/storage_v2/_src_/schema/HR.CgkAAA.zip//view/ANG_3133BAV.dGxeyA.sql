create view ANG_3133BAV as
SELECT COUNT(*) AS ANGAJATI, MAX(salary) AS SALARIU_MAXIM, TO_CHAR(hire_date, 'YYYY') AS AN
FROM employees
GROUP BY TO_CHAR(hire_date, 'YYYY')
/

