create package body ab_package is
    procedure employee(p_job_id employees.job_id%type) is
    begin
        for rec in (select employee_id, last_name, first_name
                    from employees
                    where lower(job_id) = lower(p_job_id))
        loop
            dbms_output.put_line(rec.last_name || ' ' || rec.first_name || ' ' || rec.employee_id);
        end loop;
    end employee;

    procedure employee(p_an varchar2) is
    begin
        for rec in (select last_name, first_name, employee_id
                    from employees
                    where to_char(hire_date, 'YYYY') = p_an)
        loop
            dbms_output.put_line(rec.last_name || ' ' || rec.first_name || ' ' || rec.employee_id);
        end loop;
    end employee;
end ab_package;
/

