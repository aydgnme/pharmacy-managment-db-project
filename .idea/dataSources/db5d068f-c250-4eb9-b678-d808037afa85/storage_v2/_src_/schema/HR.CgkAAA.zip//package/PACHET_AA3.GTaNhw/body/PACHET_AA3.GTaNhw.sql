create PACKAGE BODY pachet_aa3 IS
PROCEDURE angajatlitera(litera VARCHAR2) IS
BEGIN
for i in (select last_name,first_name from aa_emp where substr(last_name,1,1) = UPPER(litera)) LOOP
DBMS_OUTPUT.PUT_LINE(i.last_name||' '||i.first_name);
END LOOP;
END angajatlitera;
PROCEDURE angajatjob(nume aa_emp.last_name%TYPE, prenume aa_emp.first_name%TYPE) IS
jobangajat aa_emp.job_id%TYPE;
BEGIN
select job_id into jobangajat from aa_emp where last_name = nume and first_name = prenume;
for i in(select last_name,first_name from aa_emp where job_id = jobangajat) LOOP
DBMS_OUTPUT.PUT_LINE('');
END LOOP;
END angajatjob;
PROCEDURE angajatsalariumare IS
salariumediu aa_emp.salary%TYPE;
BEGIN
SELECT AVG(salary) into salariumediu from aa_emp;
for i in (select last_name,first_name from aa_emp where salary > salariumediu) LOOP
DBMS_OUTPUT.PUT_LINE('');
END LOOP;
END angajatsalariumare;
END pachet_aa3;
/

