create FUNCTION get_count_emp(p_job_id employees.job_id%TYPE) RETURN NUMBER IS

    v_count employees.job_id%TYPE;

BEGIN

    SELECT COUNT(*) INTO v_count

    FROM employees

    WHERE job_id = p_job_id;

    RETURN v_count;

EXCEPTION

    WHEN NO_DATA_FOUND THEN

        RETURN 0;

END get_count_emp;



/

