create FUNCTION f100(id employees.employee_id%type) RETURN VARCHAR2 IS
v_email employees.email%type;
BEGIN
select email into v_email
from employees
where employee_id = id;

return v_email;
END f100;
/

