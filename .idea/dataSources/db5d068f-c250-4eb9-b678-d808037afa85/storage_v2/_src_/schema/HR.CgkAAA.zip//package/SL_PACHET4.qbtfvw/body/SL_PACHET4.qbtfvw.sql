create PACKAGE BODY SL_PACHET4 IS
    PROCEDURE ADD_DEP(DEP_ID SL_DEP.DEPARTMENT_ID%TYPE, DEP_NAME SL_DEP.DEPARTMENT_NAME%TYPE, MNG_ID SL_DEP.MANAGER_ID%TYPE, LOC_ID SL_DEP.LOCATION_ID%TYPE) IS
    BEGIN
        BEGIN
            INSERT INTO SL_DEP VALUES(DEP_ID, DEP_NAME, MNG_ID, LOC_ID);
            DBMS_OUTPUT.PUT_LINE('A fost adaugat cu succes departamentul cu ID-ul ' || DEP_ID);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
                DBMS_OUTPUT.PUT_LINE('Eroare: Departamentul cu ID-ul ' || DEP_ID || ' deja exista in tabel.');
        END;
    END ADD_DEP;

    PROCEDURE MODIF_DEP(DEP_ID SL_DEP.DEPARTMENT_ID%TYPE, DEP_NAME SL_DEP.DEPARTMENT_NAME%TYPE) IS
    exista_dep NUMBER :=0;
    BEGIN
            SELECT count(*) into exista_dep FROM SL_DEP WHERE DEPARTMENT_ID = DEP_ID;
        IF exista_dep = 0 THEN
              RAISE NO_DATA_FOUND;
        END IF;
            UPDATE SL_DEP
            SET DEPARTMENT_NAME = DEP_NAME
            WHERE DEPARTMENT_ID = DEP_ID;
            DBMS_OUTPUT.PUT_LINE('A fost actualizat cu succes departamentul cu ID-ul ' || DEP_ID);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE('Eroare: Nu exista departamentul cu ID-ul ' || DEP_ID);
    END MODIF_DEP;

    PROCEDURE DEL_DEP(DEP_ID SL_DEP.DEPARTMENT_ID%TYPE) IS
    exista_dep NUMBER :=0;
    BEGIN
        SELECT count(*) into  exista_dep FROM SL_DEP WHERE DEPARTMENT_ID = DEP_ID;
        IF exista_dep = 0 THEN
              RAISE NO_DATA_FOUND;
        END IF;
        DELETE FROM SL_DEP WHERE DEPARTMENT_ID = DEP_ID;
        DBMS_OUTPUT.PUT_LINE('A fost sters cu succes departamentul cu ID-ul ' || DEP_ID);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE('Eroare: Nu exista departamentul cu ID-ul ' || DEP_ID);
    END DEL_DEP;

FUNCTION GET_DEP(DEP_ID SL_DEP.DEPARTMENT_ID%TYPE) RETURN SL_DEP.DEPARTMENT_NAME%TYPE IS
        NUME_DEP SL_DEP.DEPARTMENT_NAME%TYPE;
    BEGIN
        BEGIN
            SELECT DEPARTMENT_NAME INTO NUME_DEP FROM SL_DEP WHERE DEPARTMENT_ID = DEP_ID;
            RETURN NUME_DEP;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RETURN NULL;
        END;
    END GET_DEP;
END SL_PACHET4;
/

