create package body pachet_am is



function nrAng(dep_id number)

return number

is

nr_emp number;

begin

select count(employee_id)

into nr_emp

from employees

where department_id=dep_id

group by department_id;

return nr_emp;

end nrAng;





procedure numeDep(dep_id number)

is

dep_name departments.department_name%type;

begin

select department_name into dep_name

from departments

where department_id=dep_id;



begin



dbms_output.put_line('Nume departament: '|| dep_name);



end;



end numeDep;



end pachet_am;
/

