create FUNCTION functiecomision(nume aa_emp.last_name%TYPE,prenume aa_emp.first_name%TYPE)

RETURN number

IS

com aa_emp.commission_pct%TYPE;

BEGIN

SELECT commission_pct into com from aa_emp where last_name = nume and first_name = prenume;

IF com is null THEN

DBMS_OUTPUT.PUT_LINE('Angajatul nu are comision');

ELSE

DBMS_OUTPUT.PUT_LINE('Angajatul are: '||com||' puncte comision');

END IF;

return com;

END functiecomision;
/

