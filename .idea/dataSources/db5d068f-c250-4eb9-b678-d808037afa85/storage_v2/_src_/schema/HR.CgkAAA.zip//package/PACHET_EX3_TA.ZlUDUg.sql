create package pachet_ex3_TA IS
  FUNCTION GETaNaNGAJARE(EMPLOYEE_ID EMPLOYEE_ID%type)
  RETURN DATE;
  PROCEDURE AFISaNaNGAJARE(employee_id employees.employee_id%TYPE);
end pachet_ex3_TA ;
/

