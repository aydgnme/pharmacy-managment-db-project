create FUNCTION f1(f_an in employees.hire_date%TYPE)

RETURN NUMBER IS

   v_sal number(8,2);

BEGIN

   select MAX(salary) into v_sal

   from employees

   where TO_CHAR(hire_date,'YYYY') = TO_CHAR(f_an,'YYYY');



   RETURN v_sal;

END f1;
/

