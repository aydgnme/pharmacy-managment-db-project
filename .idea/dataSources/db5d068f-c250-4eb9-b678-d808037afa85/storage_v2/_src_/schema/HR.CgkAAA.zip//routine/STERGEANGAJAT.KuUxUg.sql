create procedure stergeAngajat
 is
  vechime employees.hire_date%TYPE;

begin
   select max(employees_hire_date) into vechime
   from employees_FINAL;


 show errors;

    Exception
    when others then

    dbms_output.put_line('EROARE');

   end;
/

