create function year_ang(p_employee_id in number) return number is
v_year_a number;
begin
select extract(year from hire_date) into v_year_a
from employees
where employee_id = p_employee_id;

return v_year_a;
exception
when no_data_found then
return null;
end;
/

