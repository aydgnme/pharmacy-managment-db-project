create PACKAGE CB_pachet1 IS
FUNCTION medSalDep(dep departments.department_id%TYPE)
RETURN NUMBER;
FUNCTION medSalAn(date1 number)
RETURN NUMBER;
function medSal
return number;


END CB_pachet1;
/

