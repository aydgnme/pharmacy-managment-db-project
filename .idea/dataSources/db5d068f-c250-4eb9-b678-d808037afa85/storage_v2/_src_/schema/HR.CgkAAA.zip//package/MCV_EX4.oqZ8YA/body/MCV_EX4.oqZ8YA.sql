create PACKAGE BODY mcv_ex4 AS
 PROCEDURE ADD_DEP(id mcv_dep.department_id%TYPE, nume mcv_dep.department_name%TYPE)IS
 BEGIN
  INSERT INTO mcv_dep(department_id, department_name) VALUES (id,nume);
 END ADD_DEP;

 PROCEDURE MODIF_DEP(id mcv_dep.department_id%TYPE, nume mcv_dep.department_name%TYPE) IS
 BEGIN
  UPDATE mcv_dep SET department_name = nume WHERE department_id = id;
 END MODIF_DEP;

 PROCEDURE DEL_DEP(id mcv_dep.department_id%TYPE) IS
 BEGIN
  DELETE mcv_dep WHERE department_id = id;
 END DEL_DEP;

 FUNCTION GET_DEP(id mcv_dep.department_id%TYPE) RETURN varchar2
 IS
  denumire VARCHAR2(50);
  BEGIN
 SELECT department_name INTO denumire FROM mcv_dep WHERE department_id = id;
  RETURN denumire;
 END GET_DEP;
END mcv_ex4;
/

