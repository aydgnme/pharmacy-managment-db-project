create procedure  pdd_proced
is update;
--declare
--v_dep_id departments_pdd.department_id%type;
begin


end;

/

