create procedure p7(id employees.employee_id%type) is
nume employees.last_name%type;
begin
select last_name into nume from employees
where employee_id=id;
dbms_output.put_line(nume);
end p7;
/

