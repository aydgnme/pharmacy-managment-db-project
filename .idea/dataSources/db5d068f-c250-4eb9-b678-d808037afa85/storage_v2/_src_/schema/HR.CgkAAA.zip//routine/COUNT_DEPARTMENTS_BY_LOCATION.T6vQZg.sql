create FUNCTION count_departments_by_location(
    v_location_id IN NUMBER
) RETURN NUMBER IS
    v_department_count NUMBER;
BEGIN

    SELECT COUNT(*)
    INTO v_department_count
    FROM departments
    WHERE location_id = v_location_id;


    RETURN v_department_count;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
END;
/

