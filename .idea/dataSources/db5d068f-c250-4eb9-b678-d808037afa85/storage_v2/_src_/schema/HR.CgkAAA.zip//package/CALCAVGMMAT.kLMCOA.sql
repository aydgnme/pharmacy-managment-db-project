create PACKAGE calcAvgMMAT IS
  FUNCTION avgYearMMAT(emp_hd employees.hire_date%type) RETURN NUMBER;
  FUNCTION avgDepMMAT(emp_di employees.department_id%type) RETURN NUMBER;
  FUNCTION avgMMAT RETURN NUMBER;
END calcAvgMMAT;
/

