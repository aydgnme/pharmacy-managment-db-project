create PROCEDURE gata IS
  CURSOR sume IS
    SELECT salary, last_name
    FROM employees
    WHERE salary < 9000;

  contor sume%ROWTYPE;

  nr NUMBER(10) := 0;

BEGIN
  OPEN sume;
  while true
  LOOP
    FETCH sume INTO contor;
    EXIT WHEN sume%NOTFOUND;
    nr := nr + contor.salary;
  END LOOP;
  CLOSE sume;
  DBMS_OUTPUT.PUT_LINE('Suma salariilor mai mici de 9000 este ' || nr);
END;
/

