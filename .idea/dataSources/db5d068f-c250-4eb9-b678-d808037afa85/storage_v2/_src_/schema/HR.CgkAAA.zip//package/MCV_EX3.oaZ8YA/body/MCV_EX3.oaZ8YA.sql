create PACKAGE BODY MCV_ex3 IS
  PROCEDURE afis_litera(nume mcv_emp.last_name%TYPE) IS
  BEGIN
    FOR emp IN (SELECT * FROM mcv_emp WHERE UPPER(SUBSTR(last_name, 1, 1)) = UPPER(nume)) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name);
    END LOOP;
  END afis_litera;

  PROCEDURE acelasi_job(nume mcv_emp.last_name%TYPE, prenume mcv_emp.first_name%TYPE) IS
    v_job mcv_emp.job_id%TYPE;
  BEGIN
    SELECT job_id INTO v_job FROM mcv_emp WHERE last_name = nume AND first_name = prenume;
    FOR emp IN (SELECT * FROM mcv_emp WHERE job_id = v_job) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name);
    END LOOP;
  END acelasi_job;

 PROCEDURE salar_mare IS
  v_avg_salary NUMBER;
 BEGIN
 SELECT AVG(salary) INTO v_avg_salary FROM Employees;
 FOR emp IN (SELECT * from EMPLOYEES WHERE SALARY > V_AVG_SALARY) LOOP
  DBMS_OUTPUT.PUT_LINE(emp.FIRST_NAME ||''|| emp.LAST_NAME);
 END LOOP;
 END SALAR_MARE;

END mcv_ex3;
/

