create PACKAGE BODY CF_pachet3 IS

PROCEDURE angajatiLitera(litera CHAR) IS
  e_nume employees.last_name%TYPE;
  e_prenume employees.first_name%TYPE;
  CURSOR c_ang IS
      SELECT last_name, first_name FROM Employees WHERE last_name LIKE litera || '%';
BEGIN
  OPEN c_ang;
  FETCH c_ang INTO e_nume, e_prenume;
  WHILE c_ang%FOUND LOOP
    DBMS_OUTPUT.PUT_LINE(e_nume || ' ' || e_prenume);
    FETCH c_ang INTO e_nume, e_prenume;
  END LOOP;
END angajatiLitera;

PROCEDURE angajatiJob(eNume employees.last_name%TYPE, ePrenume employees.first_name%TYPE) IS
v_job employees.job_id%TYPE;
  BEGIN
    SELECT job_id INTO v_job
    FROM Employees
    WHERE first_name = ePrenume AND last_name = eNume;

    FOR emp IN (SELECT * FROM Employees WHERE job_id = v_job) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.last_name || ' ' || emp.first_name);
    END LOOP;

END angajatiJob;

PROCEDURE salariuMediu IS
v_salary NUMBER;
  BEGIN
    SELECT AVG(salary) INTO v_salary FROM Employees;

    FOR emp IN (SELECT * FROM Employees WHERE salary > v_salary) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.last_name || ' ' || emp.first_name);
    END LOOP;

END salariuMediu;

END CF_pachet3;
/

