create package body
hl_pachet1 is
FUNCTION medieDep(dep_id
departments.department_id%TYPE)
RETURN NUMBER
is
medie NUMBER;
BEGIN
SELECT AVG(salary) INTO medie FROM
employees
where department_id=dep_id;
if medie is null then
return -1
else
return medie;
end if;
end medieDep; /

