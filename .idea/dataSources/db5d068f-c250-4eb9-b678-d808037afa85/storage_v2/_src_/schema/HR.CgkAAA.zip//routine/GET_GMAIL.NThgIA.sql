create FUNCTION GET_GMAIL(
    v_id PSM_EMPLOYEES.Employee_ID%TYPE
) RETURN VARCHAR2
IS
    v_gmail VARCHAR2(100);
BEGIN
    SELECT Email INTO v_gmail
    FROM PSM_EMPLOYEES
    WHERE Employee_ID = v_id;

    RETURN v_gmail;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error');
END;
/

