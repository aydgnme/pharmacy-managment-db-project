create PACKAGE pachet_aa4 IS
PROCEDURE add_dep(depid aa_dep.department_id%TYPE,numedep aa_dep.department_name%TYPE,manid aa_dep.manager_id%TYPE,locid aa_dep.location_id%TYPE);
PROCEDURE modif_dep(depid aa_dep.department_id%TYPE, numedep aa_dep.department_name%TYPE);
PROCEDURE del_dep(depid aa_dep.department_id%TYPE);
FUNCTION get_dep( depid aa_dep.department_id%TYPE) RETURN aa_dep.department_name%TYPE;
END pachet_aa4;
/

