create PACKAGE mcv_ex2 IS
  FUNCTION get_nume(id mcv_emp.employee_id%TYPE) RETURN VARCHAR2;
  FUNCTION get_salary(id mcv_emp.employee_id%TYPE) RETURN NUMBER;
  FUNCTION get_email(id mcv_emp.employee_id%TYPE) RETURN VARCHAR2;
  FUNCTION get_hire_date(id mcv_emp.employee_id%TYPE) RETURN DATE;
END mcv_ex2;
/

