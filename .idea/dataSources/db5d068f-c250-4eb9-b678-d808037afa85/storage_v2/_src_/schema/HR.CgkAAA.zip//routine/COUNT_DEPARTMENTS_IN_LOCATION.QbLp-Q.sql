create FUNCTION count_departments_in_location(location_id IN NUMBER)
RETURN NUMBER
IS
    v_department_count NUMBER;
BEGIN

    v_department_count := 0;


    FOR department_rec IN (
        SELECT department_id
        FROM departments
        WHERE location_id = location_id
    )
    LOOP

        v_department_count := v_department_count + 1;
    END LOOP;


    RETURN v_department_count;
END;
/

