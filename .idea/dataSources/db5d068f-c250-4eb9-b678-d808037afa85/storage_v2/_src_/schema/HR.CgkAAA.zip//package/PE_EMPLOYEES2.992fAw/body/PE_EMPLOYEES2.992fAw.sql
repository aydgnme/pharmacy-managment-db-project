create PACKAGE BODY pe_employees2 AS

  PROCEDURE displayEmployeesByInital(emp_inital IN CHAR) IS
  BEGIN
    FOR r IN (SELECT first_name, last_name FROM employees WHERE first_name LIKE emp_inital || '%') LOOP
      DBMS_OUTPUT.PUT_LINE(r.first_name || ' ' || r.last_name);
    END LOOP;
  END displayEmployeesByInital;

  PROCEDURE displayEmployeesByJob(emp_name IN VARCHAR2) IS
    v_job_id employees.job_id%TYPE;
  BEGIN

    SELECT job_id INTO v_job_id FROM employees WHERE first_name = emp_name OR last_name = emp_name AND rownum = 1;


    FOR r IN (SELECT first_name, last_name FROM employees WHERE job_id = v_job_id) LOOP
      DBMS_OUTPUT.PUT_LINE(r.first_name || ' ' || r.last_name);
    END LOOP;
  END displayEmployeesByJob;

PROCEDURE employeesAboveAverage IS
    v_salariu_mediu NUMBER;
  BEGIN

    SELECT AVG(salary) INTO v_salariu_mediu FROM employees;


    FOR r IN (SELECT first_name, last_name, salary FROM employees WHERE salary > v_salariu_mediu) LOOP
      DBMS_OUTPUT.PUT_LINE(r.first_name || ' ' || r.last_name || ' - Salariu: ' || r.salary);
    END LOOP;
  END employeesAboveAverage;


END pe_employees2 ;
/

