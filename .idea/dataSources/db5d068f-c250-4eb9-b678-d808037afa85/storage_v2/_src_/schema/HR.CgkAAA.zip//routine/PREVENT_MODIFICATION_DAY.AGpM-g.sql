create FUNCTION prevent_modification_day()
RETURNS TRIGGER AS $$
BEGIN
  IF EXTRACT(DOW FROM CURRENT_DATE) = 2 THEN
    RAISE EXCEPTION 'Modificarile nu sunt permise în ziua de laborator!';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;



/

