create procedure  pcd_proced
is update;
declare
v_dep departments_pdd.department_name%type;
function fct (v_id_ang employees_pdd.employee_id%type)
as number;

begin
procedure pcd_proced;
Update departments_pdd
set department_name=v_dep;
end pcd_proced;

end;
/show errors;
/

