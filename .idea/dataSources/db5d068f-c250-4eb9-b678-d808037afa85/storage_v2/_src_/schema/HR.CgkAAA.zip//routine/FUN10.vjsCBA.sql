create function fun10(id departments.location_id%type)

return number is

numar number;

begin

select count(department_id) into numar

from departments

where location_id=id;

return numar;

end fun10;
/

