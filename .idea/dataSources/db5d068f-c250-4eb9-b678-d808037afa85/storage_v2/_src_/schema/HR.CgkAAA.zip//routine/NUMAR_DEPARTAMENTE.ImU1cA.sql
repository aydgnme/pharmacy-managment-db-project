create function numar_departamente(location_id number) return number is
v_numar_dep number;

begin

v_numar_dep :=0;

for department_rec in(
select department_id
from departments
where location_id = location_id) loop
v_numar_dep := v_numar_dep +1;
end loop;
return v_numar_dep;
end;
/

