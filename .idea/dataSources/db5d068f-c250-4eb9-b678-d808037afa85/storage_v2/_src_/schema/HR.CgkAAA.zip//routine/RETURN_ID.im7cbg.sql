create function return_id(v_nume employees.last_name%type, v_prenume employees.first_name%type)
return number is
v_id employees.employee_id%type;
begin
select employee_id into v_id from employees
where first_name = v_prenume and last_name=v_nume;
return v_id;
end return_id;
/

