create PACKAGE SM_EX2 IS
  FUNCTION nume_complet(identificator employees.employee_id%TYPE)
   RETURN varchar2;
  FUNCTION salariu(identificator employees.employee_id%TYPE)
   RETURN number;
  FUNCTION email(identificator employees.employee_id%TYPE)
   RETURN varchar2;
  FUNCTION data_angajari(identificator employees.employee_id%TYPE)
   RETURN date;
END SM_EX2;
#ALTER PACKAGE SM_ex2 COMPILE package




CREATE OR REPLACE PACKAGE BODY SM_ex2 AS
  FUNCTION nume_complet(identificator employees.employee_id%TYPE) RETURN varchar2 IS
    nume varchar2(50);
  BEGIN
    SELECT first_name || ' ' || last_name INTO nume FROM Employees
    WHERE employee_id = identificator;
    RETURN nume;
  END nume_complet;

  FUNCTION salariu(identificator employees.employee_id%TYPE) RETURN number IS
    salariu_valoare NUMBER;
  BEGIN
    SELECT salary INTO salariu_valoare FROM Employees
    WHERE employee_id = identificator;
    RETURN salariu_valoare;
  END salariu;

  FUNCTION email(identificator employees.employee_id%TYPE) RETURN varchar2 IS
    posta_electronica VARCHAR2(50);
  BEGIN
    SELECT email INTO posta_electronica FROM Employees
    WHERE employee_id = identificator;
    RETURN posta_electronica;
  END email;

  FUNCTION data_angajari(identificator employees.employee_id%TYPE) RETURN date IS
    returneaza_data DATE;
  BEGIN
    SELECT hire_date INTO returneaza_data FROM Employees
    WHERE Employee_id = identificator;
    RETURN returneaza_data;
  END data_angajari;
END SM_ex2;
/

