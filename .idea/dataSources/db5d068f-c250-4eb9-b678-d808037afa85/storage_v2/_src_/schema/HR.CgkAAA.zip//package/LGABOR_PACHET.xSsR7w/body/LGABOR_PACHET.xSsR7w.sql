create PACKAGE BODY lgabor_pachet IS

 FUNCTION f1(id IN departments.department_id%TYPE) RETURN NUMBER

  IS

   v_nr NUMBER;

 BEGIN

  SELECT COUNT(*) INTO v_nr FROM employees WHERE department_id = id;

  RETURN v_nr;

 END f1;



 PROCEDURE p1(id IN departments.department_id%TYPE) IS

  v_nume departments.department_name%TYPE;

 BEGIN

  SELECT department_name INTO v_nume FROM departments WHERE department_id = id;

  DBMS_OUTPUT.PUT_LINE('Departamentul ' || id || ' are numele: '|| v_nume);

 END p1;

END;

/

