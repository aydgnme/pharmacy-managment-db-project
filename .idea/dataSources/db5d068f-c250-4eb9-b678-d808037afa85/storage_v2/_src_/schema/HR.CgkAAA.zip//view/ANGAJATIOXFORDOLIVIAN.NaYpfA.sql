create view ANGAJATIOXFORDOLIVIAN as
select e.employee_id, e.last_name, e.first_name, d.department_id, l.city
from employees e, departments d, locations l
where e.department_id=d.department_id and d.location_id=l.location_id and l.city like '%London%'
/

