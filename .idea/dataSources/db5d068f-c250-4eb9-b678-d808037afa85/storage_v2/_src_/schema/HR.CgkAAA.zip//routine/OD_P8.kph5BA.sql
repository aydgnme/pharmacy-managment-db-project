create PROCEDURE OD_P8( p_an NUMBER)
IS
 p_nr number;
BEGIN

  DELETE FROM OD_Angajati
   WHERE to_char(hire_date,'yyyy') = p_an;

   SELECT COUNT(*) INTO p_nr
    FROM OD_Angajati
    WHERE to_char(hire_date,'yyyy') = p_an;

 dbms_output.put_line('Nr de persoane angajate sterse sunt: '||p_nr);

exception
 when no_data_found then
 dbms_output.put_line('Nu exista angajati cu anul angajarii '|| p_an);
 when others then
  dbms_output.put_line('Eroare');
end od_p8;
/

