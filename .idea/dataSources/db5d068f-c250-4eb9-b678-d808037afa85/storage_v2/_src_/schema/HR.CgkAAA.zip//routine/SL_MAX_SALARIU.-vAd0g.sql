create FUNCTION SL_MAX_SALARIU (an NUMBER) RETURN NUMBER IS

    max_salary NUMBER;

    counter_emp NUMBER:=0;

BEGIN

    SELECT COUNT(employee_id) into counter_emp from employees where TO_CHAR(HIRE_DATE,'YYYY') = an;

    IF counter_emp = 0 THEN

        RETURN -1;

    END IF;

    SELECT MAX(SALARY) INTO max_salary FROM employees WHERE TO_CHAR(HIRE_DATE,'YYYY') = an;

    RETURN max_salary;



END SL_MAX_SALARIU;
/

