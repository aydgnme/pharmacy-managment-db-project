create FUNCTION maxSal(p_date varchar2)

RETURN NUMBER

IS

v_maxSalary Employees.Salary%Type;

Begin



Select MAX(Salary)

INTO v_maxSalary

From Employees

Where To_Char(Hire_Date,'YY') = To_Char(Hire_Date,'YY');

return v_maxSalary;



END maxSal;
/

