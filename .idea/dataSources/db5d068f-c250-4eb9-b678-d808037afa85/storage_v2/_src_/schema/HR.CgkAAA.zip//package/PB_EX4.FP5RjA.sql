create PACKAGE PB_EX4 IS

PROCEDURE ADD_DEP(nume VARCHAR2);
PROCEDURE MODIF_DEP(v_nume Departments.department_name%TYPE, v_nume_nou Departments.department_name%TYPE);
PROCEDURE DEL_DEP(v_nume Departments.department_name%TYPE);
FUNCTION GET_DEP(v_cod Departments.department_id%TYPE) RETURN VARCHAR2;
END PB_EX4;
/

