create FUNCTION informatii(dep IN employees.department_id%TYPE)
RETURN NUMBER IS
  nr NUMBER(2);
BEGIN
  SELECT COUNT(employee_id) INTO nr
  FROM employees
  WHERE department_id = dep;
  RETURN nr;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN -1;
WHEN TOO_MANY_ROWS THEN
RETURN -2;
WHEN OTHERS THEN

RETURN -3;

END informatii;
/

