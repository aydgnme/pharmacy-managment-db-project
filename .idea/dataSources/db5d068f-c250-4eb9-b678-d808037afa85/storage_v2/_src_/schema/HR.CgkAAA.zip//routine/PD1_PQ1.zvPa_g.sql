create procedure  pd1_pq1 on;



declare



v_dep departments_pdd.department_name%type;

begin



v_dep:='Dep_nou';

procedure pd1_pq;

Update departments_pdd

set department_name=v_dep;

 end pd1_pq;

end;

show errors;
/

