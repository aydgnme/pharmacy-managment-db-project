create PACKAGE mg_pachet2 IS
 FUNCTION empName(emp_id employees.employee_id%TYPE)
 RETURN VARCHAR2;

 FUNCTION empSalary(emp_id employees.employee_id%TYPE)
 RETURN NUMBER;

 FUNCTION empEmail(emp_id employees.employee_id%TYPE)
 RETURN VARCHAR2;

 FUNCTION empHireDate(emp_id employees.employee_id%TYPE)
 RETURN NUMBER;
END mg_pachet2;

CREATE OR REPLACE PACKAGE BODY mg_pachet2 IS
 FUNCTION empName(emp_id employees.employee_id%TYPE)
  RETURN VARCHAR2
  IS
  nume VARCHAR2(100);
  BEGIN
  SELECT first_name ||' '|| last_name INTO nume FROM employees
  WHERE employee_id = emp_id;
  RETURN nume;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN -1;
 END empName;

 FUNCTION empSalary(emp_id employees.employee_id%TYPE)
  RETURN NUMBER
  IS
  salariu NUMBER;
  BEGIN
  SELECT salary INTO salariu FROM employees
  WHERE employee_id = emp_id;
  RETURN salariu;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN -1;
 END empSalary;

 FUNCTION empEmail(emp_id employees.employee_id%TYPE)
  RETURN VARCHAR2
  IS
  emp_email VARCHAR2(100);
  BEGIN
  SELECT email INTO emp_email FROM employees
  WHERE employee_id = emp_id;
  RETURN emp_email;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN -1;
 END empEmail;

 FUNCTION empHireDate(emp_id employees.employee_id%TYPE)
  RETURN NUMBER
  IS
  an NUMBER;
  BEGIN
  SELECT EXTRACT (YEAR FROM hire_date) INTO an FROM employees
  WHERE employee_id = emp_id;
  RETURN an;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN -1;
 END empHireDate;
END mg_pachet2;
/

