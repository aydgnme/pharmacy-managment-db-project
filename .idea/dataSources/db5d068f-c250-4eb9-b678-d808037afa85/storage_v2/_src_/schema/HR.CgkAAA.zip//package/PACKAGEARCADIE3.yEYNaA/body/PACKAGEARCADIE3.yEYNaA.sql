create PACKAGE BODY packageArcadie3 AS
    PROCEDURE display_employees_by_initial(p_initial CHAR) IS
    BEGIN
        FOR emp IN (SELECT * FROM employees WHERE SUBSTR(last_name, 1, 1) = p_initial) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || emp.last_name || ', Prenume: ' || emp.first_name);
        END LOOP;
    END display_employees_by_initial;

    PROCEDURE display_employees_same_job(p_first_name VARCHAR2, p_last_name VARCHAR2) IS
        v_job_id employees.job_id%TYPE;
    BEGIN
        SELECT job_id INTO v_job_id
        FROM employees
        WHERE first_name = p_first_name AND last_name = p_last_name;

        FOR emp IN (SELECT * FROM employees WHERE job_id = v_job_id) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || emp.last_name || ', Prenume: ' || emp.first_name);
        END LOOP;
    END display_employees_same_job;

    PROCEDURE display_employees_above_avg IS
        v_avg_salary NUMBER;
    BEGIN
        SELECT AVG(salary) INTO v_avg_salary FROM employees;
        FOR emp IN (SELECT * FROM employees WHERE salary > v_avg_salary) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || emp.last_name || ', Prenume: ' || emp.first_name || ', Salariu: ' || emp.salary);
        END LOOP;
    END display_employees_above_avg;
END packageArcadie3;
/

