create PROCEDURE p3 IS
v_sal_mediu employees.salary%type;
BEGIN
SELECT AVG(salary) INTO v_sal_mediu FROM employees;
DBMS_OUTPUT.PUT_LINE('Salariul mediu este ' || v_sal_mediu);
END p3;
/

