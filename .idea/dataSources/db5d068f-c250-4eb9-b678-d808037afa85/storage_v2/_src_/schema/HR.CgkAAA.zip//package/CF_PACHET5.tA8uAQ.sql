create PACKAGE CF_pachet5 AS

  PROCEDURE afisare_angajati(job employees.job_id%TYPE);
  PROCEDURE afisare_angajati(an NUMBER);

END CF_pachet5;
/

