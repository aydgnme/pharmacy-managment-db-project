create FUNCTION get_employee_id_FTD(p_first_name IN VARCHAR2, p_last_name IN VARCHAR2)
RETURN NUMBER IS
    v_employee_id employees.employee_id%TYPE;
BEGIN
    SELECT employee_id INTO v_employee_id
    FROM employees
    WHERE first_name = p_first_name AND last_name = p_last_name;

    RETURN v_employee_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
    WHEN TOO_MANY_ROWS THEN
        RETURN NULL;
    WHEN OTHERS THEN
        RETURN NULL;
END get_employee_id_FTD;
/

