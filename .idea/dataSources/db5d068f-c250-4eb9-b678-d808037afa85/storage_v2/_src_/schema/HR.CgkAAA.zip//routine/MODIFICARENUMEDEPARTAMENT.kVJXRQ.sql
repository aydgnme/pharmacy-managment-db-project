create PROCEDURE modificareNumeDepartament(

    p_department_id departments_sa.department_id%TYPE,

    p_nume_nou departments_sa.department_name%TYPE



) AS

BEGIN

UPDATE departments_sa

SET department_name = p_nume_nou

WHERE department_id = p_department_id;



COMMIT;



DBMS_OUTPUT.PUT_LINE (' Departamentul cu id-ul' || p_department_id || ' a fost modificat');

EXCEPTION

WHEN NO_DATA_FOUND THEN

DBMS_OUTPUT.PUT_LINE ('Nu a fost gasit nici un departament cu id-ul dat ');

END;
/

