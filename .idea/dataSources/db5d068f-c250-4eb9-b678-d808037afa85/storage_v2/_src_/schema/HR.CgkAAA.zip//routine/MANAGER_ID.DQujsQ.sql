create function manager_id(p_employee_id in number) return number is
v_manager_i number;

begin

select manager_id into v_manager_i
from employees
where manager_id =p_employee_id;

return v_manager_i;
exception
when no_data_found then
return null;
end;
/

