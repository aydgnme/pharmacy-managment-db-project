create PACKAGE pachetAC IS
  FUNCTION avgYear(emp_hd employees.hire_date%type) RETURN NUMBER;
  FUNCTION avgDep(emp_di employees.department_id%type) RETURN NUMBER;
  FUNCTION avgAll RETURN NUMBER;
END pachetAC;
/

