create package body pachet as
    procedure test is
     begin
   end;
  end;
/

