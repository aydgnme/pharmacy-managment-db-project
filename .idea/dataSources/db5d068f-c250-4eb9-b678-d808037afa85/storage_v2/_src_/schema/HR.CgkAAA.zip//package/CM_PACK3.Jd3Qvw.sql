create PACKAGE CM_pack3 IS
PROCEDURE selectForLetter(letter VARCHAR2);
PROCEDURE selectForJob(nume VARCHAR2, prenume VARCHAR2);
PROCEDURE selectForSalaryGreaterThanAvg;
END CM_pack3;
/

