create PACKAGE BODY PB_EX1 IS


FUNCTION AVG_DEPARTAMENT(dep_name IN Departments.department_name%TYPE) RETURN NUMBER IS
avgg NUMBER;
v_dep_name Departments.department_name%TYPE;
BEGIN
SELECT department_name INTO v_dep_name FROM Departments WHERE department_name = dep_name;
SELECT AVG(salary) INTO avgg FROM Employees e JOIN Departments d ON e.department_id = d.department_id WHERE d.department_name = dep_name;
RETURN avgg;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Nu exista departament cu numele ' || dep_name);
        RETURN NULL;


END AVG_DEPARTAMENT;


FUNCTION AVG_EMPLOYEES RETURN NUMBER IS
avgg NUMBER;
BEGIN
SELECT AVG(salary) INTO avgg FROM Employees;
RETURN avgg;
END AVG_EMPLOYEES;

FUNCTION AVG_FROM_YEAR(year VARCHAR2) RETURN NUMBER
IS avgg NUMBER;
BEGIN

SELECT AVG(salary) INTO avgg FROM Employees WHERE TO_CHAR(hire_date, 'YYYY') = year;

IF avgg IS NULL THEN
RAISE NO_DATA_FOUND
END IF;

RETURN avgg;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Nu exista angajati din acest an ' || year);
        RETURN NULL;

END AVG_FROM_YEAR;


END PB_EX1;

/

