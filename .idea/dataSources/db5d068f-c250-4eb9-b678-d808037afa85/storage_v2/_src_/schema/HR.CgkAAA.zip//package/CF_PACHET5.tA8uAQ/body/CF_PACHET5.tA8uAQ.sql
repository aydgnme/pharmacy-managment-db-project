create PACKAGE BODY CF_pachet5 IS

  PROCEDURE afisare_angajati(job employees.job_id%TYPE) IS
  BEGIN
    FOR emp IN (SELECT employee_id, last_name, first_name FROM Employees WHERE job_id = job) LOOP
      DBMS_OUTPUT.PUT_LINE('Id: ' || emp.employee_id || ' Nume: ' || emp.last_name || ' Prenume: ' || emp.first_name);
    END LOOP;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Nu exista angajati cu job_id-ul specificat.');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('A aparut o eroare in timpul afisarii angajatilor cu job_id-ul specificat.');
  END afisare_angajati;

  PROCEDURE afisare_angajati(an NUMBER) IS
  BEGIN
    FOR emp IN (SELECT employee_id, last_name, first_name FROM Employees WHERE TO_CHAR(hire_date, 'YYYY') = TO_CHAR(an)) LOOP
      DBMS_OUTPUT.PUT_LINE('Id: ' || emp.employee_id || ' Nume: ' || emp.last_name || ' Prenume: ' || emp.first_name);
    END LOOP;
  END afisare_angajati;

END CF_pachet5;
/

