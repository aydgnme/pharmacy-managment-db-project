create FUNCTION count_departments(
    p_location_id IN NUMBER
) RETURN NUMBER IS
    v_dep_count NUMBER := 0;
BEGIN

    SELECT COUNT(*)
    INTO v_dep_count
    FROM departments
    WHERE location_id = p_location_id;


    RETURN v_dep_count;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
END;
/

