create PACKAGE BODY PB_EX5 IS

PROCEDURE AFISEAZA(v_job Employees.job_id%TYPE) IS
BEGIN
FOR angajat IN (SELECT * FROM Employees WHERE job_id = v_job) LOOP
DBMS_OUTPUT.PUT_LINE(angajat.first_name || ' ' || angajat.last_name);
END LOOP;
END AFISEAZA;




PROCEDURE AFISEAZA(v_an NUMBER) IS
BEGIN
FOR angajat in (SELECT * FROM Employees WHERE TO_CHAR(hire_date, 'YYYY') = TO_CHAR(v_an)) LOOP
DBMS_OUTPUT.PUT_LINE(angajat.first_name || ' ' || angajat.last_name);
END LOOP;
END AFISEAZA;



END PB_EX5;
/

