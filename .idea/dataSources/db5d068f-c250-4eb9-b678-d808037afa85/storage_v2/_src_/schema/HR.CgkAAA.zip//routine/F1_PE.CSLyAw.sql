create FUNCTION f1_pe  (fname employees.FIRST_NAME%TYPE, lname employees.LAST_NAME%TYPE) RETURN NUMBER  IS

cms_point employees.COMMISSION_PCT%type;

begin

 select COMMISSION_PCT into cms_point from employees

 where first_name = fname and last_name= lname;



 if cms_point is Null then

	return 0;

 end if;



 return cms_point;

end;
/

