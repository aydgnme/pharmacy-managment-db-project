create PACKAGE pe_employees3 IS
    PROCEDURE displayEmployeesByInitial(initial_char IN VARCHAR2);
    PROCEDURE displayEmployeesByJob(employee_name IN VARCHAR2);
    PROCEDURE displayEmployeesAboveAverageSalary;
END pe_employees3;
/

