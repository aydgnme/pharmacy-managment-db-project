create PACKAGE BODY mcv_pachet1 IS
  FUNCTION medie_salarii_dep(id mcv_dep.department_id%TYPE)
    RETURN NUMBER
  IS
    media NUMBER;
  BEGIN
    SELECT AVG(e.salary) INTO media FROM mcv_emp e WHERE e.department_id = id;
    RETURN media;
  END medie_salarii_dep;

  FUNCTION medie_salarii_toti_an(anul mcv_emp.hire_date%TYPE)
    RETURN NUMBER
  IS
    mediaa NUMBER;
  BEGIN
    SELECT AVG(salary) INTO mediaa FROM mcv_emp WHERE EXTRACT(YEAR FROM hire_date) = anul;
    RETURN mediaa;
  END medie_salarii_toti_an;
END mcv_pachet1;
/

