create PACKAGE aa_package IS

FUNCTION aa_functie(hiredate aa_emp.hire_date%TYPE)

RETURN DATE;

PROCEDURE aa_procedura(salariu aa_emp.salary%TYPE);

end aa_package;
/

