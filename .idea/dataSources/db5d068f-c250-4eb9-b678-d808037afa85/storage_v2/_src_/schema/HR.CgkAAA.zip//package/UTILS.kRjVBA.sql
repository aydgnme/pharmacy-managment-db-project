create PACKAGE utils IS
  FUNCTION mpu(dep in employees.department_id%TYPE)
    RETURN NUMBER;
  FUNCTION mpa
    RETURN NUMBER;
END utils;
/

