create PACKAGE BODY dp_pachet1 IS
FUNCTION numarAngajati(dep departments.department_id%TYPE)
RETURN NUMBER
IS
numar NUMBER;
BEGIN
SELECT COUNT(*) INTO numar FROM employees
WHERE department_id=dep;
RETURN numar;
END numarAngajati;

FUNCTION sumaSalarii(dep departments.department_id%TYPE)
RETURN NUMBER
IS
suma NUMBER;
BEGIN
SELECT SUM(salary+salary*NVL(commission_pct,0)) INTO suma
FROM employees WHERE department_id=dep;
RETURN suma;
END sumaSalarii;
END dp_pachet1;
/

