create package body PACHET1 as
  procedure stergeAngajat is
  select * from employees;
end;
/

