create package sam_pachet2 is

function NumeAng(id employees.employee_id%type)
return varchar2;

function SalAng(id employees.employee_id%type)
return number;

function EmailAng(id employees.employee_id%type)
return varchar2;

function HiredateAng(id employees.employee_id%type)
return date;

end sam_pachet2;
/

