create PACKAGE BODY pe_pachet1 IS
 FUNCTION medieDepartament(dep_id departments.department_id%TYPE)
  RETURN NUMBER
  IS
  medie NUMBER;
  BEGIN
  SELECT AVG(salary) INTO medie FROM employees
  WHERE department_id = dep_id;
  IF medie IS NULL THEN
      RETURN -1;
    ELSE
      RETURN medie;
    END IF;
 END medieDepartament;

 FUNCTION medieAn(an NUMBER)
  RETURN NUMBER
  IS
  medie NUMBER;
  BEGIN
  SELECT AVG(salary) INTO medie FROM employees
  WHERE EXTRACT(YEAR FROM hire_date) = an;
  IF medie IS NULL THEN
      RETURN -1;
    ELSE
      RETURN medie;
    END IF;
 END medieAn;

 FUNCTION medieAngajati
  RETURN NUMBER
  IS
  medie NUMBER;
  BEGIN
  SELECT AVG(salary) INTO medie FROM employees;
  IF medie IS NULL THEN
      RETURN -1;
    ELSE
      RETURN medie;
    END IF;
 END medieAngajati;
END pe_pachet1;
/

