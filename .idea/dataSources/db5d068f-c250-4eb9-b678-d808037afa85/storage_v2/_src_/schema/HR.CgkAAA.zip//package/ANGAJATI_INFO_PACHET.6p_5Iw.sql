create PACKAGE Angajati_Info_pachet IS
    PROCEDURE afisareAngajati(job_in VARCHAR2);
    PROCEDURE afisareAngajati(an_in NUMBER);
END Angajati_Info_pachet;
/

