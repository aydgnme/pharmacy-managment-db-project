create procedure  prd_proced
is update;
--declare
--v_dep_id departments_pdd.department_id%type;
begin
procedure pd_proced;

end pd_proced;

end;
/show errors;
/

