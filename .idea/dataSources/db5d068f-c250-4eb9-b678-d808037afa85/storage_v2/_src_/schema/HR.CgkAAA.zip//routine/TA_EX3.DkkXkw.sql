create function TA_ex3(nume employees.last_name%type ,

                                  prenume employees.first_name%type )

  return jobs.job_title%type

  is

    nume_job jobs.JOB_TITLE%type;

    begin

     SELECT JOB_TITLE into nume_job

     FROM JOBS J, EMPLOYEES E

     WHERE

       j.job_id=e.job_id

     AND FIRST_NAME= prenume

     and last_name = nume;

   return nume_job;

   exception

   when no_data_found then

   return '-1';

end TA_ex3;
/

