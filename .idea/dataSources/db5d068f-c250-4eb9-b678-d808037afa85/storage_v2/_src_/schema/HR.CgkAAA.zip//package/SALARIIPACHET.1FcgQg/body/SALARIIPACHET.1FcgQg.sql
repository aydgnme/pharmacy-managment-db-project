create PACKAGE BODY SalariiPachet IS

  FUNCTION ValoareMedieSalariiDepartament(departament_id NUMBER) RETURN NUMBER IS
    valoare_medie NUMBER;
  BEGIN
    SELECT AVG(salary) INTO valoare_medie
    FROM employees
    WHERE department_id = departament_id;
    RETURN valoare_medie;
  END ValoareMedieSalariiDepartament;

  FUNCTION ValoareMedieSalarii RETURN NUMBER IS
    valoare_medie NUMBER;
  BEGIN
    SELECT AVG(salary) INTO valoare_medie
    FROM employees;
    RETURN valoare_medie;
  END ValoareMedieSalarii;

  FUNCTION ValoareMedieSalariiAnAngajare(an_angajare NUMBER) RETURN NUMBER IS
    valoare_medie NUMBER;
  BEGIN
    SELECT AVG(salary) INTO valoare_medie
    FROM employees
    WHERE EXTRACT(YEAR FROM hire_date) = an_angajare;
    RETURN valoare_medie;
  END ValoareMedieSalariiAnAngajare;

END SalariiPachet;
/

