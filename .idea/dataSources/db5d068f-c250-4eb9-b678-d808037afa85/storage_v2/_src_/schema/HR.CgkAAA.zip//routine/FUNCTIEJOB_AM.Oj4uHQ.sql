create function functieJob_am(nume varchar, prenume varchar)

return varchar

is

job jobs.job_title%type;



begin

select j.job_title into job

from employees e, jobs j

where e.last_name=nume and e.first_name=prenume and e.job_id=j.job_id;

return job;

end functieJob_am;

/

