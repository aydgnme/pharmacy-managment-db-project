create function f6(id number)
return employees.email%type
is
email_u employees.email%type;
begin
select email into email_u from employees where employee_id=id;
return email_u;
exception
when no_data_found then return -1;
end f6;
/

