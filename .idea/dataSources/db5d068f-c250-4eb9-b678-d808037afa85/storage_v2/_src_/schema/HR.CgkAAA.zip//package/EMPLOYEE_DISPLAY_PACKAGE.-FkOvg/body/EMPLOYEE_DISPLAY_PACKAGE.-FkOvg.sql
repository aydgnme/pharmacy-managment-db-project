create PACKAGE BODY EMPLOYEE_DISPLAY_PACKAGE IS

  PROCEDURE DISPLAY_EMPloyees_BY_INITIAL(INITIAL_CHAR IN VARCHAR2) IS
  BEGIN
    FOR emp IN (SELECT * FROM employees WHERE SUBSTR(first_name, 1, 1) = INITIAL_CHAR) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name || ' - ' || emp.job_id);
    END LOOP;
  END DISPLAY_EMPLOYEES_BY_INITIAL;

  PROCEDURE DISPLAY_EMP_WITH_SAME_JOB(FIRST_NAME IN VARCHAR2, LAST_NAME IN VARCHAR2) IS
BEGIN
  FOR emp IN (SELECT * FROM employees WHERE job_id = (select job_id from employees where first_name = FIRST_NAME AND last_name = LAST_NAME)) LOOP
    DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name || ' - ' || emp.job_id);
  END LOOP;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Employee not found.');
END DISPLAY_EMP_WITH_SAME_JOB;


  PROCEDURE DISPLAY_EMP_ABOVE_AVG_SALARY IS
    avg_salary NUMBER;
  BEGIN
    SELECT AVG(salary) INTO avg_salary FROM employees;

    FOR emp IN (SELECT * FROM employees WHERE salary > avg_salary) LOOP
      DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name || ' - ' || emp.salary);
    END LOOP;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('No employees found.');
  END DISPLAY_EMP_ABOVE_AVG_SALARY;

END EMPLOYEE_DISPLAY_PACKAGE;
/

