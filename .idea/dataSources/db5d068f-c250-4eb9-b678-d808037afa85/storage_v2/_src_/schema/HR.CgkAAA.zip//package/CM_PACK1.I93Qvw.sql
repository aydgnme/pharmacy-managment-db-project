create PACKAGE CM_pack1 IS
FUNCTION avgSalForDep(dep departments.department_id%TYPE)
RETURN employees.salary%TYPE;
FUNCTION avgSalForAll
RETURN employees.salary%TYPE;
FUNCTION avgSalForHireDate(v_hire_date employees.hire_date%TYPE)
RETURN employees.salary%TYPE;
END CM_pack1;
/

