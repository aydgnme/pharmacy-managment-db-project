create procedure LD_ex6 (v_salary employees.salary%Type)
is
cursor c_ang is select * from employees where salary<v_salary;
begin
for emp in c_ang loop
DBMS_OUTPUT.PUT_LINE(EMP.FIRST_NAME||' '||EMP.LAST_NAME|| ' ARE SALARIUL MAI MIC DECAT '||V_SALARY);
END LOOP;
end LD_ex6;
/

