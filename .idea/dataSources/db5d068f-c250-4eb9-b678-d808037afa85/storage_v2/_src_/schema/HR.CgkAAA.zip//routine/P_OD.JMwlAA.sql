create procedure p_od(id number)
is
salary_p employees.salary%type;
salary_nou employees.salary%type;
begin
select salary into salary_p from employees where employee_id=id;
update od_emp
set salary=
case
when commission_pct between 0.1 and 0.2 then salary+salary*0.1
when commission_pct> 0.2 then salary+salary*2.5
else salary
end
where employee_id=id;
select salary into salary_nou from employees where employee_id=id;
dbms_output.put_line('Salariul vechi:'||salary_p||' si salariul nou'||salary_nou);
end p_od;
/

