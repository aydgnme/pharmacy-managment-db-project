create PACKAGE TA_PACHET1 IS
    FUNCTION numarAngajati(v_dep departments.department_id%TYPE)
        RETURN NUMBER;
    FUNCTION sumaSalarii(v_dep departments.department_id%TYPE)
        return NUMBER;
END TA_PACHET1;
/

