create PACKAGE pe_pachet1 IS
 FUNCTION medieDepartament(dep_id departments.department_id%TYPE)
 RETURN NUMBER;

 FUNCTION medieAn(an NUMBER)
 RETURN NUMBER;

 FUNCTION medieAngajati
 RETURN NUMBER;
END pe_pachet1;
/

