create FUNCTION obtine_comision(

    v_nume_angajat employees.last_name%TYPE,

    v_prenume_angajat employees.first_name%TYPE

) RETURN employees.commission_pct%TYPE AS

    v_comision employees.commission_pct%TYPE;

BEGIN

    v_nume_angajat :='King';

    v_prenume_angajat := 'Steven';



    SELECT commission_pct INTO v_comision

    FROM employees

    WHERE last_name = v_nume_angajat AND first_name = v_prenume_angajat;



    RETURN v_comision;

EXCEPTION

    WHEN NO_DATA_FOUND THEN

        DBMS_OUTPUT.PUT_LINE('Angajatul ' || v_prenume_angajat || ' ' || v_nume_angajat || ' nu a fost gasit.');

        RETURN NULL;

    WHEN OTHERS THEN

        DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);

        RETURN NULL;

END;
/

