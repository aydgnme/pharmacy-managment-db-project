create PACKAGE BODY CM_pack1 IS
FUNCTION avgSalForDep(dep departments.department_id%TYPE)
RETURN employees.salary%TYPE
IS
avgSal employees.salary%TYPE;
BEGIN
SELECT AVG(salary) into avgSal FROM employees
WHERE department_id=dep;
if(avgSal IS NULL) THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END IF;
RETURN avgSal;
END avgSalForDep;

FUNCTION avgSalForAll
RETURN employees.salary%TYPE
IS
avgSal employees.salary%TYPE;
BEGIN
SELECT AVG(salary) into avgSal FROM employees;
if(avgSal IS NULL) THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END IF;
RETURN avgSal;
END avgSalForAll;


FUNCTION avgSalForHireDate(v_hire_date employees.hire_date%TYPE)
RETURN employees.salary%TYPE
IS
avgSal employees.salary%TYPE;
BEGIN
SELECT AVG(salary) into avgSal FROM employees
WHERE employees.hire_date=v_hire_date;
if(avgSal IS NULL) THEN
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END IF;
RETURN avgSal;
END avgSalForHireDate;
END CM_pack1;
/

