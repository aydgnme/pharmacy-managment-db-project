create FUNCTION max_salary_per_department RETURN SYS_REFCURSOR IS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT department_id, MAX(salary) AS max_salary
        FROM employees
        GROUP BY department_id;
    RETURN v_cursor;
END;
/

