create package pachet as
   procedure test is
   show errors;
  end;






create or replace procedure stergereAngajat

  is

  vechime employees.hire_date%TYPE;

  begin

  select max(hire_date) into vechime

   from employees;



  delete

   from employees_FINAL

   where vechime=hire_date;







  Exception

   when others then

   dbms_output.put_line('EROARE');

  end;
/

