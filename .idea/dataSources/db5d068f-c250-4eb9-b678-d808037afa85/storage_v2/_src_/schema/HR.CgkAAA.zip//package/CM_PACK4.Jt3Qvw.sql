create PACKAGE CM_pack4 IS
PROCEDURE ADD_DEP(id Cm_departments.department_id%TYPE,
name CM_departments.department_name%TYPE,
man_id CM_departments.manager_id%TYPE,
loc_id CM_departments.location_id%TYPE);

PROCEDURE MODIF_DEP(id Cm_departments.department_id%TYPE,
name CM_departments.department_name%TYPE,
man_id CM_departments.manager_id%TYPE,
loc_id CM_departments.location_id%TYPE);

PROCEDURE DEL_DEP(id Cm_departments.department_id%TYPE);

FUNCTION GET_DEP(id Cm_departments.department_id%TYPE)
RETURN CM_departments.department_name%TYPE;
END CM_pack4;
/

