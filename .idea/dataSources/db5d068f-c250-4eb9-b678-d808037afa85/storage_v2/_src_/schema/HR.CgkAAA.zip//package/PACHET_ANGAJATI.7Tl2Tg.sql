create PACKAGE Pachet_Angajati AS

    FUNCTION AnulAngajarii(ID_angajat IN employees.employee_id%TYPE) RETURN DATE;


    PROCEDURE ModificaSalariu(ID_angajat IN employees.employee_id%TYPE, NouSalariu IN NUMBER);
END Pachet_Angajati;
/

