create function max_sal(hire_year in number) return number is
v_max_salariu  number;

begin

select max(salary) into v_max_salariu
from employees
where extract(year from hire_date) = hire_year;

return v_max_salariu;
exception
when no_data_found then
return null;

end;
/

