create procedure  pd1_p
as update;


declare

v_dep departments_pdd.department_name%type;



begin

v_dep:='Dep_nou';

procedure pd1_p;

Update departments_pdd

set department_name=v_dep

where department_id=90;



 end pd1_p;


/

