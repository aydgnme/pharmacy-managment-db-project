create FUNCTION f7_mcv(nume_d mcv_dep.department_name%TYPE)
  RETURN varchar2
 IS
  oras locations.city%TYPE;
  BEGIN
   SELECT l.city INTO oras FROM Locations L, Departments D WHERE l.location_id = d.location_id and d.department_name = nume_d;
  RETURN oras;
 END f7_mcv;
/

