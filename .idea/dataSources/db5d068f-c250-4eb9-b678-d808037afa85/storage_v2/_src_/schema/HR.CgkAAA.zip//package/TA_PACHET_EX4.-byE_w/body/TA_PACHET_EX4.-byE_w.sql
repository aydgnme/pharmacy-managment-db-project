create PACKAGE BODY TA_PACHET_EX4 IS
  FUNCTION gETaNaNGAJARII(id_ang IN EMPLOYEES.EMPLOYEE_ID%TYPE)
  return date
  is
  an_angajarii employees.hire_date%TYPE;
  begin
    select hire_date into an_angajarii from employees
    where employee_id = id_ang;
  return an_angajarii;
  end GETaNaNGAJARII;
  PROCEDURE MODIFsAL(ID_ANG EMPLOYEES.EMPLOYEE_ID%TYPE,new_sal in employees.salary%TYPE)
  IS
  BEGIN
    UPDATE TA_EMP
    SET SALARY = new_sal
    WHERE EMPLOYEE_ID = ID_ANG;
  END MODIFSAL;
END TA_PACHET_EX4;
/

