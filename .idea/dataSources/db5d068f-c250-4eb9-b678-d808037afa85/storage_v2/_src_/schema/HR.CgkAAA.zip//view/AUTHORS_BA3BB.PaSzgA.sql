create view AUTHORS_BA3BB as
select first_name
from authors_BA3b
/

