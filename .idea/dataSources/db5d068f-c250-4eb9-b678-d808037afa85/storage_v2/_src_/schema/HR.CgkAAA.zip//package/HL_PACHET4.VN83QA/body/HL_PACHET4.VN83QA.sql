create PACKAGE BODY hl_pachet4 AS

  PROCEDURE ADD_DEP(h_dep_id IN NUMBER, h_dep_name IN VARCHAR2) IS
  BEGIN
    INSERT INTO pe_departments(department_id, department_name) VALUES (h_dep_id, h_dep_name);
  END ADD_DEP;

  PROCEDURE MODIF_DEP(h_dep_id IN NUMBER, h_dep_name IN VARCHAR2) IS
  BEGIN
    UPDATE hl_departamente SET department_name = h_dep_name WHERE department_id = h_dep_id;
  END MODIF_DEP;

  PROCEDURE DEL_DEP(h_dep_id IN NUMBER) IS
  BEGIN
    DELETE FROM hl_departmente  WHERE department_id = h_dep_id;
  END DEL_DEP;

  FUNCTION GET_DEP(h_dep_id IN NUMBER) RETURN VARCHAR2 IS
    v_dep_name VARCHAR2(255);
  BEGIN
    SELECT department_name INTO v_dep_name FROM hl_departmente WHERE department_id = h_dep_id;
    RETURN v_dep_name;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
  END GET_DEP;

END hl_pachet4;
/

