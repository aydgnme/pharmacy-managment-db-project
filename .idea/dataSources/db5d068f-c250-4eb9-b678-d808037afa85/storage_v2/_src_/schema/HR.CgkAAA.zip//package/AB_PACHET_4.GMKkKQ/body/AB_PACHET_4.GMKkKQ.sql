create package body ab_pachet_4 is

procedure add_dep (name ab_dep.department_name%type)as
begin
insert into ab_dep(department_name) values(name);
end add_dep;

procedure modif_dep (name ab_dep.department_name%type, name_n ab_dep.department_name%type)as
begin
update ab_dep
set department_name = name_n
where department_name = name;
end modif_dep;

procedure del_dep (id ab_dep.department_id%type)as
begin
delete from ab_dep
where department_id = id;
end del_dep;

function get_dep(id ab_dep.department_id%type) return varchar2
is a ab_dep.department_name%type;
begin
select department_name into a from departments where department_id= id;
return a;
end get_dep;


end ab_pachet_4;
/

