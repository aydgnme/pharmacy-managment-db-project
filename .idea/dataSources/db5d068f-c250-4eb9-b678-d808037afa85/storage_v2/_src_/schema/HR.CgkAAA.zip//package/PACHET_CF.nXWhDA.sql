create PACKAGE pachet_CF IS


FUNCTION nr_ang(job IN employees.job_id%TYPE) RETURN NUMBER;



PROCEDURE sterg_ang;



END pachet_CF;


/

