create PROCEDURE updateEmailAn AS
    TYPE NameList IS TABLE OF VARCHAR2(100);
    l_names NameList;
BEGIN

    UPDATE employees_sa
    SET email = REPLACE(first_name || '.' || last_name || '@gmail.com')
    WHERE job_id = 'ST_MAN';

    COMMIT;


    SELECT first_name || ' ' || last_name
    BULK COLLECT INTO l_names
    FROM employees_sa
    WHERE job_id = 'ST_MAN';


    FOR i IN 1..l_names.COUNT LOOP
        DBMS_OUTPUT.PUT_LINE('Angajat modificat: ' || l_names(i));
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('A aparut o eroare ');
END;
/

