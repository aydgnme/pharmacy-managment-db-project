create FUNCTION prevent_modification_on_day()
RETURN VARCHAR2 AS
BEGIN

  IF TO_CHAR(SYSDATE, 'D') = '3' THEN
    RAISE_APPLICATION_ERROR(-20001, 'Modificarile nu sunt permise în ziua de laborator!');
  END IF;
  RETURN NULL;
END;
/

