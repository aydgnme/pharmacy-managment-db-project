create package pachet1_LE is
function salMediu_dep(dep departments.department_id%TYPE)
return employees.salary%TYPE;
function salMediu_all
return employees.salary%TYPE;
function salMediu_ang(data varchar2)
return employees.salary%TYPE;
end pachet1_LE;
/

