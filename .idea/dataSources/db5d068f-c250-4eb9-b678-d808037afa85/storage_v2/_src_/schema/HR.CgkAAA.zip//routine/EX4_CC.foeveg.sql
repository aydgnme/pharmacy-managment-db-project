create FUNCTION ex4_CC (id IN departments.department_id%TYPE)
RETURN NUMBER
IS
nrang NUMBER;
BEGIN
Select COUNT(*) INTO nrang From Employees Where department_id = id;
RETURN nrang;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN -1;
WHEN OTHERS THEN
RETURN -2;
END ex4_CC;
/

