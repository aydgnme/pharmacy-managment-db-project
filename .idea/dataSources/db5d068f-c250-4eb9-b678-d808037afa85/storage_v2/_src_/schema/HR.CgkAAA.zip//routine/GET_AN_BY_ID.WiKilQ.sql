create FUNCTION

  GET_AN_BY_ID( id NUMBER)

  RETURN VARCHAR

IS



V_AN VARCHAR(4);

   BEGIN

select to_Char(hire_date,'yyyy') INTO V_AN

from emp_TA

where employee_id=ID;

   RETURN V_AN;



  END GET_AN_BY_ID;
/

