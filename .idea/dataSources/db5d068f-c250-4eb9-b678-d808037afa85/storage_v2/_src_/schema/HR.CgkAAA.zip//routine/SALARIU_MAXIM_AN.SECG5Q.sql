create FUNCTION salariu_maxim_an(
    p_anul IN DATE
)
RETURN NUMBER
IS
    v_salariu_maxim employees.salary%TYPE;
BEGIN
    SELECT MAX(salary) INTO v_salariu_maxim
    FROM employees
    WHERE EXTRACT(YEAR FROM hire_date) = EXTRACT(YEAR FROM p_anul);

    RETURN v_salariu_maxim;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
    WHEN OTHERS THEN
        RETURN NULL;
END;
/

