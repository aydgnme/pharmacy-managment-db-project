create package hl_pachet1
is
function medieDep(dep_id
departments.department_id%TYPE)
return number;

function medieAn(an NUMBER)
return number;

function medieAngajati
return number;
end hl_pachet1;
/

