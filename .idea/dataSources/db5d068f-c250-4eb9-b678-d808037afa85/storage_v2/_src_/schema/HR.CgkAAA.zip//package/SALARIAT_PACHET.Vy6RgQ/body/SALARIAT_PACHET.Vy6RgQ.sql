create PACKAGE BODY Salariat_Pachet AS
  FUNCTION Anul_Angajarii (p_id_salariat NUMBER) RETURN NUMBER IS
    v_anul_angajarii NUMBER;
  BEGIN
    SELECT EXTRACT(YEAR FROM hire_date) INTO v_anul_angajarii
    FROM employees
    WHERE employee_id= p_id_salariat;

    RETURN v_anul_angajarii;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
  END Anul_Angajarii;

  PROCEDURE Afiseaza_Salariat (p_id_salariat NUMBER) IS
    v_salariat employees%ROWTYPE;
  BEGIN
    SELECT * INTO v_salariat
    FROM employees
    WHERE employee_id= p_id_salariat;

    DBMS_OUTPUT.PUT_LINE('ID: ' || v_salariat.employee_id|| ', First_name: ' || v_salariat.First_name|| ', Anul Angajarii: ' || EXTRACT(YEAR FROM v_salariat.hire_date));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Nu  salariat cu ID-ul ' || p_id_salariat);
  END Afiseaza_Salariat;
END Salariat_Pachet;
/

