create procedure p_dac(id_dep dac_dep.department_name%type) is





begin

update dac_dep

set department_name='Electronics'

where department_id=id_dep;

dbms_output.put_line('Numele departamentului a fost schimbat');

end p_dac;
/

