create PACKAGE Employee_Management_IC AS

  PROCEDURE Delete_Oldest_Employee_IC;



  FUNCTION Count_Employees_By_Job_IC(job_id IN VARCHAR2) RETURN NUMBER;

END Employee_Management_IC;
/

