create package TA_pachet_ex3 IS
  FUNCTION GETaNaNGAJARE(EMPLOYEE_ID in employees.EMPLOYEE_ID%type)  RETURN DATE;
  PROCEDURE AFISareaNaNGAJARE(employee_id in employees.employee_id%TYPE);
end TA_pachet_ex3 ;
/

