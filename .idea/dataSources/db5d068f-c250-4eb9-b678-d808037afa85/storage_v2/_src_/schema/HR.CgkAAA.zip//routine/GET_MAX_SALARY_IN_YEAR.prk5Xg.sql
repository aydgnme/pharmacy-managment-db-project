create FUNCTION get_max_salary_in_year(year_in IN NUMBER)
RETURN NUMBER
IS
    max_salary NUMBER;
BEGIN
    SELECT MAX(salary) INTO max_salary
    FROM employees
    WHERE EXTRACT(YEAR FROM hire_date) = year_in;

    RETURN max_salary;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END;
/

