create PACKAGE BODY mcv_ex5 AS
 PROCEDURE anumit(job mcv_emp.job_id%TYPE)
 IS
 BEGIN
 FOR emp IN (SELECT employee_id, last_name, first_name FROM mcv_emp WHERE job_id = job) LOOP
 DBMS_OUTPUT.PUT_LINE(emp.employee_id || emp.first_name || emp.last_name);
 END LOOP;
 END anumit;

 PROCEDURE anumit(anul NUMBER)
 IS
 BEGIN
 FOR emp IN (SELECT last_name, first_name, employee_id FROM mcv_emp WHERE EXTRACT(YEAR FROM hire_date) = anul) LOOP
 DBMS_OUTPUT.PUT_LINE(emp.last_name || emp.first_name || anul);
 END LOOP;
 END anumit;
END mcv_ex5;
/

