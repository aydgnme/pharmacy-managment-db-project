create PROCEDURE sterge_angajati_salariu_mic (

    val_sal IN NUMBER

) IS

    TYPE AngajatType IS TABLE OF DSDSDS_angajati.employee_id%TYPE INDEX BY PLS_INTEGER;

    angajati_stersi AngajatType;

BEGIN

    DELETE FROM DSDSDS_angajati

    WHERE salary < val_sal

    RETURNING employee_id BULK COLLECT INTO angajati_stersi;



    IF angajati_stersi.COUNT > 0 THEN

        DBMS_OUTPUT.PUT_LINE('Angajatii stersi:');

        FOR i IN 1 .. angajati_stersi.COUNT LOOP

            DBMS_OUTPUT.PUT_LINE('Angajatul cu ID-ul ' || angajati_stersi(i) || ' a fost sters.');

        END LOOP;

    ELSE

        DBMS_OUTPUT.PUT_LINE('Nu s-au gasit angajati cu salariul mai mic decat ' || val_sal);

    END IF;

EXCEPTION

    WHEN OTHERS THEN

        DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);

END sterge_angajati_salariu_mic;
/

