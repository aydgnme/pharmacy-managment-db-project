create Function lab4ex6(p_id Number)
Return VarChar2(25)

DECLARE
v_email VarChar2(25);

BEGIN
SELECT EMAIL

INTO v_email
From PSM_Employees
Where Employee_ID = p_id;
return v_email;

EXCEPTION
WHEN OTHERS THEN
DBMS_OUTPUT.PUTLINE('Exceptie');

end lab4ex6;

Begin
lab4ex6(100);
END;
/

