create PACKAGE BODY CM_pack3 IS
PROCEDURE selectForLetter(letter VARCHAR2) IS
counter NUMBER(9);
CURSOR c_ang IS
SELECT last_name, first_name FROM employees WHERE last_name LIKE(letter || '%');
BEGIN
counter:=0;
FOR v_ang in c_ang LOOP
DBMS_OUTPUT.PUT_LINE(v_ang.last_name || ' ' || v_ang.first_name);
counter:=counter+1;
END LOOP;
if(counter=0) then
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END if;
END selectForLetter;

PROCEDURE selectForJob(nume VARCHAR2, prenume VARCHAR2) IS
counter NUMBER(9);
CURSOR c_ang IS
SELECT last_name, first_name FROM employees WHERE job_id = (SELECT job_id FROM employees WHERE last_name=nume AND first_name=prenume);
BEGIN
counter:=0;
FOR v_ang in c_ang LOOP
DBMS_OUTPUT.PUT_LINE(v_ang.last_name || ' ' || v_ang.first_name);
counter:=counter+1;
END LOOP;
if(counter=0) then
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END if;
END selectForJob;

PROCEDURE selectForSalaryGreaterThanAvg IS
counter NUMBER(9);
CURSOR c_ang IS
SELECT last_name, first_name FROM employees WHERE salary>(SELECT AVG(salary) from employees);
BEGIN
counter:=0;
FOR v_ang in c_ang LOOP
DBMS_OUTPUT.PUT_LINE(v_ang.last_name || ' ' || v_ang.first_name);
counter:=counter+1;
END LOOP;
if(counter=0) then
DBMS_OUTPUT.PUT_LINE('NU EXISTA!');
END if;
END selectForSalaryGreaterThanAvg ;
END CM_pack3;
/

