create PROCEDURE Afisare_Salariu(last_name IN EMPLOYEES.LAST_NAME%TYPE, first_name IN EMPLOYEES.FIRST_NAME%TYPE) IS
  salariul NUMBER;
BEGIN
  SELECT SALARY INTO salariul
  FROM EMPLOYEES
  WHERE LAST_NAME = last_name AND FIRST_NAME = first_name;

  DBMS_OUTPUT.PUT_LINE('Salariul pentru ' || first_name || ' ' || last_name || ' este: ' || salariul);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Nu existA un angajat cu numele dat.');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('A apArut o eroare: ' || SQLERRM);
END;
/

