create PACKAGE BODY sa_pachet_3 IS

    FUNCTION getAnAngajare(employee_id IN employees.employee_id%TYPE) RETURN DATE IS
        v_an_angajare DATE;
    BEGIN
        SELECT hire_date INTO v_an_angajare
        FROM employees
        WHERE employee_id = employee_id;

        RETURN v_an_angajare;
    END getAnAngajare;

    PROCEDURE modificaSalariu(employee_id IN employees.employee_id%TYPE, nou_salariu IN employees.salary%TYPE) IS
    BEGIN
        UPDATE employees
        SET salary = nou_salariu
        WHERE employee_id = employee_id;

        COMMIT;
    END modificaSalariu;

END sa_pachet_3;
/

