create package pac is

  function oras(nume_dept departments.department_name%type) return varchar2;

end pac;
/

