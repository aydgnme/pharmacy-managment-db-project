create view ANGAJATI_IC33B_GREENBERG as
select e.first_name||' ' ||e.last_name as angajat,e.employee_id, d.department_name, j.job_title, e1.last_name || ' ' || e1.first_name as manager
from employees e, departments d, jobs j, employees e1
where d.department_id = e.department_id AND j.job_id = e.job_id AND e1.employee_id = e.manager_id AND e1.last_name = 'Greenberg'
/

