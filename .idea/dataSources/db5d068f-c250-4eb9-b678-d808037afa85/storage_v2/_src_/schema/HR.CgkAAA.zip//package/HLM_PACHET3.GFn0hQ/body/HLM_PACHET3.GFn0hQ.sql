create PACKAGE BODY hlm_pachet3 AS
  PROCEDURE empInitial(p_initial IN VARCHAR2) IS
  BEGIN
    FOR rec IN (SELECT * FROM employees WHERE LOWER(SUBSTR(last_name,1,1)) = LOWER(p_initial)) LOOP
      DBMS_OUTPUT.PUT_LINE(rec.first_name || ' ' || rec.last_name);
    END LOOP;
  END empInitial;

  PROCEDURE empSameJobs(p_nume IN VARCHAR2, p_prenume IN VARCHAR2) IS
    v_job employees.job_id%TYPE;
  BEGIN
    SELECT job_id INTO v_job
    FROM employees
    WHERE LOWER(last_name) = LOWER(p_nume) AND LOWER(first_name) = LOWER(p_prenume);

    FOR rec IN (SELECT * FROM employees WHERE job_id = v_job) LOOP
      DBMS_OUTPUT.PUT_LINE(rec.first_name || ' ' || rec.last_name);
    END LOOP;
  END empSameJobs;

  PROCEDURE highSalaries IS
    v_medie NUMBER;
  BEGIN
    SELECT AVG(salary) INTO v_medie FROM employees;
    FOR rec IN (SELECT * FROM employees WHERE salary > v_medie) LOOP
      DBMS_OUTPUT.PUT_LINE(rec.first_name || ' ' || rec.last_name);
    END LOOP;
  END highSalaries;
END hlm_pachet3;
/

