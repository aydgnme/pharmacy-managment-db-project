create PROCEDURE procedurasalariu(id aa_emp.employee_id%TYPE, salariu OUT aa_emp.salary%TYPE,salariu_nou OUT aa_emp.salary%TYPE) IS
com aa_emp.commission_pct%TYPE;
BEGIN
SELECT salary, commission_pct into salariu, com from aa_emp where employee_id = id;
CASE
WHEN com in (0.1,0.2) THEN
salariu_nou:=salariu*1.1;
WHEN com >0.2 THEN
salariu_nou:=salariu*1.25;
ELSE
salariu_nou:=salariu;
END CASE;
UPDATE aa_emp
set salary=salariu_nou
where employee_id = id;
END procedurasalariu;
/

