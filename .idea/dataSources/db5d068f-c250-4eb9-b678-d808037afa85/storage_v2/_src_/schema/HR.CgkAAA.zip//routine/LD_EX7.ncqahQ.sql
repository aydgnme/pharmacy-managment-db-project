create function LD_ex7 (v_id employees.employee_id%type)
return varchar is
v_email employees.email%type;
begin
select email into v_email from employees
where employee_id=v_id;
return v_email;
exception
when no_data_found then
dbms_output.put_line('Angajatul nu are email');
when too_many_rows then
dbms_output.put_line('prea multi angajati cu acelasi id');
end LD_EX7;
/

