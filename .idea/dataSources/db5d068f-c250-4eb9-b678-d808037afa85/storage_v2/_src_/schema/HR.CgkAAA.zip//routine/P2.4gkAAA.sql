create PROCEDURE p2(litera varchar) IS

empid employees.employee_id%TYPE;

CURSOR c1 IS

select employee_id from uc_emp where last_name like '%litera';

BEGIN

open c1;



FOR vari in c1 loop

update ucc_emp

set department_id = department_id + 10 where employee_id = 100;

end loop;

close c1;

END p2;
/

