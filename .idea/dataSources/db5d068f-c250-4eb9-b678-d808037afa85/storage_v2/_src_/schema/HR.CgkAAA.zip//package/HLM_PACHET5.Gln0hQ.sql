create PACKAGE hlm_pachet5 AS

  PROCEDURE showEmployees(j_id employees.JOB_ID%Type);

  PROCEDURE showEmployees(year NUMBER);

END hlm_pachet5;
/

