create PACKAGE BODY CF_pachet4 IS

PROCEDURE ADD_DEP(id departments.department_id%TYPE, nume departments.department_name%TYPE, manager departments.manager_id%TYPE, locatie departments.location_id%TYPE) IS

BEGIN
    INSERT INTO Departments_CF VALUES(id, nume, manager, locatie);
    COMMIT;

END ADD_DEP;

PROCEDURE MODIF_DEP(nume departments.department_name%TYPE, id departments.department_id%TYPE) IS
BEGIN
    UPDATE Departments_CF SET department_name = nume WHERE department_id = id;
    COMMIT;

END MODIF_DEP;

PROCEDURE DEL_DEP(id departments.department_id%TYPE) IS
BEGIN
    DELETE FROM Departments_CF WHERE department_id = id;
    COMMIT;

END DEL_DEP;

FUNCTION GET_DEP(id departments.department_id%TYPE) RETURN departments.department_name%TYPE IS
nume Departments_CF.department_name%TYPE;
  BEGIN
    SELECT department_name INTO nume FROM Departments_CF WHERE department_id = id;
    RETURN nume;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;

END GET_DEP;

END CF_pachet4;
/

