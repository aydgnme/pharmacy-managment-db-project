create procedure p8(an number)
is
nr number:=0;
begin
delete from od_emp
where to_char(hire_date,'YYYY')=an;
if sql%found then
nr:=nr+sql%rowcount;
end if;
dbms_output.put_line('S-au sters '||nr);
exception
 when no_data_found then
 dbms_output.put_line('Nu exista angajati cu anul angajarii '|| an);
 when others then
  dbms_output.put_line('Eroare');

end p8;
/

