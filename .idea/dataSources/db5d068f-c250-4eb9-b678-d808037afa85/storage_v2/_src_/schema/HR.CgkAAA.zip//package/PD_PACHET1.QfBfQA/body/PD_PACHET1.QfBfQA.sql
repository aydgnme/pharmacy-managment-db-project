create PACKAGE BODY pd_pachet1 IS
    FUNCTION medSalDep(dep departments.department_id%TYPE)
    RETURN NUMBER
    IS
        numar NUMBER;
    BEGIN
        SELECT avg(salary) INTO numar FROM employees
        WHERE department_id=dep;
        RETURN numar;
    END medSalDep;

    FUNCTION medSalAn(date1 number)
    RETURN NUMBER
    IS
        med NUMBER;
    BEGIN
        SELECT avg(salary) INTO med FROM employees WHERE extract(year from hire_date)=date1;
        RETURN med;
    END medSalAn;

    FUNCTION medSal
    RETURN NUMBER
    IS
        medsal NUMBER;
    BEGIN
        SELECT avg(salary) INTO medsal FROM employees;
        RETURN medsal;
    END medSal;

END pd_pachet1;
/

