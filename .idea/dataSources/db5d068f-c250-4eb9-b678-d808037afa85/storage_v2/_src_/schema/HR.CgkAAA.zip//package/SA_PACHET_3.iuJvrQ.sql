create PACKAGE sa_pachet_3 IS
    FUNCTION getAnAngajare(employee_id IN employees.employee_id%TYPE) RETURN DATE;
    PROCEDURE modificaSalariu(employee_id IN employees.employee_id%TYPE, nou_salariu IN employees.salary%TYPE);
END sa_pachet_3;
/

