create PACKAGE mcv_pachet1 IS
 FUNCTION medie_salarii_dep(id mcv_dep.department_id%TYPE)
  RETURN NUMBER;
 FUNCTION medie_salarii_toti_an(anul mcv_emp.hire_date%TYPE)
  RETURN NUMBER;
END mcv_pachet1;
/

