create function salariu(an in employees.hire_date%type)



return number is



   sal number(9);



   begin



   select max(salary) into sal



    from employees



  where to_char(hire_date,'dd-mm-yyyy') = to_char(an,'dd-mm-yyyy');

   return sal;

  exception



  when others then



  return -10;



  end;


/

