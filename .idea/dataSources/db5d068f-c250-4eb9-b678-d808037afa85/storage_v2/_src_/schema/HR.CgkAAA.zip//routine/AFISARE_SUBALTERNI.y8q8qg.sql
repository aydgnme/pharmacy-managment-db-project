create PROCEDURE afisare_subalterni(
    manager_id_angajat IN NUMBER
) AS
BEGIN

    FOR subordonat IN (SELECT * FROM angajati WHERE manager_id = manager_id_angajat) LOOP
        DBMS_OUTPUT.PUT_LINE('Nume: ' || subordonat.nume || ', Prenume: ' || subordonat.prenume);
    END LOOP;
END;
/

