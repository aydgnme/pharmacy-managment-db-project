create package TA_PACHET_ex2

is

   procedure delHighestVechime;

   function nrAng(id_job varchar)

   return number;

end TA_PACHET_ex2;
/

