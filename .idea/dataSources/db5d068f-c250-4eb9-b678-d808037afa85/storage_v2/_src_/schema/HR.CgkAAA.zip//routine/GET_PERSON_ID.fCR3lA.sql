create FUNCTION get_person_id(p_last_name IN VARCHAR2, p_first_name IN VARCHAR2) RETURN NUMBER IS
    v_person_id NUMBER;
BEGIN
    SELECT employee_id INTO v_person_id FROM employees WHERE last_name = p_last_name AND first_name = p_first_name;
    RETURN v_person_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END get_person_id;
/

