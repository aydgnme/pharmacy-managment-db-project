create Function GetEmail(p_id number) Return VarChar2 IS
v_email VarChar2(100);
Begin

Select Email
INTO v_email
FROM psm_employees
Where Employee_ID = p_id;
return v_email;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
    WHEN OTHERS THEN
        RETURN NULL;
END;
/

