create PACKAGE mcv_ex4 IS
 PROCEDURE ADD_DEP(id mcv_dep.department_id%TYPE, nume mcv_dep.department_name%TYPE);
 PROCEDURE MODIF_DEP(id mcv_dep.department_id%TYPE, nume mcv_dep.department_name%TYPE);
 PROCEDURE DEL_DEP(id mcv_dep.department_id%TYPE);
 FUNCTION GET_DEP(id mcv_dep.department_id%TYPE) RETURN varchar2;
END mcv_ex4;
/

