create function salariu_maxim(p_department_name in varchar2) return number is
v_max_salariu number;

begin
select max(salary) into v_max_salariu
from employees e
join departments d on e.department_id = d.department_id
where upper(d.department_name) = upper(p_department_name);
return v_max_salariu;
exception
when no_data_found then
return null;
end;
/

