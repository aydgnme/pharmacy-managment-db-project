create FUNCTION fex2 (idep in aa_dep.department_id%TYPE)
RETURN NUMBER
IS
nrang NUMBER;
BEGIN
SELECT COUNT(*) into nrang from aa_dep where department_id = idep;
RETURN nrang;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN -1;
WHEN OTHERS THEN
RETURN -2;
END fex2;
/

