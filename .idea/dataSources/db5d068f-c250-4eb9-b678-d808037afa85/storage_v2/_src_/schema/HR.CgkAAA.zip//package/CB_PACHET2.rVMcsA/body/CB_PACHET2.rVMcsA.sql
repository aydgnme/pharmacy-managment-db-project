create package body CB_pachet2 is

function NumeAng(id employees.employee_id%type)
return varchar2
is
nume varchar2(50);
begin
select first_name|| ' '|| last_name into nume from employees where employee_id=id;
return nume;
end NumeAng;

function SalAng(id employees.employee_id%type)
return number
is
sal number;
begin
select salary into sal from employees where employee_id=id;
return sal;
end SalAng;

function EmailAng(id employees.employee_id%type)
return varchar2
is
emailAng1 varchar2(50);
begin
select email into emailAng1 from employees where employee_id=id;
return emailAng1;
end EmailAng;

function HiredateAng(id employees.employee_id%type)
return date
is
dataang date;
begin
select hire_date into dataang from employees where employee_id=id;
return dataang;
end HiredateAng;

end CB_pachet2;
/

