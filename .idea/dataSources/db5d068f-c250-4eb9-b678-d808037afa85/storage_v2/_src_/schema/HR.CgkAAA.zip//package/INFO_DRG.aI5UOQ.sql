create PACKAGE Info_drg AS

  PROCEDURE AfiseazaAngajati(p_job_id IN VARCHAR2);

  PROCEDURE AfiseazaAngajati(p_an_angajare IN NUMBER);
END Info_drg;
/

