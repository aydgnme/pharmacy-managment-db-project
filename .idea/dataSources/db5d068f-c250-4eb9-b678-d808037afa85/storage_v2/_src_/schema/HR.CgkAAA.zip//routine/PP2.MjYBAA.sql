create PROCEDURE pp2 IS

TYPE tab_nume IS TABLE OF employees.last_name%TYPE;
TYPE tab_prenume IS TABLE OF employees.first_name%TYPE;

t_nume tab_nume;
t_prenume tab_prenume;

CURSOR c1 IS
select last_name, first_name from ucc_emp where last_name like '%n';

BEGIN
open c1;

LOOP
FETCH c1 BULK COLLECT INTO t_nume, t_prenume;

exit when c1%NOTFOUND;
update ucc_emp
set department_id = department_id + 10 ;
DBMS_OUTPUT.PUT_LINE('a');
END LOOP;

close c1;

END pp2;

/

