create FUNCTION display_employees_by_job(job_title IN VARCHAR2) RETURN NUMBER IS
    v_display_employees NUMBER := 0;
BEGIN

    SELECT COUNT(*)
    INTO v_display_employees
    FROM employees
    WHERE job_id = job_title;


    RETURN v_display_employees;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END;
/

