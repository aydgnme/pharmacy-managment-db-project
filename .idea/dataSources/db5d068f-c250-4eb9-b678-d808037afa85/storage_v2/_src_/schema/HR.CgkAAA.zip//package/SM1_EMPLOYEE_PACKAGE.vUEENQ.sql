create package SM1_EMPLOYEE_PACKAGE as

PROCEDURE DELETE_EMPLOYEE;

Function count_employee(job_id in number)

return number;

end SM1_EMPLOYEE_PACKAGE;




/

