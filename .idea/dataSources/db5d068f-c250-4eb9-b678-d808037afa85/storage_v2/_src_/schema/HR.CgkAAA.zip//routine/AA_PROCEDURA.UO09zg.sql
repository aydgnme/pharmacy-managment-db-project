create PROCEDURE aa_procedura(id in aa_emp.employee_id%TYPE, salariu out aa_emp.salary%TYPE,salariu_nou aa_emp.salary%TYPE) IS
com aa_emp.commission_pct%TYPE;
BEGIN
select salary,commission_pct into salariu,com from aa_emp where employee_id = id;
CASE
WHEN com>0.1 and com<0.2 THEN
DBMS_OUTPUT.PUT_LINE('Comision intre 0.1-0.2');
salariu_nou:=1.1*salariu;
WHEN com>0.2 THEN
DBMS_OUTPUT.PUT_LINE('Comision mai mare de 0.2');
salariu_nou := salariu*1.25;
ELSE
DMBS_OUTPUT.PUT_LINE('Comision mai mic de 0.1');
salariu_nou:=salariu;
END CASE;
UPDATE aa_emp
set salary = salariu_nou
where employee_id = id;
end aa_procedura;

DECLARE
id employees.employee_id%TYPE;
salariu_vechi employees.salary%TYPE;
salariu_nou employees.salary%TYPE;
BEGIN
aa_procedura('100',salariu_vechi,salariu_nou);
DBMS_OUTPUT.PUT_LINE('Salariu vechi: '||salariu_vechi);
DBMS_OUTPUT.PUT_LINE('Salariu nou: '||salariu_nou);
END;
/

