create function get_max_salary(hire_in in number) return number is
v_max_salary number;

begin

select max(salary) into v_max_salary
from employees
where extract(year from hire_date) = hire_in;
return v_max_salary;
exception
when no_data_found then
return null;
end;
/

