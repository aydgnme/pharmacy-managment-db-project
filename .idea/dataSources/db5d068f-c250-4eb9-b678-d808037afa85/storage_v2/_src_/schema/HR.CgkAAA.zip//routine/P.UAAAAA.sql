create procedure p is

 v_hire_date lk_emp.hire_date%type;

begin

  select min(hire_date) into v_hire_date

  from lk_emp

having min(hire_date) < max(hire_date);

 delete lk_emp

 where to_char(hire_date, 'dd-mm-yy') = to_char(v_hire_date, 'dd-mm-yy');

  dbms_output.put_line('a fost sters angajatul cu cea mai mare vechime, data angajatii: '|| v_hire_date);

end p;






/

