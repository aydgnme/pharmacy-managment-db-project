create PACKAGE BODY mvd_pachet_1 IS
 FUNCTION anul(id employees.employee_id%TYPE) RETURN NUMBER
 IS
  angajare NUMBER;
 BEGIN
  SELECT EXTRACT(YEAR FROM hire_date) INTO angajare FROM Employees WHERE employee_id = id;
 RETURN angajare;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
 RETURN NULL;
  WHEN OTHERS THEN
    RAISE;
 END anul;


 PROCEDURE modifica_salar(id employees.employee_id%TYPE, valoare employees.salary%TYPE) IS
 BEGIN
  Update mcv_emp
  SET salary = salary + valoare
  WHERE employee_id = id;

 IF SQL%ROWCOUNT = 0 THEN
  RAISE_APPLICATION_ERROR(-20001, 'NO EMPLOYEE FOUND');
 END IF;

 EXCEPTION
  WHEN OTHERS THEN
  RAISE;
 END modifica_salar;
END mvd_pachet_1;
/

