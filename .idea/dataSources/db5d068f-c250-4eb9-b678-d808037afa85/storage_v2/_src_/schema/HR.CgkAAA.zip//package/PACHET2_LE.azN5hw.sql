create package pachet2_LE is

function nume_ang(emp1 employees.employee_id%type)
return varchar2;
function salariu_ang(emp2 employees.employee_id%type)
return employees.salary%type;
function email_ang(emp3 employees.employee_id%type)
return employees.email%TYPE;
function data_ang(emp4 employees.employee_id%type)
return employees.hire_date%TYPE;

end pachet2_LE;
/

