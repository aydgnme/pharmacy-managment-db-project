create PACKAGE BODY pachete IS


   PROCEDURE a7 IS
  BEGIN
    FOR i IN (SELECT * FROM employees) LOOP
      IF i.salary > 9000 THEN
        DBMS_OUTPUT.PUT_LINE(i.last_name || ' ' || i.first_name);
      END IF;
    END LOOP;
  END a7;


  FUNCTION f7(a NUMBER, b NUMBER) RETURN NUMBER IS
  BEGIN
    RETURN a / b;
  EXCEPTION
    WHEN ZERO_DIVIDE THEN
      DBMS_OUTPUT.PUT_LINE('Ghinion: Impartire la zero!');
      RETURN NULL;
    when others then
          DBMS_OUTPUT.PUT_LINE('Ghinion: Impartire la zero!');
  END f7;

END pachete;
/

