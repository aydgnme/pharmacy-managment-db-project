create FUNCTION count_employees_by_job(job_title IN VARCHAR2)
RETURN NUMBER
AS
    v_employee_count NUMBER;
BEGIN

    INTO v_employee_count
    FROM employees
    WHERE job_id = job_title;


    RETURN v_employee_count;
END;
/

