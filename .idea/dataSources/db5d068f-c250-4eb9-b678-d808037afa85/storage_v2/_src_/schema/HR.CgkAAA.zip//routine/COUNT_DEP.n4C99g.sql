create function count_dep(p_location_id in number) return number is

v_dep_count number ;
begin

v_dep_count := 0;

for department_rec in(
select department_id
from departments
where location_id = p_location_id) loop

v_dep_count :=v_dep_count+1;

end loop;
 return v_dep_count;
end;
/

