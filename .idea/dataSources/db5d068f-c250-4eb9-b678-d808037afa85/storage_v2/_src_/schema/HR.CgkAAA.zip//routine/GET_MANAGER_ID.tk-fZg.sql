create FUNCTION get_manager_id(
    v_employee_id IN NUMBER
) RETURN NUMBER IS
    v_manager_id NUMBER;
BEGIN

    SELECT manager_id INTO v_manager_id
    FROM employees
    WHERE employee_id = v_employee_id;

    RETURN v_manager_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN NULL;
END;
/

