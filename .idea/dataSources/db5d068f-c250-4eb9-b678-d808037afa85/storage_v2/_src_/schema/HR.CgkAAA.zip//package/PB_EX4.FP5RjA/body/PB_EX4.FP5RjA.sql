create PACKAGE BODY PB_EX4 IS

PROCEDURE ADD_DEP(nume VARCHAR2) IS
BEGIN
INSERT INTO PB_dep(department_name) VALUES(nume);
DBMS_OUTPUT.PUT_LINE(nume || ' a fost adaugat cu succes');
END ADD_DEP;



PROCEDURE MODIF_DEP(v_nume Departments.department_name%TYPE, v_nume_nou Departments.department_name%TYPE) IS
BEGIN
UPDATE PB_dep SET department_name = v_nume_nou WHERE department_name = v_nume;
END MODIF_DEP;


PROCEDURE DEL_DEP(v_nume Departments.department_name%TYPE) IS
BEGIN
DELETE FROM PB_dep WHERE department_name = v_nume;

IF SQL%ROWCOUNT = 0 THEN
DBMS_OUTPUT.PUT_LINE('No exista departament cu asa nume');

ELSE
DBMS_OUTPUT.PUT_LINE('Acest departament a fost sters');
END IF;

END DEL_DEP;


FUNCTION GET_DEP(v_cod Departments.department_id%TYPE) RETURN VARCHAR2 IS
v_nume Departments.department_name%TYPE;
BEGIN
SELECT department_name INTO v_nume FROM PB_dep WHERE department_id = v_cod;
END GET_DEP;


END PB_EX4;
/

