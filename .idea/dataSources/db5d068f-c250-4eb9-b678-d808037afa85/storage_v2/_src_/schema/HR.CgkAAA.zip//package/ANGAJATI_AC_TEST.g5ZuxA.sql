create PACKAGE Angajati_AC_TEST AS

    FUNCTION Anul_Angajarii(ID_angajat IN NUMBER)

        RETURN varchar2;

END Angajati_AC_TEST ;



/

