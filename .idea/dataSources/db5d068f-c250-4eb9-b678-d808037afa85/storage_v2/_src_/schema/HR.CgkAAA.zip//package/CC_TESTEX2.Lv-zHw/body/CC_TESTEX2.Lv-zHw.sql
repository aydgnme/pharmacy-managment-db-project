create PACKAGE BODY CC_testex2 IS

FUNCTION an (ID Employees_CC.employee_id%TYPE)

RETURN DATE

IS

angj DATE;

BEGIN

Select hire_date INTO angj

From Employees_CC

Where employee_id = ID;

RETURN angj;

END an;

PROCEDURE editsalary(ID Employees_CC.employee_id%TYPE, salariu Employees.salary%TYPE) IS

BEGIN

UPDATE Employees_CC

Set salary = salariu

Where employee_id = ID;

IF SQL%FOUND THEN

DBMS_OUTPUT.PUT_LINE('Salariu nou angajat_id '||ID||' = '||salariu);

ELSE DBMS_OUTPUT.PUT_LINE('Nu exista angajat cu acest id.');

END IF;

END editsalary;

END CC_testex2;
/

