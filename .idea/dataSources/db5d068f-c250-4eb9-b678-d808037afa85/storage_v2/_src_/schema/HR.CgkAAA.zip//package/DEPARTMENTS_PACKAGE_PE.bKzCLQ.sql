create PACKAGE departments_package_pe AS

  PROCEDURE ADD_DEP(p_dep_id NUMBER, p_dep_name VARCHAR2);

  PROCEDURE MODIF_DEP(p_dep_id NUMBER, p_dep_name VARCHAR2);

  PROCEDURE DEL_DEP(p_dep_id NUMBER);

  FUNCTION GET_DEP(p_dep_id NUMBER) RETURN VARCHAR2;
END departments_package_pe;
/

