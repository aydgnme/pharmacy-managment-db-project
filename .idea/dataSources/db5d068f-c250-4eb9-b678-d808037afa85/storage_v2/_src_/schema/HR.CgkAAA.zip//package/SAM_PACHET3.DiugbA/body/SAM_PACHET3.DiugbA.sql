create package body sam_pachet3 is

procedure literaAng(litera in varchar2)
is
begin
for anf in (select * from employees where last_name like litera ||'%')
loop
dbms_output.put_line(anf.last_name||' '|| anf.first_name);
end loop;
end literaAng;

procedure jobAng(nume in varchar2) is
job employees.job_id%type;
begin
select job_id into job from employees where first_name = nume or last_name = nume;
for anf in(select first_name, last_name from employees where job_id = job) loop
dbms_output.put_line(anf.first_name || ' ' || anf.last_name);
end loop;
end jobAng;

procedure salMed is
salMediu number;
begin
select avg(salary) into salMediu from employees;
for anf in(select first_name, last_name, salary from employees where salary > salMediu) loop
dbms_output.put_line(anf.first_name || ' ' || anf.last_name || ' , Salariu: ' || anf.salary);
end loop;
end salMed;

end sam_pachet3;
/

