create PACKAGE Salarii_pachet IS
    FUNCTION medieSalariuPerDepartament(dep_id IN NUMBER) RETURN NUMBER;
    FUNCTION medieSalariuPentruToti RETURN NUMBER;
    FUNCTION medieSalariuPerAn(anul IN NUMBER) RETURN NUMBER;
END Salarii_pachet;
/

