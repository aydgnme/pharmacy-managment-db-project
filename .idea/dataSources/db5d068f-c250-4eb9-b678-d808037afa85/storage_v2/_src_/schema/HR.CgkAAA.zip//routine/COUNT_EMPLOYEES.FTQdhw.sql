create function count_employees(job_title in varchar2) return number is
v_count_employee number := 0;

begin

select count(*) into v_count_employee
from employees
where job_id = job_title;

return v_count_employee;
exception
when no_data_found then
return null;
end;

/

