create PACKAGE aa_ex1 IS
FUNCTION AVGSAL
RETURN NUMBER;
FUNCTION AVGSAL(dep departments.department_id%TYPE)
RETURN NUMBER;
FUNCTION AVGSAL(dep departments.department_id%TYPE, an NUMBER)
RETURN NUMBER;
END aa_ex1;
/

