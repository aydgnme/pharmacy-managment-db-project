create package body pd_pachet3 is
procedure AngLitera(litera in varchar2);
is
begin
for anf in (select * from employees where last_name like litera ||'%')
loop
dbms_output.pit_line(last_name||' '|| first_name);
end loop;
end AngLitera;

procedure AngJobidem(nume in varchar2, prenume in varchar2);
is
job varchar2(50);
begin
select job_id into job
from employees
where upper(last_name)=nume and upper(first_name)=prenume;
for ang in (select* from employees where job_id=job)
loop
dbms_output.put_line('ang cu acelasi job ' || ang.last_name || ' ' ||ang.first_name);
end loop;
end AngJobidem

procedure AngSalMMediu
is
sal_mediu number;
begin
select avg(salary) into sal_mediu from employees;
for ang in (select* from employees where salary>sal_mediu)
loop
dbms_output.put_line('ang cu sal ' || ang.last_name || ' ' ||ang.first_name);
end loop;
end AngSalMMediu;

end pd_pachet3;
/

