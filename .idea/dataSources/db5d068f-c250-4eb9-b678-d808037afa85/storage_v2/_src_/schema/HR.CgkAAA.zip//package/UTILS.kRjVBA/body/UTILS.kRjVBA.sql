create PACKAGE BODY utils IS
  FUNCTION mpu(dep employees.department_id%TYPE)
  RETURN NUMBER IS
    nr NUMBER(10);
  BEGIN
    SELECT AVG(salary) INTO nr FROM employees WHERE department_id = dep;
    RETURN nr;
  END mpu;

  FUNCTION mpa
  RETURN NUMBER IS
    nr NUMBER(10);
  BEGIN
    SELECT AVG(salary) INTO nr FROM employees;
    RETURN nr;
  END mpa;
END utils;
/

