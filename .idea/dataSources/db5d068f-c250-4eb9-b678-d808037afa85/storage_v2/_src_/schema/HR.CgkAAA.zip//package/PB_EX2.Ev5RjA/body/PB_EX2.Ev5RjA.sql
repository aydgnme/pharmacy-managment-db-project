create PACKAGE BODY PB_EX2 IS

FUNCTION PB_EX2_NUME(eid Employees.employee_id%TYPE) RETURN VARCHAR2
IS nume_complet VARCHAR2(40);
BEGIN
SELECT first_name || ' ' || last_name INTO nume_complet FROM Employees WHERE employee_id = eid;
RETURN nume_complet;
END PB_EX2_NUME;

FUNCTION PB_EX2_SALARIU(eid Employees.employee_id%TYPE) RETURN NUMBER
IS salariu Employees.salary%TYPE;
BEGIN
SELECT salary INTO salariu FROM Employees WHERE employee_id = eid;
RETURN salariu;
END PB_EX2_SALARIU;

FUNCTION PB_EX2_ANGAJARE(eid Employees.employee_id%TYPE) RETURN DATE
IS data_ang Employees.hire_date%TYPE;
BEGIN
SELECT hire_date INTO data_ang FROM Employees WHERE employee_id = eid;
RETURN data_ang;
END PB_EX2_ANGAJARE;

FUNCTION PB_EX2_EMAIL(eid Employees.employee_id%TYPE) RETURN VARCHAR2 IS
v_email Employees.email%TYPE;
BEGIN
SELECT email INTO v_email FROM Employees WHERE employee_id = eid;
RETURN v_email;
END PB_EX2_EMAIL;

END PB_EX2;
/

