create package pachet_am is

function nrAng(dep_id number)

return number;

procedure numeDep(dep_id number);

end pachet_am;


/

