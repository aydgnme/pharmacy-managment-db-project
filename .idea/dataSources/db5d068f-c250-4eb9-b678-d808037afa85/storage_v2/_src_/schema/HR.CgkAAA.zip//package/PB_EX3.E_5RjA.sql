create PACKAGE PB_EX3 IS

PROCEDURE litera(v_litera VARCHAR2);
PROCEDURE acelasi_job(v_first_name Employees.first_name%TYPE, v_last_name Employees.last_name%TYPE);
PROCEDURE angajati_salariu_mediu;

END PB_EX3;
/

