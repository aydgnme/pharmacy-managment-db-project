create PACKAGE pe_package3 AS

  PROCEDURE showEmployees(j_id employees.JOB_ID%Type);

  PROCEDURE showEmployees(year NUMBER);

END pe_package3;
/

