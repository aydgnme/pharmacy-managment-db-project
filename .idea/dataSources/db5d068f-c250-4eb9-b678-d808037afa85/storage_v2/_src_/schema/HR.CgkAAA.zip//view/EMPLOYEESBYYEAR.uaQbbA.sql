create view EMPLOYEESBYYEAR as
SELECT COUNT(employee_id) AS num_of_employees, MAX(salary) AS max_salary, TO_CHAR(hire_date, 'YYYY') AS year
FROM Employees
GROUP BY TO_CHAR(hire_date, 'YYYY')
/

