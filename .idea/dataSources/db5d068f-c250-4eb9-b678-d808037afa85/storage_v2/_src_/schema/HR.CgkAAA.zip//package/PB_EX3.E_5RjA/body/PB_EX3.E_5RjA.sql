create PACKAGE BODY PB_EX3 IS



PROCEDURE litera(v_litera VARCHAR2) IS
BEGIN
FOR employee IN (SELECT * FROM Employees WHERE first_name LIKE v_litera || '%') LOOP
DBMS_OUTPUT.PUT_LINE(employee.first_name || ' ' || employee.last_name);
END LOOP;
END litera;


PROCEDURE acelasi_job(v_first_name Employees.first_name%TYPE, v_last_name Employees.last_name%TYPE) IS
v_job_id Employees.job_id%TYPE;
BEGIN
SELECT job_id INTO v_job_id FROM Employees WHERE first_name = v_first_name AND last_name = v_last_name;
FOR employee IN (SELECT * FROM Employees WHERE job_id = v_job_id) LOOP
DBMS_OUTPUT.PUT_LINE(employee.first_name || ' ' || employee.last_name);
END LOOP;
END acelasi_job;


PROCEDURE angajati_salariu_mediu IS
v_avg NUMBER;
BEGIN
SELECT AVG(salary) INTO v_avg FROM Employees;
FOR employee in (SELECT * FROM Employees WHERE salary > v_avg) LOOP
DBMS_OUTPUT.PUT_LINE(employee.first_name || ' ' || employee.last_name);
END LOOP;
END angajati_salariu_mediu;


END PB_EX3;
/

