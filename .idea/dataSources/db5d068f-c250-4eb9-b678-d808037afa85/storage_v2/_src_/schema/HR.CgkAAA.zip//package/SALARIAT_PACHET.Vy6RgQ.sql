create PACKAGE Salariat_Pachet AS

  FUNCTION Anul_Angajarii (p_id_salariat NUMBER) RETURN NUMBER;


  PROCEDURE Afiseaza_Salariat (p_id_salariat NUMBER);
END Salariat_Pachet;
/

