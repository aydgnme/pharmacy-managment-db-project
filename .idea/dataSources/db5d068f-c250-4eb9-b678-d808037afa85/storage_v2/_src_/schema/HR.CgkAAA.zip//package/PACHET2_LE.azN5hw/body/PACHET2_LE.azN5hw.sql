create package body pachet2_LE is

function nume_ang(emp1 employees.employee_id%type)
return varchar2
is nume varchar2(45);
begin
select last_name ||' '|| first_name into nume from employees
where employee_id = emp1;
return nume;
end nume_ang;

function salariu_ang(emp2 employees.employee_id%type)
return employees.salary%type
is
salariu employees.salary%type;
begin
select salary into salariu from employees
where employee_id = emp2;
return salariu;
end salariu_ang;

function email_ang(emp3 employees.employee_id%type)
return employees.email%TYPE
is
email_angajati employees.email%TYPE;
begin
select email into email_angajati from employees
where employee_id = emp3;
return email_angajati;
end email_ang;

function data_ang(emp4 employees.employee_id%type)
return employees.hire_date%TYPE
is
data_angajarii employees.hire_date%TYPE;
begin
select hire_date into data_angajarii from employees
where employee_id = emp4;
return data_angajarii;
end data_ang;

end pachet2_LE;
/

