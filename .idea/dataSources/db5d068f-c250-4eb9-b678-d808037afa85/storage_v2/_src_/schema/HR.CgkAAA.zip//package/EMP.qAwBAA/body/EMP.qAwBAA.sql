create PACKAGE BODY emp IS

   create or replace procedure delete_employees(anul_angajarii in number)

is

   v_vechime  date;

begin

  delete from employees_ab where min (to_char(hire_date, 'YYYY')) = anul_angajarii;



end delete_employees;
/

