create view DEM_EX5 as
SELECT employee_id, first_name, last_name, e.department_id, city
FROM employees e, locations l, departments d
WHERE e.department_id = d.department_id AND d.location_id = l.location_id AND l.city = 'London'
/

