create PROCEDURE HACKX
  IS
 BEGIN
 DBMS_OUTPUT.PUT_LINE('

 CREATE OR REPLACE PACKAGE MCV_EX2 IS
  FUNCTION nume_complet(identificator employees.employee_id%TYPE)
   RETURN varchar2;
  FUNCTION salariu(identificator employees.employee_id%TYPE)
   RETURN number;
  FUNCTIO
');
 END HACKX;
/

