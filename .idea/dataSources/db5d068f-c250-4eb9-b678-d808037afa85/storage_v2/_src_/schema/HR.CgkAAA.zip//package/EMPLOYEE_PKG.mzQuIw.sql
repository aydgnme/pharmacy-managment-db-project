create PACKAGE employee_pkg IS

    FUNCTION get_hire_year(employee_id IN employees.employee_id%TYPE) RETURN NUMBER;

    PROCEDURE update_salary(employee_id IN employees.employee_id%TYPE, new_salary IN employees.salary%TYPE);
END employee_pkg;
/

