create PACKAGE XX_pachet1 IS
FUNCTION numarAngajati(dep departments.department_id%TYPE)
RETURN NUMBER;
FUNCTION sumaSalarii(dep departments.department_id%TYPE)
RETURN NUMBER;

END XX_pachet1;
/

