create PACKAGE BODY SL_PACHET5 IS
    PROCEDURE AFISARE_ANG(JOB EMPLOYEES.JOB_ID%TYPE) IS
        numar_angajati NUMBER := 0;
    BEGIN
        FOR ANGAJAT IN (SELECT * FROM EMPLOYEES WHERE JOB_ID = JOB) LOOP
            DBMS_OUTPUT.PUT_LINE('Angajat: ' || ANGAJAT.LAST_NAME || ' ' || ANGAJAT.FIRST_NAME || ', Job: ' || ANGAJAT.JOB_ID);
            numar_angajati := numar_angajati + 1;
        END LOOP;

        IF numar_angajati = 0 THEN
            RAISE NO_DATA_FOUND;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Nu exista angajati pentru jobul specificat.');
    END AFISARE_ANG;

    PROCEDURE AFISARE_ANG(AN NUMBER) IS
    numar_angajati NUMBER := 0;
    BEGIN
        FOR ANGAJAT IN (SELECT * FROM EMPLOYEES WHERE TO_CHAR(HIRE_DATE,'YYYY') = AN) LOOP
            DBMS_OUTPUT.PUT_LINE('Angajat: ' || ANGAJAT.LAST_NAME || ' ' || ANGAJAT.FIRST_NAME || ', Data angajarii: ' || ANGAJAT.HIRE_DATE);
        numar_angajati := numar_angajati + 1;
        END LOOP;
     IF numar_angajati = 0 THEN
            RAISE NO_DATA_FOUND;
     END IF;
     EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Nu exista angajati pentru anul specificat.');
    END AFISARE_ANG;
END SL_PACHET5;
/

