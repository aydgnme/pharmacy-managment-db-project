create procedure q1 is
 ok number(1) :=0;
begin
for c in (select * from employees where salary<9000)
  loop
    if c.last_name  like 'Austin' and c.first_name  like 'David' then
   dbms_output.put_line(c.last_name ||' ' || c.first_name ||' cu salariul: ' || c.salary);
  ok:=1;
  end if;
   if ok=1 then
   dbms_output.put_line('Are si leafa para');
   ok:=0;
   end if;
end loop;
end;
/

