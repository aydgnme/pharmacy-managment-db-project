create PACKAGE BODY aa_ex1 IS

FUNCTION AVGSAL
RETURN NUMBER
IS
suma NUMBER;
BEGIN
Select AVG(salary) INTO suma From Employees;
RETURN suma;
END AVGSAL;

FUNCTION AVGSAL(dep departments.department_id%TYPE)
RETURN NUMBER
IS
suma NUMBER;
BEGIN
Select AVG(salary) INTO suma From Employees
Where department_id = dep;
RETURN suma;
END AVGSAL;


FUNCTION AVGSAL(dep departments.department_id%TYPE, an NUMBER)
RETURN NUMBER
IS
suma NUMBER;
BEGIN
Select AVG(salary) INTO suma From Employees
Where department_id = dep AND TO_CHAR(hire_date,'YYYY') = an;
RETURN suma;
END AVGSAL; /

