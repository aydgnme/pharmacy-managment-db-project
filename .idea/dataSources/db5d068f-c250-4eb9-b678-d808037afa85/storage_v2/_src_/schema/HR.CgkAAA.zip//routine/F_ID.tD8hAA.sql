create FUNCTION f_id
RETURN NUMBER
IS
    p_nume employees.last_name%TYPE;
    p_prenume employees.first_name%TYPE;
    l_empid employees.employee_id%TYPE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Introduce numele:');
    p_nume := UPPER(TRIM('Tata'));

    DBMS_OUTPUT.PUT_LINE('Introduce prenumele:');
    p_prenume := UPPER(TRIM('rtata'));
    SELECT employee_id INTO l_empid
    FROM employees
    WHERE last_name = p_nume AND first_name = p_prenume;

    RETURN l_empid;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN -1;
    WHEN TOO_MANY_ROWS THEN
        RETURN -2;
    WHEN OTHERS THEN
        RETURN -3;
END f_id;
/

