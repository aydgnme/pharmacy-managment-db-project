create package CB_pachet4 is
procedure ADD_DEP(id_dep CB11_dep.department_id%type,nume CB11_dep.department_name%type);
procedure MODIF_DEP(id_dep CB11_dep.department_id%type,nume CB11_dep.department_name%type);
procedure DEL_DEP(id_dep CB11_dep.department_id%type);
function GET_DEP(id_dep CB11_dep.department_id%type)
return varchar2;

end CB_pachet4;
/

