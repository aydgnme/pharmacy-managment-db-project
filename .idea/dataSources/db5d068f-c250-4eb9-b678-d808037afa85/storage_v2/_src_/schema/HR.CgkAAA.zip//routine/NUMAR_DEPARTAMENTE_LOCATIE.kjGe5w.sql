create FUNCTION numar_departamente_locatie(LOCATIE_ID  NUMBER) RETURN NUMBER IS nr_departamente  NUMBER ;



BEGIN

SELECT COUNT(*) into DEPARTMENT_ID

FROM DEPARTMENTS

WHERE LOCATION_ID = numar_departamente_locatie.locatie_id;

RETURN nr_departamente;

end;
/

