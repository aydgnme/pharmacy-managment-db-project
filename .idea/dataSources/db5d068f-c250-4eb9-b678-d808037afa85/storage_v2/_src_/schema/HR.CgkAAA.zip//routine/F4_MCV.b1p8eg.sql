create FUNCTION f4_mcv(id mcv_dep.department_id%TYPE)
  RETURN NUMBER
 IS
   nr_ang NUMBER;
BEGIN
  SELECT COUNT(e.employee_id)INTO nr_ang From mcv_emp E, mcv_dep D
  WHERE e.department_id = d.department_id and d.department_id = id;
  RETURN nr_ang;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RETURN NULL;

 END f4_mcv;
/

