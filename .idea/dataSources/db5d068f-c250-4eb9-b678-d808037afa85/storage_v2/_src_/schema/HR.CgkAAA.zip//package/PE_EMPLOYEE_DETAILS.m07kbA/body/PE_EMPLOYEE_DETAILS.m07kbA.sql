create PACKAGE BODY pe_employee_details IS

FUNCTION employeeFullName(id employees.EMPLOYEE_ID%Type)
 RETURN employees.FIRST_NAME%Type
  IS
  full_name employees.FIRST_NAME%Type;
  BEGIN

  SELECT FIRST_NAME || ' ' || LAST_NAME INTO full_name FROM employees
  WHERE employee_id = id;

  RETURN full_name;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 'Angajatul nu exista';
    WHEN TOO_MANY_ROWS THEN
     RETURN 'Exista mai multi anagajti cu id-ul respectiv';
    WHEN OTHERS THEN
     RETURN 'Error';
END employeeFullName;


--------------------------------------------


FUNCTION employeeSalary(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Salary%Type
IS
  emp_salary employees.Salary%Type;
  BEGIN

  SELECT salary INTO emp_salary FROM employees
  WHERE employee_id = id;

  RETURN emp_salary;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 0;
    WHEN TOO_MANY_ROWS THEN
     RETURN -1;
    WHEN OTHERS THEN
     RETURN -1;
end employeeSalary;

-----------------------------------

FUNCTION employeeEmail(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Email%Type
IS
    emp_email employees.Email%Type;
  BEGIN

  SELECT email INTO emp_email FROM employees
  WHERE employee_id = id;

  RETURN emp_email;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN 'Angajatul nu exista';
    WHEN TOO_MANY_ROWS THEN
     RETURN 'Exista mai multi anagajti cu id-ul respectiv';
    WHEN OTHERS THEN
     RETURN 'Error';

end employeeEmail;


---------------------------------

FUNCTIOn employeeHireDate(id employees.EMPLOYEE_ID%Type)
 RETURN employees.HIRE_DATE%Type
 IS
  emp_date employees.HIRE_DATE%Type;
 BEGIN
  SELECT hire_date INTO emp_date FROM employees
  WHERE employee_id = id;
  RETURN emp_date;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
     RETURN null;
    WHEN TOO_MANY_ROWS THEN
     RETURN null;
    WHEN OTHERS THEN
     RETURN null;

end employeeHireDate;


END pe_employee_details;
/

