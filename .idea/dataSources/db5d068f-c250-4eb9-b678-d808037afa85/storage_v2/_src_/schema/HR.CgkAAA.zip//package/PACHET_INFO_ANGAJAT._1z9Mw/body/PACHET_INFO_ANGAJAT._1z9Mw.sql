create PACKAGE BODY pachet_info_angajat IS

    FUNCTION nume_complet(p_employee_id IN employees.employee_id%TYPE) RETURN VARCHAR2 IS
        v_nume employees.last_name%TYPE;
        v_prenume employees.first_name%TYPE;
        v_nume_complet VARCHAR2(100);
    BEGIN

        SELECT last_name, first_name INTO v_nume, v_prenume
        FROM employees
        WHERE employee_id = p_employee_id;


        v_nume_complet := v_nume || ' ' || v_prenume;

        RETURN v_nume_complet;
    END nume_complet;


    FUNCTION salariu(p_employee_id IN employees.employee_id%TYPE) RETURN NUMBER IS
        v_salariu employees.salary%TYPE;
    BEGIN

        SELECT salary INTO v_salariu
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_salariu;
    END salariu;


    FUNCTION email(p_employee_id IN employees.employee_id%TYPE) RETURN VARCHAR2 IS
        v_email employees.email%TYPE;
    BEGIN

        SELECT email INTO v_email
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_email;
    END email;


    FUNCTION data_angajare(p_employee_id IN employees.employee_id%TYPE) RETURN DATE IS
        v_data_angajare employees.hire_date%TYPE;
    BEGIN

        SELECT hire_date INTO v_data_angajare
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_data_angajare;
    END data_angajare;
END pachet_info_angajat;
/

