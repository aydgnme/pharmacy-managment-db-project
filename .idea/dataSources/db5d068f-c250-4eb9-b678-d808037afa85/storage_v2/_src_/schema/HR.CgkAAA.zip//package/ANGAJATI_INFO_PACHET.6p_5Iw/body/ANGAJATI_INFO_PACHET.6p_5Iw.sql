create PACKAGE BODY Angajati_Info_pachet IS
    PROCEDURE afisareAngajati(job_in VARCHAR2) IS
    BEGIN
        FOR angajat IN (SELECT employee_id, first_name, last_name FROM employees WHERE job_id = job_in) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || angajat.employee_id || ', Nume: ' || angajat.first_name || ', Prenume: ' || angajat.last_name);
        END LOOP;
    END afisareAngajati;

    PROCEDURE afisareAngajati(an_in NUMBER) IS
    BEGIN
        FOR angajat IN (SELECT employee_id, first_name, last_name FROM employees WHERE hire_date >= TO_DATE(an_in || '-01-01', 'YYYY-MM-DD') AND hire_date < TO_DATE((an_in + 1) || '-01-01', 'YYYY-MM-DD')) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || angajat.employee_id || ', Nume: ' || angajat.first_name || ', Prenume: ' || angajat.last_name);
        END LOOP;
    END afisareAngajati;
END Angajati_Info_pachet;
/

