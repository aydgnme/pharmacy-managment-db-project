create PACKAGE pe_employee2 IS

  PROCEDURE showEmployeesByInitial(initial_char IN VARCHAR2);
  PROCEDURE showEmployeesByJob(employee_name IN VARCHAR2);
  PROCEDURE employeesAboveAverage;
END pe_employee2;
/

