create procedure  pxd_proced
is update;
declare
v_dep departments_pdd.department_name%type;

begin
v_dep:='Dep_nou';
procedure pxd_proced;
Update departments_pdd
set department_name=v_dep;
end pxd_proced;

end;
/show errors;
/

