create function am_functie(nume in employees.last_name%type, prenume in employees.first_name%type)

return employees.job_id%type

is

job employees.job_id%type;



begin



select job_id into job

from employees

where last_name = nume and first_name = prenume and job_id = job;

return job;



end am_functie;


/

