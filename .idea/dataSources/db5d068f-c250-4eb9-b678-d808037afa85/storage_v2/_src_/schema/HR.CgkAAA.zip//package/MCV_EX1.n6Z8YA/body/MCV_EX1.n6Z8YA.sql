create PACKAGE BODY MCV_EX1 AS
  FUNCTION angajati_din_an(data_ang IN employees.hire_date%TYPE) RETURN NUMBER IS
    AVERAGE NUMBER;
  BEGIN
    SELECT FLOOR(AVG(SALARY)) INTO AVERAGE FROM EMPLOYEES
    WHERE EXTRACT(YEAR FROM HIRE_DATE) = EXTRACT(YEAR FROM data_ang);
    RETURN AVERAGE;
  END angajati_din_an;

  FUNCTION angajati_din_departa(departa IN employees.department_id%type) RETURN NUMBER IS
    SUMA NUMBER;
  BEGIN
    SELECT FLOOR(AVG(SALARY)) INTO SUMA FROM EMPLOYEES
    WHERE DEPARTMENT_ID = departa;
    RETURN SUMA;
  END angajati_din_departa;
END MCV_EX1;
/

