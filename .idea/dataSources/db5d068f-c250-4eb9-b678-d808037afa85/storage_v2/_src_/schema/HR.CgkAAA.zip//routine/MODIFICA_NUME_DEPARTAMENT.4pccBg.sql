create PROCEDURE modifica_nume_departament(
    p_employee_id IN NUMBER,
    p_new_department_name IN VARCHAR2
) IS

    FUNCTION get_manager_id(p_employee_id IN NUMBER) RETURN NUMBER IS
        v_manager_id NUMBER;
    BEGIN
        SELECT manager_id INTO v_manager_id
        FROM Employees
        WHERE employee_id = p_employee_id;

        RETURN v_manager_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END get_manager_id;
BEGIN

    NULL;
END;
/

