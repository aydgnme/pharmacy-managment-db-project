create Package psm_pachet1 IS
Function numarAngajati(dep departments.department_id%TYPE)
 Return Number;
Function sumaSalarii(dep departments.department_id%TYPE)
 return Number;
END psm_pachet1;

Create or Replace Package Body psm_pachet1 IS
Function numarAngajati(dep departments.department_id%type)
Return Number
IS
numar Number;

BEGIN
SELECT Count(*) INTO numar From Employees
 Where department_id = dep;
return numar;
End numarAngajati;

Function sumaSalarii(dep departments.department_id%type)
Return Number
IS
suma Number;

BEGIN
Select SUM(Salary+salary*NVL(Commission_pct,0) INTO SUMA
 From Employees Where Department_id=dep;
Return suma;
END sumaSalarii;
END psm_pachet1;
/

