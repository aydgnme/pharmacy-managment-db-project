create PACKAGE Employee_Package AS
  -- Functie pentru obtinerea salariului unui angajat
  FUNCTION GetSalary(employee_id NUMBER) RETURN NUMBER;

  -- Procedura pentru afisarea informatiilor despre un angajat
  PROCEDURE PrintEmployeeInfo(employee_id NUMBER);
END Employee_Package;
/

