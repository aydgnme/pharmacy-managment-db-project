create view AN_SALARIU_ED as
SELECT  COUNT(employee_id) AS NrAngajati, MAX(salary) AS Salmaxim, TO_CHAR(hire_date, 'YYYY') AS An
FROM Employees
GROUP BY TO_CHAR(hire_date, 'YYYY')
/

