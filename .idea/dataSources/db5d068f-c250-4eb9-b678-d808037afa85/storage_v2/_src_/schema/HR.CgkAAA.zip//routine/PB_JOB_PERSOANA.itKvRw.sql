create FUNCTION pb_job_persoana(v_nume IN employees.first_name%TYPE, v_prenume IN employees.last_name%TYPE) RETURN VARCHAR IS

v_job Employees.job_id%TYPE;



BEGIN

SELECT job_title INTO v_job FROM Employees e JOIN Jobs j ON e.job_id = j.job_id WHERE first_name = v_prenume AND last_name = v_nume;





DBMS_OUTPUT.PUT_LINE('Angajatul ' || v_nume || ' ' || v_prenume || ' are job-ul ' || v_job);

RETURN v_job;



EXCEPTION

WHEN NO_DATA_FOUND THEN

DBMS_OUTPUT.PUT_LINE('Nu exista angajat cu numele si prenumele ' || v_nume || ' ' || v_prenume);

RETURN NULL;

END;




/

