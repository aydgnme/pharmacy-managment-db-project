create PACKAGE  pachet_CC1 IS

PROCEDURE printFirstNBySalary(n INTEGER);

FUNCTION getCountByDepartment(id departments.department_id%TYPE) RETURN INTEGER;

END pachet_CC1;
/

