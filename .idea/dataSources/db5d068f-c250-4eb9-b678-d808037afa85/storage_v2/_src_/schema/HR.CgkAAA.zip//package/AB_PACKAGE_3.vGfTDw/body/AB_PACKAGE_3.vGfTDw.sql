create package body ab_package_3 is

procedure numeIncepeCuLitera(litera in char) is

begin
for entry in (select last_name, first_name from employees
                where last_name like litera || '%')
loop

dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;
if NO_DATA_FOUND then
            dbms_output.put_line('Nu exista angajati al caror nume începe cu litera' || litera);
        end if;

end numeIncepeCuLitera;


procedure angajatCuAngajat(nume in employees.last_name%type, prenume in employees.first_name%type) is
begin
for entry in (select last_name, first_name
from employees
where job_id = (select job_id
from employees
where last_name = nume and first_name = prenume))
loop
dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;

EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('Nu exista angajati ');
end angajatCuAngajat;


procedure angajatCuSalMare is
begin
for entry in (select last_name, first_name
from employees
where salary > (select avg(salary)
from employees))
loop
dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('Nu exista angajati');
end angajatCuSalMare;


end ab_package_3;
/

