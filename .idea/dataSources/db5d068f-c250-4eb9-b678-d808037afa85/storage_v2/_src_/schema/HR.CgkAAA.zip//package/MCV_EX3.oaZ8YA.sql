create PACKAGE mcv_ex3 IS
 PROCEDURE afis_litera(nume mcv_emp.last_name%TYPE);
 PROCEDURE acelasi_job(nume mcv_emp.last_name%TYPE, prenume mcv_emp.first_name%TYPE);
 PROCEDURE salar_mare;
END mcv_ex3;
/

