create package pachet4_LE is

procedure add_dep(name Dep_LE.department_name%type)
as
begin
insert into Dep_LE(department_name) values(name);
end add_dep;

procedure modif_dep(name Dep_LE.department_name%type, name_n Dep_LE.department_name%type) as
begin
update Dep_LE
set department_name = name_n
where department_name = name;
end modif_dep;

procedure del_dep(id Dep_LE.department_id%type)
begin
delete from Dep_LE
where department_id = id;
end del_dep;

function get_dep(id Dep_LE.department_id%type)
return varchar2
is
denumire Dep_LE.department_id%type;
begin
select department_name into denumire from Dep_LE
where department_id = id;
return denumire;
end get_dep;

end pachet4_LE;
/

