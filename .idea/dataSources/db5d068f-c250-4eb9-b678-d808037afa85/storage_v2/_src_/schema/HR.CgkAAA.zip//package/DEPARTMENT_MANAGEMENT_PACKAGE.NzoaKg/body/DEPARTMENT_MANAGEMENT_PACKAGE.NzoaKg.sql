create PACKAGE BODY DEPARTMENT_MANAGEMENT_PACKAGE IS

  PROCEDURE ADD_DEP(DEP_NAME IN VARCHAR2) IS
  BEGIN
    INSERT INTO TA_dep (department_id, department_name) VALUES (DEP_ID, DEP_NAME);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Department added successfully.');
  END ADD_DEP;

  PROCEDURE MODIF_DEP(OLD_DEP_NAME VARCHAR2, NEW_DEP_NAME IN VARCHAR2) IS
  BEGIN
    UPDATE TA_dep  SET department_name = NEW_DEP_NAME WHERE department_id = DEP_ID;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Department updated successfully.');
  END MODIF_DEP;

  PROCEDURE DEL_DEP(DEP_ID IN NUMBER) IS
  BEGIN
    DELETE FROM TA_dep  WHERE department_id = DEP_ID;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Department deleted successfully.');
  END DEL_DEP;

  PROCEDURE GET_DEP(DEP_ID NUMBER) IS
  dep_name varchar;
  BEGIN
    SELECT DEPARTAMENT_NAME INTO dep_name FROM TA_dep WHERE department_id = DEP_ID;
	DBMS_OUTPUT.PUT_LINE('Departament are titlu ' ||  dep_name);
  END GET_DEP;

END DEPARTMENT_MANAGEMENT_PACKAGE;
/

