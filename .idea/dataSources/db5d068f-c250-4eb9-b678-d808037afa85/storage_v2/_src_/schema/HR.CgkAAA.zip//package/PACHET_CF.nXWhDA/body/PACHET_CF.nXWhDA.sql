create PACKAGE BODY pachet_CF IS



FUNCTION nr_ang(job IN employees.job_id%TYPE) RETURN NUMBER IS

nr NUMBER;



BEGIN



SELECT COUNT(employee_id) INTO nr FROM Employees WHERE job_id = job;

RETURN nr;

END nr_ang;



PROCEDURE sterg_ang IS

mn DATE;

id employees_cf.employee_id%TYPE;

vechime employees_cf.hire_date%TYPE;



BEGIN

SELECT MIN(hire_date) INTO mn FROM Employees_cf;

DELETE FROM employees_cf WHERE hire_date = mn RETURNING employee_id, hire_date INTO id, vechime;

DBMS_OUTPUT.PUT_LINE('Angatatul cu id-ul ' || id || ', angajat la data de ' || TO_CHAR(vechime, 'DD-MM-YYYY') || ' a fost sters.');

END sterg_ang;

END pachet_CF;
/

