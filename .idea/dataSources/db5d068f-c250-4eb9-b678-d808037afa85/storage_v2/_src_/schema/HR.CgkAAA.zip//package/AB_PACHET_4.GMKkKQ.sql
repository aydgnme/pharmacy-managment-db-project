create package ab_pachet_4 is
procedure add_dep (name ab_dep.department_name%type);
procedure modif_dep (name ab_dep.department_name%type,name_n ab_dep.department_name%type);
procedure del_dep (id ab_dep.department_id%type);
function get_dep(id ab_dep.department_id%type) return varchar2;
end ab_pachet_4;
/

