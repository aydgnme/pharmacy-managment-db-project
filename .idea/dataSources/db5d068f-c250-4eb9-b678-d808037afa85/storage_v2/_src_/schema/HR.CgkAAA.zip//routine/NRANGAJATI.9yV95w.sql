create function nrAngajati(q in employees.job_id%type)

  return number is

   numar number(9);

  begin

   select count(employee_id) into numar

   from employees

   where job_id = q;



   return q;

   Exception

    when others then

    return -1;

  end;
/

