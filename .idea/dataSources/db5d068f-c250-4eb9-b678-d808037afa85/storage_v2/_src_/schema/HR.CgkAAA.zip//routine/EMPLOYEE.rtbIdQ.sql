create function employee(hire_year in number ) return number is
begin
for employee_rec in(
select employee_id, first_name, last_name, hire_date
from employees
where extract(year from hire_date) =hire_year )

loop

dbms_output.put_line(employee_rec.first_name || employee_rec.last_name || to_char(employee_rec.hire_date , 'YYYY'));

end loop;
return sql%rowcount;
end;
/

