create PACKAGE calcAvgCB IS
  FUNCTION avgYearCB(emp_hd employees.hire_date%type) RETURN NUMBER;
  FUNCTION avgDepCB(emp_di employees.department_id%type) RETURN NUMBER;
  FUNCTION avgCB RETURN NUMBER;
END calcAvgCB;

--corpul pachetului
CREATE OR REPLACE PACKAGE BODY calcAvgCB IS

  FUNCTION avgYearCB(emp_hd employees.hire_date%type)
  RETURN NUMBER
  IS
    AVERAGE NUMBER;
  BEGIN
    SELECT FLOOR(AVG(SALARY)) INTO AVERAGE FROM EMPLOYEES
    WHERE to_char(HIRE_DATE,'YYYY')=to_char(emp_hd,'YYYY');
    RETURN AVERAGE;
  END avgYearCB;

  FUNCTION avgCB RETURN NUMBER IS
  NUMAR;
  BEGIN
  SELECT AVG(SALARY) INTO NUMAR FROM EMPLOYEES;
  RETURN NUMAR;
  END avgCB;

  FUNCTION avgDepCB(emp_di employees.department_id%type)
  RETURN NUMBER
  IS
    SUMA NUMBER;
  BEGIN
    SELECT FLOOR(AVG(SALARY)) INTO SUMA FROM EMPLOYEES
    WHERE DEPARTMENT_ID=EMP_DI;
    RETURN SUMA;
  END avgDepCB;

END calcAvgCB;
/

