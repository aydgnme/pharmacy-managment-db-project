create PACKAGE BODY pe_pachet IS

FUNCTION avgSalaryDep_PE(dep_id departments.department_id%TYPE)
  RETURN NUMBER
  IS
    avg_salary NUMBER;
  BEGIN
    SELECT AVG(salary) INTO avg_salary
    FROM employees
    WHERE department_id = dep_id;

    RETURN avg_salary;
  END avgSalaryDep_PE;


FUNCTION avgSalaryYear_PE(year_hired NUMBER)
  RETURN NUMBER
  IS
    avg_salary NUMBER;
  BEGIN
    SELECT AVG(salary) INTO avg_salary
    FROM employees
    WHERE EXTRACT(YEAR FROM hire_date) = year_hired;

    RETURN avg_salary;
  END avgSalaryYear_PE;


FUNCTION avgSalaryEmployees_PE()
  RETURN NUMBER
  IS
    avg_salary NUMBER;
  BEGIN
    SELECT AVG(salary) INTO avg_salary
    FROM employees

    RETURN avg_salary;
  END avgSalaryYearEmployees_PE;

END pe_pachet;
/

