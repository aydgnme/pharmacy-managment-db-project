create FUNCTION DivideNumbers(numerator NUMBER, denominator NUMBER) RETURN NUMBER IS
BEGIN
  RETURN numerator / denominator;
EXCEPTION
  WHEN ZERO_DIVIDE THEN
    DBMS_OUTPUT.PUT_LINE('Eroare: Impartire la zero!');
    RETURN NULL;
END;
/

