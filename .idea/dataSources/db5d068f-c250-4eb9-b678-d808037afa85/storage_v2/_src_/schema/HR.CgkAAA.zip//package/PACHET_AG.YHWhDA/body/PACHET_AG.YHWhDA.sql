create package body pachet_ag is

FUNCTION f(id IN emp_ag.employee_id%TYPE)

return number

is

an NUMBER;

begin

select to_char(hire_date,'yyyy') into an

from emp_ag

where employee_id=id;

return an;

end f;


PROCEDURE p(id IN emp_ag.employee_id%TYPE, val  IN emp_ag.salary%TYPE)

is


begin

update emp_ag

set salary=val

where employee_id=id;

commit;
DBMS_OUTPUT.PUT_LINE(id ||' ' || salary);

end p;

end pachet_ag;
/

