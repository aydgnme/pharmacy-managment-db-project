create PACKAGE BODY Employee_Management_IC AS


  PROCEDURE Delete_Oldest_Employee_IC IS



    v_employee_id NUMBER;



  BEGIN

    SELECT employee_id INTO v_employee_id

    FROM EMPLOYEES_IC_TEST

    WHERE hire_date = (SELECT MIN(hire_date) FROM EMPLOYEES_IC_TEST);



    DELETE FROM EMPLOYEES_IC_TEST WHERE employee_id = v_employee_id;

    COMMIT;



EXCEPTION

    WHEN NO_DATA_FOUND THEN

      DBMS_OUTPUT.PUT_LINE('NICIUN ANGAJAT GASIT.');

    WHEN OTHERS THEN

      DBMS_OUTPUT.PUT_LINE('ErOARE: ' || SQLERRM);



  END Delete_Oldest_Employee_IC;



  FUNCTION Count_Employees_By_Job_IC(job_id IN VARCHAR2) RETURN NUMBER IS



    v_count NUMBER;



  BEGIN



    SELECT COUNT(*) INTO v_count FROM employees_IC_TEST WHERE job_id = job_id;



    RETURN v_count;



  EXCEPTION



    WHEN OTHERS THEN



      DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);



      RETURN NULL;



  END Count_Employees_By_Job_IC;



END Employee_Management_IC;


/

