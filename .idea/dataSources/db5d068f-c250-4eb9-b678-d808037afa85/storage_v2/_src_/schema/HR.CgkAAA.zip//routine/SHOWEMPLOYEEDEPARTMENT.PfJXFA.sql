create PROCEDURE ShowEmployeeDepartment(p_EmployeeID NUMBER) IS
  v_EmployeeName VARCHAR2(100);
  v_DepartmentName VARCHAR2(100);
BEGIN
  SELECT e.First_Name || ' ' || e.Last_Name, d.Department_Name
  INTO v_EmployeeName, v_DepartmentName
  FROM PSM_Employees e
  INNER JOIN PSM_Departments d ON e.Department_ID = d.Department_ID
  WHERE e.Employee_ID = p_EmployeeID;

  DBMS_OUTPUT.PUT_LINE('Employee Name: ' || v_EmployeeName);
  DBMS_OUTPUT.PUT_LINE('Department: ' || v_DepartmentName);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Employee with ID ' || p_EmployeeID || ' not found.');
END;
/

