create view ANGAJATI_IC33B as
select e.employee_id, e.first_name, e.last_name, d.department_id, l.city
from employees e, departments d, locations l
where d.department_id = e.department_id AND l.location_id = d.location_id AND l.city = 'London'
/

