create PACKAGE BODY packageArcadie2 AS
    FUNCTION get_full_name(p_employee_id NUMBER) RETURN VARCHAR2 IS
        v_full_name VARCHAR2(100);
    BEGIN
        SELECT first_name || ' ' || last_name INTO v_full_name
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_full_name;
    END get_full_name;

    FUNCTION get_salary(p_employee_id NUMBER) RETURN NUMBER IS
        v_salary NUMBER;
    BEGIN
        SELECT salary INTO v_salary
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_salary;
    END get_salary;

    FUNCTION get_email(p_employee_id NUMBER) RETURN VARCHAR2 IS
        v_email VARCHAR2(100);
    BEGIN
        SELECT email INTO v_email
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_email;
    END get_email;

    FUNCTION get_hire_date(p_employee_id NUMBER) RETURN DATE IS
        v_hire_date DATE;
    BEGIN
        SELECT hire_date INTO v_hire_date
        FROM employees
        WHERE employee_id = p_employee_id;

        RETURN v_hire_date;
    END get_hire_date;
END packageArcadie2;
/

