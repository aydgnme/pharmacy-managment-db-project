create FUNCTION display_employees_by_year(hire_year IN NUMBER)
RETURN NUMBER
IS
BEGIN
    FOR employee_rec IN (
        SELECT employee_id, first_name, last_name, hire_date
        FROM employees
        WHERE EXTRACT(YEAR FROM hire_date) = hire_year
    )
    LOOP

    END LOOP;


    RETURN SQL%ROWCOUNT;
END;
/

