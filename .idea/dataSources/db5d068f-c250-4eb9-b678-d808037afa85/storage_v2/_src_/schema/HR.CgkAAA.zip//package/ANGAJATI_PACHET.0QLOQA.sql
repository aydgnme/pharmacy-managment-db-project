create PACKAGE Angajati_Pachet AS
  PROCEDURE afisare_angajati_job(job_id VARCHAR2);

  PROCEDURE afisare_salariati_an(anul NUMBER);

  PROCEDURE afisare_angajati_job(job_id VARCHAR2, anul NUMBER);
END Angajati_Pachet;
/

