create function f1_LE (nume employees.last_name%TYPE, prenume employees.first_name%TYPE)
return varchar2
is
job employees.job_id%TYPE;
begin
select job_id into job
from employees
where last_name = nume and first_name = prenume;
return job;

exception
when NO_DATA_FOUND then
dbms_output.put_line('Nu exita nici un angajat cu acest job');
when TOO_MANY_ROWS then
dbms_output.put_line('Exita mai multi angajati cu acest job');
when OTHERS then
dbms_output.put_line('A aparut o eroare!');
end f1_LE;
/

