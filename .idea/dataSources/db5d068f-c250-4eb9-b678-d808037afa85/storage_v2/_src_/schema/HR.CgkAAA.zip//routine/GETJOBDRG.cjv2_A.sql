create FUNCTION GetJobDRG(p_first_name VARCHAR2, p_last_name VARCHAR2)



RETURN VARCHAR2



IS

    v_job JOBS.job_title%TYPE;

BEGIN

    SELECT job_title INTO v_job

    FROM employees e, jobs j

    WHERE e.first_name = p_first_name AND e.last_name = p_last_name AND j.job_id=e.job_id;

    RETURN v_job;



EXCEPTION

    WHEN NO_DATA_FOUND THEN

        RETURN 'No employee found';

    WHEN TOO_MANY_ROWS THEN

        RETURN 'Multiple entries found';

    WHEN OTHERS THEN

        RETURN 'Error: ' || SQLERRM;



END;




/

