create PACKAGE pe_employees2 AS
  PROCEDURE displayEmployeesByInital(emp_inital IN CHAR);
  PROCEDURE displayEmployeesByJob(emp_name IN VARCHAR2);
  PROCEDURE employeesAboveAverage;
END pe_employees2;
/

