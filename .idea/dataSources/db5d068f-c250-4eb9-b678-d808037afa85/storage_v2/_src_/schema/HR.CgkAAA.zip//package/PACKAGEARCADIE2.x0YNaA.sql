create PACKAGE packageArcadie2 AS
    FUNCTION get_full_name(p_employee_id NUMBER) RETURN VARCHAR2;
    FUNCTION get_salary(p_employee_id NUMBER) RETURN NUMBER;
    FUNCTION get_email(p_employee_id NUMBER) RETURN VARCHAR2;
    FUNCTION get_hire_date(p_employee_id NUMBER) RETURN DATE;
END packageArcadie2;
/

