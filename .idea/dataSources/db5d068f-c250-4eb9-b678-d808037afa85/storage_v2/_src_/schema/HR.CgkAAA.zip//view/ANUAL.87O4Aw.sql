create view ANUAL as
SELECT count(employee_id) as nr_angajati, max(salary) as salariu, to_char(hire_date, 'YYYY') as an
from employees
group by to_char(hire_date, 'YYYY')
/

