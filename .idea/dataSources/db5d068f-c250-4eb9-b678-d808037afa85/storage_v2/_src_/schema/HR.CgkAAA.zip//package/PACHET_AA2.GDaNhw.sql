create PACKAGE pachet_aa2 IS
FUNCTION numecompletangajat(id aa_emp.employee_id%TYPE)
RETURN VARCHAR2;
FUNCTION salariuangajat(id aa_emp.employee_id%TYPE)
RETURN NUMBER;
FUNCTION emailangajat(id aa_emp.employee_id%TYPE)
RETURN VARCHAR2;
FUNCTION hiredateangajat(id aa_emp.employee_id%TYPE)
RETURN DATE;
END pachet_aa2;
/

