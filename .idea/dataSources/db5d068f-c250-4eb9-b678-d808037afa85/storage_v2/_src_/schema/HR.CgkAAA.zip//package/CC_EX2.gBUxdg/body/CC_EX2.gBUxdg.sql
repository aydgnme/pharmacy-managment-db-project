create PACKAGE BODY CC_ex2 IS
FUNCTION Nume(id employees.employee_id%TYPE)
RETURN VARCHAR2
IS
val_nume VARCHAR2(50);
BEGIN
Select last_name||' '||first_name INTO val_nume from Employees
Where employee_id = id;
RETURN val_nume;
END Nume;

FUNCTION Salariu(id employees.employee_id%TYPE)
RETURN NUMBER
IS
suma NUMBER;
BEGIN
Select salary INTO suma from Employees
Where employee_id = id;
RETURN suma;
END Salariu;

FUNCTION Email(id employees.employee_id%TYPE)
RETURN VARCHAR2
IS
val_email VARCHAR2(25);
BEGIN
Select email INTO val_email From Employees
Where employee_id= id;
RETURN val_email;
END Email;

FUNCTION Data_Ang(id employees.employee_id%TYPE)
RETURN DATE
IS
val_data DATE;
BEGIN
Select hire_date INTO val_data From Employees
Where employee_id = id;
RETURN val_data;
END Data_Ang;

END CC_ex2;
/

