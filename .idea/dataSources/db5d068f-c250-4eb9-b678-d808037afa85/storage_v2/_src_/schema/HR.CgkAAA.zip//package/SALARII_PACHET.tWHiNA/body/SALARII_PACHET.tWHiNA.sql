create PACKAGE BODY Salarii_pachet IS
    FUNCTION medieSalariuPerDepartament(dep_id IN NUMBER) RETURN NUMBER IS
        avg_salariu NUMBER;
    BEGIN
        SELECT AVG(salary) INTO avg_salariu FROM employees WHERE department_id = dep_id;
        RETURN avg_salariu;
    END medieSalariuPerDepartament;

    FUNCTION medieSalariuPentruToti RETURN NUMBER IS
        avg_salariu_tot NUMBER;
    BEGIN
        SELECT AVG(salary) INTO avg_salariu_tot FROM employees;
        RETURN avg_salariu_tot;
    END medieSalariuPentruToti;

    FUNCTION medieSalariuPerAn(anul IN NUMBER) RETURN NUMBER IS
        avg_salariu_an NUMBER;
    BEGIN
        SELECT AVG(salary) INTO avg_salariu_an FROM employees WHERE EXTRACT(YEAR FROM hire_date) = anul;
        RETURN avg_salariu_an;
    END medieSalariuPerAn;
END Salarii_pachet;
/

