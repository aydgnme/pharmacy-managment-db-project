create procedure  pd_procedur
is update;
declare
v_dep departments_pdd.department_name%type;

begin
--v_dep:='Dep_nou';
procedure pd_procedur;
Update departments_pdd
set department_name=v_dep;


end pd_procedur;

begin
v_dep:='Dep_nou';

update departments_pdd
set department_name=v_dep;
where department_id=90;
end;
/show errors;
/

