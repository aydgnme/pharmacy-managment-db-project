create PACKAGE mg_pachet3 IS
  PROCEDURE empInitial(p_initial IN VARCHAR2);
  PROCEDURE empSameJobs(p_nume IN VARCHAR2, p_prenume IN VARCHAR2);
  PROCEDURE highSalaries;
END mg_pachet3;
/

