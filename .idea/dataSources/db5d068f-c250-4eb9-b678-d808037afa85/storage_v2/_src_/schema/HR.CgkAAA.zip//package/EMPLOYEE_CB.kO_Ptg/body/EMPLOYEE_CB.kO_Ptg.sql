create PACKAGE BODY employee_cb IS

    FUNCTION get_hire_year(emp_id IN employees.employee_id%TYPE) RETURN NUMBER IS

        v_hire_year NUMBER;

    BEGIN

        SELECT EXTRACT(YEAR FROM hire_date)

        INTO v_hire_year

        FROM employees

        WHERE employee_id = emp_id;

        RETURN v_hire_year;

    EXCEPTION

        WHEN NO_DATA_FOUND THEN

            RETURN NULL;

        WHEN OTHERS THEN

            RAISE;

    END get_hire_year;

    PROCEDURE update_salary(emp_id IN employees.employee_id%TYPE, salary_change IN NUMBER) IS

    BEGIN

        UPDATE ab_angajati

        SET salary = salary + salary_change

        WHERE employee_id = emp_id;

        IF SQL%ROWCOUNT = 0 THEN

            RAISE_APPLICATION_ERROR(-20001, 'Niciun angajat gasit cu ID-ul montionat');

        END IF;

    EXCEPTION

        WHEN OTHERS THEN

            RAISE;

    END update_salary;

END employee_cb;


/

