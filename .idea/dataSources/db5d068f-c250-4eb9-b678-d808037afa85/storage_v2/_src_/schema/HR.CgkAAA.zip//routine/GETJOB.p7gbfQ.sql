create FUNCTION GetJob(nume VARCHAR2, prenume VARCHAR2)
RETURN VARCHAR2
IS
    v_job employees.job_id%TYPE;
BEGIN
    SELECT job_id INTO v_job
    FROM employees
    WHERE last_name = nume and first_name = prenume;
    RETURN v_job;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'No employee found';
    WHEN TOO_MANY_ROWS THEN
        RETURN 'Multiple entries found';
    WHEN OTHERS THEN
        RETURN 'Error: ' || SQLERRM;
END;
/

