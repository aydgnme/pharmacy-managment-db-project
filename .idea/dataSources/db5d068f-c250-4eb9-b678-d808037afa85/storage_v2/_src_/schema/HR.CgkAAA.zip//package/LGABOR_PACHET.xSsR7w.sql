create PACKAGE lgabor_pachet IS

 FUNCTION f1(id IN departments.department_id%TYPE) RETURN NUMBER;

 PROCEDURE p1(id IN departments.department_id%TYPE);

END;
/

