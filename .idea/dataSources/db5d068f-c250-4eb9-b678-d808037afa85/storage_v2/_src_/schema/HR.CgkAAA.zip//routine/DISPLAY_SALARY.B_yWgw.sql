create PROCEDURE display_salary(prenume IN employees.first_name%TYPE, nume IN employees.last_name%TYPE) IS

    emp_salary NUMBER;

BEGIN

    SELECT salary

    INTO emp_salary

    FROM employees

    WHERE first_name = prenume AND last_name = nume;

    DBMS_OUTPUT.PUT_LINE('Salariul angajatului ' || prenume || ' ' || nume || ' este: ' || emp_salary);

EXCEPTION

    WHEN NO_DATA_FOUND THEN

        DBMS_OUTPUT.PUT_LINE('Nu s-a gasit niciun angajat cu numele specificat.');

    WHEN OTHERS THEN

        DBMS_OUTPUT.PUT_LINE('Alte erori.');

END;
/

