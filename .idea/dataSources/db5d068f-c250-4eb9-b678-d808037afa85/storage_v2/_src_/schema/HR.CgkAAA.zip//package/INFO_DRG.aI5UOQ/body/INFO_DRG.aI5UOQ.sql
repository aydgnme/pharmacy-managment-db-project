create PACKAGE BODY Info_drg AS

  PROCEDURE AfiseazaAngajati(p_job_id IN VARCHAR2) IS
    l_r_found BOOLEAN := FALSE;
  BEGIN
    FOR r IN (SELECT employee_id, first_name, last_name FROM employees WHERE job_id = p_job_id) LOOP
      DBMS_OUTPUT.PUT_LINE(r.employee_id || ', ' || r.first_name || ' ' || r.last_name);
      l_r_found := TRUE;
    END LOOP;

    IF NOT l_r_found THEN
      DBMS_OUTPUT.PUT_LINE('Niciun angajat nu corespunde criteriului de job: ' || p_job_id);
    END IF;
  END AfiseazaAngajati;

  PROCEDURE AfiseazaAngajati(p_an_angajare IN NUMBER) IS
    l_r_found BOOLEAN := FALSE;
  BEGIN
    FOR r IN (SELECT employee_id, first_name, last_name FROM employees WHERE EXTRACT(YEAR FROM hire_date) = p_an_angajare) LOOP
      DBMS_OUTPUT.PUT_LINE(r.employee_id || ', ' || r.first_name || ' ' || r.last_name);
      l_r_found := TRUE;
    END LOOP;

    IF NOT l_r_found THEN
      DBMS_OUTPUT.PUT_LINE('Niciun angajat nu a fost angajat în anul: ' || p_an_angajare);
    END IF;
  END AfiseazaAngajati;

END Info_drg;
/

