create PACKAGE hlm_pachet2 IS
 FUNCTION empFullName(id employees.EMPLOYEE_ID%Type)
 RETURN employees.FIRST_NAME%Type;

 FUNCTION empSalary(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Salary%Type;

 FUNCTION empEmail(id employees.EMPLOYEE_ID%Type)
 RETURN employees.Email%Type;

 FUNCTIOn empHireDate(id employees.EMPLOYEE_ID%Type)
 RETURN employees.HIRE_DATE%Type;

END hlm_pachet2;
/

