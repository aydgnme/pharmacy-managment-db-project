create PACKAGE MCV_EX1 IS
  FUNCTION angajati_din_an(data_ang IN employees.hire_date%TYPE) RETURN NUMBER;
  FUNCTION angajati_din_departa(departa IN employees.department_id%TYPE) RETURN NUMBER;
END MCV_EX1;
/

