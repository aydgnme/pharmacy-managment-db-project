create view EMPLOYEEBLM5 as
SELECT e.employee_id, e.last_name, e.first_name, e.department_id, l.city
FROM Employees e, Departments d, Locations l
WHERE e.department_id=d.department_id AND d.location_id=l.location_id AND city LIKE 'Oxford'
/

