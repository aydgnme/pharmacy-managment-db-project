create PROCEDURE cv_increase_salary(p_id IN NUMBER,
                                                p_sal_actual OUT NUMBER,
                                                p_sal_modificat OUT NUMBER) IS
BEGIN

  DECLARE
    v_commission_pct employees.commission_pct%TYPE;
    v_sal_actual employees.salary%TYPE;
    v_sal_modificat employees.salary%TYPE;
  BEGIN

    SELECT commission_pct INTO v_commission_pct
    FROM cv_angajati
    WHERE employee_id = p_id;


    UPDATE cv_angajati
    SET salary =
      CASE
        WHEN v_commission_pct BETWEEN 0.1 AND 0.2 THEN
          salary * 1.10
        WHEN v_commission_pct > 0.2 THEN
          salary * 1.25
        ELSE
          salary
      END
    WHERE employee_id = p_id
    RETURNING salary INTO p_sal_modificat;


    SELECT salary INTO p_sal_actual
    FROM cv_angajati
    WHERE employee_id = p_id;


    DBMS_OUTPUT.PUT_LINE('Salariul actual: ' || p_sal_actual);
    DBMS_OUTPUT.PUT_LINE('Salariul modificat: ' || p_sal_modificat);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Nu exista angajat cu ID-ul dat.');

  END;
END cv_increase_salary;
/

