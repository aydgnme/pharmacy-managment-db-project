create FUNCTION ex3_morosan(prenume VARCHAR2, nume VARCHAR2)

RETURN VARCHAR2

AS

  job VARCHAR2(50);

BEGIN



  SELECT job_id INTO job

  FROM Employees

  WHERE UPPER(first_name) = UPPER(prenume) AND UPPER(last_name) = UPPER(nume);

  RETURN job;



EXCEPTION

  WHEN NO_DATA_FOUND THEN

    RETURN NULL;

  WHEN OTHERS THEN

    RETURN NULL;

END;

/

