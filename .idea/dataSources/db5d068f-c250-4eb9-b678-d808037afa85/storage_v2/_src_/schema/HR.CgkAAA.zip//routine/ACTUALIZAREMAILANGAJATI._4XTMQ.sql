create PROCEDURE actualizarEmailAngajati AS
 TYPE NameList IS TABLE OF VARCHAR2(100);
 lista NameList;
BEGIN
 UPDATE mcv_emp
  SET email = LOWER(first_name || last_name || '@gmail.com')
  WHERE job_id = 'ST_MAN';

 COMMIT;

 SELECT first_name ||''|| last_name
 BULK COLLECT INTO lista
 FROM mcv_emp
 WHERE job_id = 'ST_MAN';

 FOR i in 1..lista.COUNT LOOP
  DBMS_OUTPUT.PUT_LINE('Angajat modificat '||lista(i));
 END LOOP;
END;
/

