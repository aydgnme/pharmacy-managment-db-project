create FUNCTION salariu_maxim_departament(p_department_name IN VARCHAR2) RETURN NUMBER IS
  v_max_salariu NUMBER;
BEGIN
  SELECT MAX(salary) INTO v_max_salariu
  FROM employees e
  JOIN departments d ON e.department_id = d.department_id
  WHERE UPPER(d.department_name) = UPPER(p_department_name);

  RETURN v_max_salariu;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN NULL;
END;
/

