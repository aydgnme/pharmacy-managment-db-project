create PACKAGE BODY CF_pachet1 IS

FUNCTION salariuMediuDepartament(dep departments.department_id%TYPE) RETURN NUMBER IS

nr NUMBER := 0;
e EXCEPTION;
BEGIN
SELECT AVG(salary) INTO nr FROM Employees WHERE department_id = dep;
IF nr = 0 THEN
  RAISE e;
END IF;
RETURN nr;
EXCEPTION
    WHEN e THEN
      DBMS_OUTPUT.PUT_LINE('Departamentul introdus nu este corect.');
    RETURN NULL;
END salariuMediuDepartament;

FUNCTION salariuMediuAngajati RETURN NUMBER IS

nr NUMBER;
BEGIN
SELECT AVG(salary) INTO nr FROM Employees;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Nu exista angajati în tabelul Employees.');
      RETURN NULL;
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('A aparut o eroare în timpul calculului salariului mediu pentru toti angajatii.');
      RETURN NULL;
RETURN nr;
END salariuMediuAngajati;

FUNCTION salariuMediuAn(an VARCHAR2) RETURN NUMBER IS

nr NUMBER;
BEGIN
SELECT AVG(salary) INTO nr FROM Employees WHERE TO_CHAR(hire_date, 'YYYY') = an;
RETURN nr;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Nu exista angajati angajati în anul specificat.');
      RETURN NULL;
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('A aparut o eroare în timpul calculului salariului mediu pentru anul specificat.');
      RETURN NULL;
END salariuMediuAn;

END CF_pachet1;
/

