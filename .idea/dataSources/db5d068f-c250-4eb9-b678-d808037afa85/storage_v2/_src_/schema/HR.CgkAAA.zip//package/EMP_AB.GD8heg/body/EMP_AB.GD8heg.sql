create PACKAGE BODY emp_ab IS

    FUNCTION get_count_emp(p_job_id employees.job_id%TYPE) RETURN NUMBER IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count
        FROM employees
        WHERE job_id = p_job_id;

        RETURN v_count;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;
    END get_count_emp;

    PROCEDURE delete_employee IS
        v_employee_id employees_ab.employee_id%TYPE;
        v_oldest_hire_date DATE;
    BEGIN
        SELECT MIN(hire_date) INTO v_oldest_hire_date FROM employees_ab;

        SELECT employee_id INTO v_employee_id
        FROM employees_ab
        WHERE hire_date = v_oldest_hire_date;

        DELETE FROM employees_ab
        WHERE employee_id = v_employee_id;

        DBMS_OUTPUT.PUT_LINE('Angajatul cu cea mai veche data de angajare (' || TO_CHAR(v_oldest_hire_date, 'DD-MON-YYYY') || ') a fost sters.');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Nu exista angajati.');
    END delete_employee;

END emp_ab;
/

