create procedure  pd_p
as update or insert;

declare
v_dep departments_pdd.department_name%type;

begin
v_dep:='Dep_nou';
procedure pd_p;
Update departments_pdd
set department_name=v_dep
where department_id=90;


end pd_p;


/show errors;
/

