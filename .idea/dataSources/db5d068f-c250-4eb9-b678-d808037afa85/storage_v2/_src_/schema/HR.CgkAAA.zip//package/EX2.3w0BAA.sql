create PACKAGE ex2
FUNCTION an (ID Employees.employee_id%TYPE)
RETURN DATE;
PROCEDURE editsalary(ID Employees.employee_id%TYPE, salariu Employees.salary%TYPE);
END ex2;
/

