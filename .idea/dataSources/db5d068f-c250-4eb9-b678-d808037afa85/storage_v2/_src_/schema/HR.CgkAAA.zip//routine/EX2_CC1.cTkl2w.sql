create PROCEDURE ex2_cc1(c CHAR) IS
TYPE arr IS VARRAY(100) OF employees%ROWTYPE;
my_arr arr;
BEGIN

UPDATE CC1_employees
SET department_id = department_id + 10
WHERE last_name LIKE '%' || c;
-- RETURNING BULK COLLECT INTO my_arr;

SELECT * FROM CC1_employees
BULK COLLECT INTO my_arr
WHERE last_name LIKE '%' || c;

FOR ang IN my_ARR.FIRST...my_arr.LAST LOOP
DBMS_OUTPUT.PUT_LINE(ang.last_name || ' ' || ang.first_name);
END LOOP;
END;
/

