create FUNCTION f7(nume_d mcv_dep.department_name%TYPE)
  RETURN varchar2(50)
 IS
  oras locations.city%TYPE;
  BEGIN
   SELECT l.city INTO oras FROM Locations L, Departments D WHERE l.location_id = d.location_id and d.department_name = nume;
  RETURN oras;
 END f7;
BEGIN
 DBMS_OUTPUT.PUT_LINE('HELLO');
END;
/

