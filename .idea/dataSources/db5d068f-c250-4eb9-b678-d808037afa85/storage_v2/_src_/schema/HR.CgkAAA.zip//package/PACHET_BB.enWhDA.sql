create package pachet_bb is





procedure sterge_angajati;



function nr_ang(id_job employee_bb.job_id%type) return number;



end pachet_bb;


/

