create PACKAGE BODY AfisareAngajati_Pachet IS

    PROCEDURE afisareNumeInitialLitera(litera IN VARCHAR2) IS
    BEGIN
        FOR angajat IN (SELECT * FROM employees WHERE UPPER(SUBSTR(first_name, 1, 1)) = UPPER(litera)) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || angajat.first_name || ' ' || angajat.last_name);
        END LOOP;
    END afisareNumeInitialLitera;


    PROCEDURE afisareAngajatiCuAcelasiJob(nume IN VARCHAR2, prenume IN VARCHAR2) IS
        job_angajat VARCHAR2(50);
    BEGIN
        SELECT job_id INTO job_angajat
        FROM employees
        WHERE UPPER(first_name) = UPPER(nume) AND UPPER(last_name) = UPPER(prenume);

        FOR angajat IN (SELECT * FROM employees WHERE job_id = job_angajat) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || angajat.first_name || ' ' || angajat.last_name);
        END LOOP;
    END afisareAngajatiCuAcelasiJob;


    PROCEDURE afisareSalariuMaiMareDecatMedia IS
        salariu_mediu NUMBER;
    BEGIN
        SELECT AVG(salary) INTO salariu_mediu FROM employees;

        FOR angajat IN (SELECT * FROM employees WHERE salary > salariu_mediu) LOOP
            DBMS_OUTPUT.PUT_LINE('Nume: ' || angajat.first_name || ' ' || angajat.last_name || ', Salariu: ' || angajat.salary);
        END LOOP;
    END afisareSalariuMaiMareDecatMedia;
END AfisareAngajati_Pachet;
/

