create PACKAGE IB_PAC IS
FUNCTION AN_ANG(id  employees.employee_id%type) RETURN NUMBER;
PROCEDURE  SALARIU(id  employees.employee_id%type, SAL_NOU NUMBER);
END IB_PAC;
/

