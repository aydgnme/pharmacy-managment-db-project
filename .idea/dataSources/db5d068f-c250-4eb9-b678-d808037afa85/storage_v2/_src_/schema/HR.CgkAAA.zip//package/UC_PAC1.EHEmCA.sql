create PACKAGE uc_pac1 IS

PROCEDURE p1(id departments.department_id%TYPE);

FUNCTION f1(id departments.department_id%TYPE)

RETURN NUMBER;

END uc_pac1;
/

