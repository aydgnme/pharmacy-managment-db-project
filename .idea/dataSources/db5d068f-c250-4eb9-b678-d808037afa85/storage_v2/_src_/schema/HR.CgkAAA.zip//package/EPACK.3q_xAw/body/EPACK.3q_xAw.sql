create PACKAGE BODY EPack IS
    PROCEDURE Job(job_title jobs.job_title%TYPE) IS
    BEGIN
        FOR emp_rec IN (SELECT employee_id, last_name, first_name
                        FROM Employees e
                        JOIN jobs j ON e.job_id = j.job_id
                        WHERE UPPER(j.job_title) = UPPER(job_title)) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || emp_rec.employee_id || ', Nume: ' || emp_rec.last_name || ', Prenume: ' || emp_rec.first_name);
        END LOOP;
    END Job;

    PROCEDURE displayYear(year NUMBER) IS
    BEGIN
        FOR emp_rec IN (SELECT employee_id, last_name, first_name
                        FROM Employees
                        WHERE EXTRACT(YEAR FROM hire_date) = year) LOOP
            DBMS_OUTPUT.PUT_LINE('ID: ' || emp_rec.employee_id || ', Nume: ' || emp_rec.last_name || ', Prenume: ' || emp_rec.first_name);
        END LOOP;
    END displayYear;
END EPack;
/

