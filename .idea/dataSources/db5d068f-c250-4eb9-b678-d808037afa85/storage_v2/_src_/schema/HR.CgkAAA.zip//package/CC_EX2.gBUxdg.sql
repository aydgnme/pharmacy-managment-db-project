create PACKAGE CC_ex2 IS
FUNCTION Nume(id employees.employee_id%TYPE)
RETURN VARCHAR2;
FUNCTION Salariu(id employees.employee_id%TYPE)
RETURN NUMBER;
FUNCTION Email(id employees.employee_id%TYPE)
RETURN VARCHAR2;
FUNCTION Data_Ang(id employees.employee_id%TYPE)
RETURN DATE;
END CC_ex2;
/

