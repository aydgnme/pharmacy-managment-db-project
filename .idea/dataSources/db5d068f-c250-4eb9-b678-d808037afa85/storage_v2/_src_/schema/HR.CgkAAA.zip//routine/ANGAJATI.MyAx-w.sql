create function angajati(job_title in varchar2) return number is
begin
for employee_rec in(
select employee_id, first_name, last_name, job_id
from employees
where job_id = job_title)
loop
dbms_output.put_line(employee_rec.first_name|| employee_rec.last_name ||employee_rec.job_id);
end loop;
return sql%rowcount;
end;
/

