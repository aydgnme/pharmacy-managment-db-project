create package body pachet3_LE is

procedure nume_ang(litera varchar2)
is
begin
for entry in (select last_name, first_name from employees
where last_name like litera || '%')
loop
dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;
end nume_ang;

procedure angajati(nume employees.last_name%TYPE, prenume employees.first_name%TYPE)
is
begin
for entry in (select last_name, first_name
from employees
where job_id = (select job_id
from employees
where last_name = nume and first_name = prenume))
loop
dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;
end angajati;

procedure sal_ang
is
begin
for entry in (select last_name, first_name
from employees
where salary > (select avg(salary)
from employees))
loop
dbms_output.put_line(entry.last_name || ' ' || entry.first_name);
end loop;
end sal_ang;

end pachet3_LE;
/

