create function nr_angajati(v_job lk_emp.job_id%type)

return number is

  nr_ang number;

begin

  select count(employee_id) into nr_ang

  from lk_emp

  where job_id = v_job;

 return nr_ang;

end nr_angajati;


/

