create package sam_pachet3 is
procedure literaAng(litera in varchar2);
procedure jobAng(nume in varchar2);
procedure salMed;
end sam_pachet3;
/

