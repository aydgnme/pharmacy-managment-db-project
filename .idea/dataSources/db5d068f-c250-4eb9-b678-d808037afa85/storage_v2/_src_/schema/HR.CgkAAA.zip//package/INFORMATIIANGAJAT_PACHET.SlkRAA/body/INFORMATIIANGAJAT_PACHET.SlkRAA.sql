create PACKAGE BODY InformatiiAngajat_pachet IS
    FUNCTION numeComplet(id_angajat IN employees.employee_id%TYPE) RETURN VARCHAR2 IS
        nume_complet VARCHAR2(100);
    BEGIN
        SELECT first_name || ' ' || last_name INTO nume_complet FROM employees WHERE employee_id = id_angajat;
        RETURN nume_complet;
    END numeComplet;

    FUNCTION salariu(id_angajat IN employees.employee_id%TYPE) RETURN NUMBER IS
        salariu_angajat NUMBER;
    BEGIN
        SELECT salary INTO salariu_angajat FROM employees WHERE employee_id = id_angajat;
        RETURN salariu_angajat;
    END salariu;

    FUNCTION email(id_angajat IN employees.employee_id%TYPE) RETURN VARCHAR2 IS
        email_angajat VARCHAR2(100);
    BEGIN
        SELECT email INTO email_angajat FROM employees WHERE employee_id = id_angajat;
        RETURN email_angajat;
    END email;

    FUNCTION dataAngajarii(id_angajat IN employees.employee_id%TYPE) RETURN DATE IS
        data_angajare DATE;
    BEGIN
        SELECT hire_date INTO data_angajare FROM employees WHERE employee_id = id_angajat;
        RETURN data_angajare;
    END dataAngajarii;
END InformatiiAngajat_pachet;
/

