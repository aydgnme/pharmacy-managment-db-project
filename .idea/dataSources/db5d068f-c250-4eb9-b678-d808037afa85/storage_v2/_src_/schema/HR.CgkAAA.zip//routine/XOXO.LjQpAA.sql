create function xoxo(v_id departments.department_id%type) return number is numar_angajati number;
begin
select count(e.employee_id) into numar_angajati
from employees e
group by department_id
having v_id=department_id;
return numar_angajati;
end xoxo;
/

