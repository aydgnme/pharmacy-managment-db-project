create PACKAGE pachet_aa3 IS
    PROCEDURE angajatlitera(litera VARCHAR2);
    PROCEDURE angajatjob(nume aa_emp.last_name%TYPE, prenume aa_emp.first_name%TYPE);
    PROCEDURE angajatsalariumare;
END pachet_aa3;
/

