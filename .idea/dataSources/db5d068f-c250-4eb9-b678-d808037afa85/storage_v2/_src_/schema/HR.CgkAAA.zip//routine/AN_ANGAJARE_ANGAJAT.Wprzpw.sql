create FUNCTION an_angajare_angajat(p_employee_id IN NUMBER) RETURN NUMBER IS
  v_hire_year NUMBER;
BEGIN
  SELECT EXTRACT(YEAR FROM hire_date) INTO v_hire_year
  FROM Employees
  WHERE employee_id = p_employee_id;

  RETURN v_hire_year;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN NULL;
END;
/

