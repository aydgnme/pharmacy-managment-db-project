create PACKAGE packageArcadie3 AS
    PROCEDURE display_employees_by_initial(p_initial CHAR);
    PROCEDURE display_employees_same_job(p_first_name VARCHAR2, p_last_name VARCHAR2);
    PROCEDURE display_employees_above_avg;
END packageArcadie3;
/

