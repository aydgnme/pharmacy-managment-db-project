create PACKAGE BODY Employee_Package AS

  -- Implementarea functiei GetSalary
  FUNCTION GetSalary(employee_id NUMBER) RETURN NUMBER IS
    salary NUMBER;
  BEGIN
    SELECT salary INTO salary FROM employees WHERE employee_id = employee_id;
    RETURN salary;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL; -- Returneaza NULL daca angajatul nu exista
    WHEN OTHERS THEN
      RAISE; -- Ridica orice alta exceptie neasteptata
  END GetSalary;


  PROCEDURE PrintEmployeeInfo(employee_id NUMBER) IS
    emp_info employees%ROWTYPE;
  BEGIN
    SELECT * INTO emp_info FROM employees WHERE employee_id = employee_id;
    DBMS_OUTPUT.PUT_LINE('Nume: ' || emp_info.first_name || ' ' || emp_info.last_name);
    DBMS_OUTPUT.PUT_LINE('Salariu: ' || emp_info.salary);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Angajatul cu ID-ul ' || employee_id || ' nu a fost gasit.');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('A aparut o eroare: ' || SQLERRM);
  END PrintEmployeeInfo;

END Employee_Package;
/

