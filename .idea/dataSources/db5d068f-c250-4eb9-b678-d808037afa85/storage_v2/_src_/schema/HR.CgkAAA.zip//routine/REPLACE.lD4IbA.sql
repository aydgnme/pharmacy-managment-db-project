create procedure replace procedura_pdd
is update;

--v_dep_id departments_pdd.department_id%type;
begin
end;

/

