create PROCEDURE afisare_salariu_angajat (

    nume_angajat IN VARCHAR2,

    prenume_angajat IN VARCHAR2

) IS

    salariu_angajat NUMBER;

BEGIN

    SELECT salary

    INTO salariu_angajat

    FROM employees

    WHERE last_name = nume_angajat AND first_name = prenume_angajat;



    DBMS_OUTPUT.PUT_LINE('Angajatul ' || nume_angajat || ' ' || prenume_angajat || ' are salariul ' || salariu_angajat);



END afisare_salariu_angajat;


/

