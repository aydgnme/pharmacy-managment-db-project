create view EMPLOYEESINFO as
select job_title
from jobs
/

