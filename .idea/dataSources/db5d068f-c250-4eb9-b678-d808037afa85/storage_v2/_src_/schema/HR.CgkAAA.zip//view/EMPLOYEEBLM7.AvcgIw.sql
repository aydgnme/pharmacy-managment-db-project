create view EMPLOYEEBLM7 as
SELECT COUNT(employee_id) AS nr_angajati, MAX(salary) AS salariu_maxim,TO_CHAR(hire_date,'YYYY') AS an
FROM Employees
GROUP BY TO_CHAR(hire_date,'YYYY')
/

