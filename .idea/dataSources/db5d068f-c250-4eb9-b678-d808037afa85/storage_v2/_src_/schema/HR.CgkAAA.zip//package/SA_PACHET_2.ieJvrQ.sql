create PACKAGE sa_pachet_2 IS
    FUNCTION getAnAngajare(employee_id IN employees.employee_id%TYPE) RETURN DATE;
    PROCEDURE afisareAnAngajare(employee_id IN employees.employee_id%TYPE);
END sa_pachet_2;
/

