create PACKAGE CM_pack2 IS
FUNCTION getFullName(id employees.employee_id%TYPE)
RETURN VARCHAR2;
FUNCTION getSalary(id employees.employee_id%TYPE)
RETURN employees.salary%TYPE;
FUNCTION getEmail(id employees.employee_id%TYPE)
RETURN employees.email%TYPE;
FUNCTION getHireDate(id employees.employee_id%TYPE)
RETURN employees.hire_date%TYPE;
END CM_pack2;
/

