create function JobEmp(nume varchar2, prenume varchar2)
return varchar2
is
v_job employees.job_id%type;
begin
select job_id into v_job
from employees
where last_name = nume and first_name = prenume;
return v_job;

exception
when NO_DATA_FOUND then
return 'Nu a fost gasit niciun angajat cu acest job';
when TOO_MANY_ROWS then
return 'Au fost gasiti mai multi angajati cu acest job';
when OTHERS then
return 'Eroare!' || SQLERRAM;
end;
/

