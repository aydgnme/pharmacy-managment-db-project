create PACKAGE hlm_pachet4 AS

  PROCEDURE ADD_DEP(hlm_dep_id NUMBER, hlm_dep_name VARCHAR2);

  PROCEDURE MODIF_DEP(hlm_dep_id NUMBER, hlm_dep_name VARCHAR2);

  PROCEDURE DEL_DEP(hlm_dep_id NUMBER);

  FUNCTION GET_DEP(hlm_dep_id NUMBER) RETURN VARCHAR2;
END hlm_pachet4;
/

