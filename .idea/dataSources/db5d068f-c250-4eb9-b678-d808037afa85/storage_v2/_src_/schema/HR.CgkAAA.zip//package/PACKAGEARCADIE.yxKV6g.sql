create PACKAGE packageArcadie AS
    FUNCTION avg_salary_by_department(p_department_id NUMBER) RETURN NUMBER;
    FUNCTION avg_salary_all_employees RETURN NUMBER;
    FUNCTION avg_salary_by_year(p_year NUMBER) RETURN NUMBER;
END packageArcadie;
/

