create PACKAGE CF_pachet2 IS

FUNCTION numeComplet(id employees.employee_id%TYPE) RETURN VARCHAR2;
FUNCTION salariu(id employees.employee_id%TYPE) RETURN NUMBER;
FUNCTION email(id employees.employee_id%TYPE) RETURN employees.email%TYPE;
FUNCTION dataAngajarii(id employees.employee_id%TYPE) RETURN employees.hire_date%TYPE;

END CF_pachet2;
/

