create PROCEDURE CC_NUME (id IN employees.employee_id%TYPE , salariu OUT employees.salary%TYPE, salariu_nou OUT employees.salary%TYPE ) IS
com employees.commission_pct%TYPE;
BEGIN
Select salary,commission_pct INTO salariu,com From CC_Employees Where employee_id = id;
CASE
WHEN com>0.1 AND  com<0.2 THEN
DBMS_OUTPUT.PUT_LINE('Comision 0.1-0.2');
salariu_nou := 1.1 * salariu;
WHEN com > 0.2 THEN
DBMS_OUTPUT.PUT_LINE('Comision >0.2');
salariu_nou := 1.25 * salariu;
ELSE
DBMS_OUTPUT.PUT_LINE('Comision <0.1');
salariu_nou := salariu;
END CASE;
UPDATE CC_Employees
SET salary = salariu_nou
Where employee_id = id;
END CC_NUME;
/

