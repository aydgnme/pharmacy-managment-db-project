create procedure cd_procedura is

begin

update  cd_departments

set department_name = 'IT' where department_id = 10;

end cd_procedura;
/

