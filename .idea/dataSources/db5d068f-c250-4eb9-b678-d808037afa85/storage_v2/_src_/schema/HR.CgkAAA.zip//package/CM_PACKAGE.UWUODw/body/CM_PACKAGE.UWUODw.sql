create PACKAGE BODY CM_package IS

PROCEDURE CM_deleteOldest IS

v_id employees.employee_id%TYPE;

v_hire_date employees.hire_date%TYPE;

BEGIN

SELECT MIN(hire_date) INTO v_hire_date FROM employees;

DELETE FROM CM_emp WHERE hire_date = v_hire_date RETURNING employee_id INTO v_id;

dbms_output.put_line('A fost sters angajatul cu id ' || v_id);

END CM_deleteOldest;

FUNCTION CM_getEmpCountByJob(id employees.job_id%TYPE) RETURN NUMBER IS

v_count NUMBER(5);

BEGIN

SELECT COUNT(*) INTO v_count FROM employees WHERE job_id=id GROUP BY job_id;

RETURN v_count;

END CM_getEmpCountByJob;

END;
/

