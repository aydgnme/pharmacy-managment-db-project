create PACKAGE BODY Angajati_AC_TEST AS



    FUNCTION Anul_Angajarii(ID_angajat IN NUMBER)

      RETURN varchar2 IS  Anul

    BEGIN

        SELECT TO_CHAR(Hire_Date,'YYYY')

        INTO Anul

        FROM employees

        WHERE employee_id = ID_angajat;



        RETURN Anul;



    END Anul_Angajarii;



END Angajati_AC_TEST ;
/

