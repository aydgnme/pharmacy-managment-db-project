create procedure  pd_procedura
is update;
declare
v_dep departments_pdd.department_name%type;

begin
v_dep:='Dep_nou';
procedure pd_procedura;
Update departments_pdd
set department_name=v_dep;
end pd_procedura;


end;
/show errors;
/

