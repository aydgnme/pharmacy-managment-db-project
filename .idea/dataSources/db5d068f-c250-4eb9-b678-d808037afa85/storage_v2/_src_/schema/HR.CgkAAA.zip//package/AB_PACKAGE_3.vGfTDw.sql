create package ab_package_3 is
procedure numeIncepeCuLitera(litera in char);
procedure angajatCuAngajat(nume in employees.last_name%type, prenume in employees.first_name%type);
procedure angajatCuSalMare;
end ab_package_3;
/

