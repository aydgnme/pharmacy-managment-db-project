create package pachet3_LE is

procedure nume_ang(litera varchar2);
procedure angajati(nume employees.last_name%TYPE, prenume employees.first_name%TYPE);
procedure sal_ang;

end pachet3_LE;
/

